import React, { useState, useEffect, useRef } from "react";
import {
  Bell,
  Box,
  Building2,
  Calendar,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  File,
  FileImage,
  FileText,
  HelpCircle,
  Info,
  LayoutGrid,
  List,
  Minus,
  MoreVertical,
  Pencil,
  Pickaxe,
  Plus,
  Route,
  Search,
  Settings,
  Trash2,
  Upload,
  Download,
  Wrench,
  X,
  User,
  Users,
  ShieldCheck,
} from "lucide-react";
import labamuMarkSrc from "./labamu-mark.svg";
import labamuWordmarkSrc from "./labamu-wordmark.svg";
import userGuidePdf from "./CASHENABLE-Labamu Manufacturing User Guide-090426-072447.pdf";

const BrandLogoIcon = ({
  size = 56,
  style = {},
  title = "Labamu",
  ...props
}) => (
  <img
    src={labamuMarkSrc}
    alt={title}
    style={{
      width: size,
      height: size,
      display: "block",
      flexShrink: 0,
      objectFit: "contain",
      ...style,
    }}
    {...props}
  />
);

const BrandLogoLockup = ({
  width = 172,
  style = {},
  title = "Labamu Manufacturing",
  ...props
}) => (
  <img
    src={labamuWordmarkSrc}
    alt={title}
    style={{
      width,
      height: "auto",
      display: "block",
      flexShrink: 0,
      objectFit: "contain",
      ...style,
    }}
    {...props}
  />
);

const SvgIconBase = ({
  size = 24,
  color = "currentColor",
  style = {},
  viewBox = "0 0 24 24",
  children,
  ...props
}) => (
  <svg
    width={size}
    height={size}
    viewBox={viewBox}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    style={{ display: "block", flexShrink: 0, ...style }}
    {...props}
  >
    {typeof children === "function" ? children({ color }) : children}
  </svg>
);

const DashboardIcon = ({
  size = 24,
  color = "currentColor",
  strokeWidth = 1.8,
  style = {},
  ...props
}) => (
  <SvgIconBase size={size} color={color} style={style} {...props}>
    <rect
      x="4.25"
      y="9.1"
      width="3.15"
      height="9.15"
      rx="1.1"
      stroke={color}
      strokeWidth={strokeWidth}
    />
    <rect
      x="10.4"
      y="4.7"
      width="3.15"
      height="13.55"
      rx="1.1"
      stroke={color}
      strokeWidth={strokeWidth}
    />
    <rect
      x="16.55"
      y="11.75"
      width="3.15"
      height="6.5"
      rx="1.1"
      stroke={color}
      strokeWidth={strokeWidth}
    />
  </SvgIconBase>
);

const ProductIcon = ({
  size = 24,
  color = "currentColor",
  strokeWidth = 1.8,
  style = {},
  ...props
}) => (
  <SvgIconBase size={size} color={color} style={style} {...props}>
    <path
      d="M18.3 3.69995H5.69995C4.59538 3.69995 3.69995 4.59538 3.69995 5.69995V18.3C3.69995 19.4045 4.59538 20.2999 5.69995 20.2999H18.3C19.4045 20.2999 20.2999 19.4045 20.2999 18.3V5.69995C20.2999 4.59538 19.4045 3.69995 18.3 3.69995Z"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeMiterlimit="10"
      strokeLinecap="round"
    />
    <path
      d="M5.76001 16.03H7.85001"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M5.76001 18H7.85001"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M14.26 9.96995L12 8.53995L9.73999 9.96995V3.69995H14.26V9.96995Z"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </SvgIconBase>
);

const SalesIcon = ({
  size = 24,
  color = "currentColor",
  strokeWidth = 1.8,
  style = {},
  ...props
}) => (
  <SvgIconBase size={size} color={color} style={style} {...props}>
    <path
      d="M12 15V18.75"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M15 13.5V18.75"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M18 10.5V18.75"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M19.5 5.25L13.0155 11.7345C12.9807 11.7694 12.9393 11.7971 12.8937 11.816C12.8482 11.8349 12.7993 11.8447 12.75 11.8447C12.7007 11.8447 12.6518 11.8349 12.6063 11.816C12.5607 11.7971 12.5193 11.7694 12.4845 11.7345L10.0155 9.2655C9.94518 9.1952 9.84981 9.1557 9.75037 9.1557C9.65094 9.1557 9.55557 9.1952 9.48525 9.2655L4.5 14.25"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M6 16.5V18.75"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M9 13.5V18.75"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </SvgIconBase>
);

const ResourcesIcon = ({
  size = 24,
  color = "currentColor",
  strokeWidth = 1.8,
  style = {},
  ...props
}) => (
  <SvgIconBase size={size} color={color} style={style} {...props}>
    <path
      d="M7.65955 8.55288V3.85453C7.65955 3.34983 8.07249 2.93689 8.57719 2.93689H20.167C20.6718 2.93689 21.0847 3.34983 21.0847 3.85453V15.4444C21.0847 15.9491 20.6718 16.362 20.167 16.362H11.8165"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M16.7074 2.93689H12.0366V5.82747H16.7074V2.93689Z"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M8.7794 9.77612H11.1653V21.0632H2.91565V9.77612H5.29235"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M8.42139 8.81982H5.66846V10.7322H8.42139V8.81982Z"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M5.14099 13.208H8.94002"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M5.14099 15.8691H8.94002"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M5.14099 18.5396H8.94002"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </SvgIconBase>
);

const ManufacturingIcon = Wrench;
const AnalyticsIcon = ({
  size = 24,
  color = "currentColor",
  strokeWidth = 1.8,
  style = {},
  ...props
}) => (
  <SvgIconBase size={size} color={color} style={style} {...props}>
    <path
      d="M18.9171 12.0048C19.3417 12.0048 19.6901 11.6594 19.6478 11.2371C19.4705 9.47124 18.6879 7.821 17.4328 6.56618C16.1777 5.31136 14.5273 4.52918 12.7614 4.35224C12.3383 4.30994 11.9937 4.65837 11.9937 5.08296V11.2364C11.9937 11.4404 12.0748 11.636 12.219 11.7803C12.3632 11.9245 12.5589 12.0055 12.7629 12.0055L18.9171 12.0048Z"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M19.0787 14.9969C18.5894 16.1541 17.8241 17.1738 16.8496 17.9669C15.8751 18.76 14.7212 19.3023 13.4887 19.5464C12.2562 19.7905 10.9827 19.7289 9.77951 19.3672C8.57631 19.0054 7.48004 18.3544 6.58656 17.471C5.69308 16.5877 5.02959 15.4989 4.65409 14.3C4.2786 13.101 4.20253 11.8282 4.43254 10.593C4.66255 9.35786 5.19164 8.19782 5.97355 7.21436C6.75546 6.23089 7.76637 5.45393 8.91792 4.95142"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </SvgIconBase>
);
const FinancingIcon = CreditCard;
const WorkOrderIcon = Pickaxe;
const BillOfMaterialsIcon = FileText;
const RoutingIcon = Route;
const SearchIcon = Search;
const MoreVerticalIcon = MoreVertical;
const NotificationIcon = Bell;
const ChevronDownIcon = ChevronDown;
const ChevronLeftIcon = ChevronLeft;
const ChevronRightIcon = ChevronRight;
const AddIcon = Plus;
const EditIcon = Pencil;
const DeleteIcon = Trash2;
const UserIcon = User;
const TeamIcon = Users;
const RoleIcon = ShieldCheck;
const UploadIcon = Upload;
const DownloadIcon = Download;
const DocumentIcon = FileText;
const FileIcon = File;
const ImageAssetIcon = FileImage;
const GridViewIcon = LayoutGrid;
const ListViewIcon = List;
const CalendarIcon = Calendar;
const UserGuideIcon = HelpCircle;
const CheckIcon = Check;
const CloseIcon = X;
const CloudUploadIcon = ({
  size = 40,
  color = "currentColor",
  strokeWidth = 1.8,
  style = {},
  ...props
}) => (
  <SvgIconBase
    size={size}
    color={color}
    style={style}
    viewBox="0 0 40 40"
    {...props}
  >
    <path
      d="M8.2 30.5H28.8C33.2 30.5 36.8 26.9 36.8 22.5C36.8 18.2 33.4 14.7 29.2 14.5C28.2 9.8 24 6.3 19 6.3C13.6 6.3 9.1 10.4 8.6 15.7C4.8 16.3 2 19.6 2 23.5C2 27.4 5 30.5 8.2 30.5Z"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M19 23V13.6"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
    />
    <path
      d="M14.8 17.8L19 13.6L23.2 17.8"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </SvgIconBase>
);

// --- MOCK DATA ---

const MOCK_VENDORS = [
  {
    id: "v1",
    name: "PT Mitra Sejahtera",
    phone: "08123456789",
    email: "contact@mitra.com",
    address: "Jl. Sudirman No.1, Jakarta Pusat, 10220",
  },
  {
    id: "v2",
    name: "CV Kayu Makmur",
    phone: "08987654321",
    email: "info@kayumakmur.com",
    address: "Jl. Merdeka No.45, Bandung, 40111",
  },
  {
    id: "v3",
    name: "Bintang Sejahtera",
    phone: "08556677889",
    email: "sales@bintang.co.id",
    address: "Kawasan Industri Raya Blok C, Tangerang",
  },
];

const MOCK_COMPANY = {
  name: "Labamu Manufacturing",
  phone: "+62 21 555 1234",
  email: "procurement@labamu.com",
  address: "Jl. Industri Utama Kav 9, South Tangerang, Banten, Indonesia 15320",
};

const COUNTRY_CODE_OPTIONS = [
  { code: "+62", label: "Indonesia", flag: "🇮🇩" },
  { code: "+65", label: "Singapore", flag: "🇸🇬" },
  { code: "+60", label: "Malaysia", flag: "🇲🇾" },
  { code: "+66", label: "Thailand", flag: "🇹🇭" },
  { code: "+84", label: "Vietnam", flag: "🇻🇳" },
  { code: "+63", label: "Philippines", flag: "🇵🇭" },
  { code: "+1", label: "United States", flag: "🇺🇸" },
];

const MOCK_WO_LINES = [
  {
    id: "wo1",
    vendorId: "v1",
    item: "Cabinet Premium Panel",
    code: "CAB-PR-9921",
    desc: "Panel set generated from work order",
    woRef: "WO-2026-03-025-00008",
    qty: 100,
    price: 250000,
    image: "cabinet_premium_panel.jpg",
  },
  {
    id: "wo2",
    vendorId: "v1",
    item: "Chair Backrest",
    code: "CHR-BR-001",
    desc: "Backrest component from work order",
    woRef: "WO-2026-03-026-00002",
    qty: 40,
    price: 175000,
    image: "chair_backrest.jpg",
  },
  {
    id: "wo3",
    vendorId: "v2",
    item: "Wooden Table Top",
    code: "TBL-TOP-021",
    desc: "Table top component from work order",
    woRef: "WO-2026-03-027-00003",
    qty: 24,
    price: 320000,
    image: "wooden_table_top.jpg",
  },
  {
    id: "wo4",
    vendorId: "v3",
    item: "Foam Seat Cushion",
    code: "FOM-ST-010",
    desc: "Seat cushion component from work order",
    woRef: "WO-2026-03-028-00004",
    qty: 60,
    price: 145000,
    image: "foam_seat_cushion.jpg",
  },
];

const MOCK_MATERIAL_LINES = [
  {
    id: "mat1",
    vendorId: "v1",
    item: "Plywood Board 18mm",
    code: "PLY-18-001",
    desc: "Premium plywood board 18mm thickness",
    qty: 120,
    price: 185000,
    image: "plywood_board_reference.jpg",
  },
  {
    id: "mat2",
    vendorId: "v1",
    item: "Wood Glue 5kg",
    code: "GLU-5KG-009",
    desc: "Industrial wood glue 5kg",
    qty: 30,
    price: 95000,
    image: "wood_glue_reference.png",
  },
  {
    id: "mat3",
    vendorId: "v2",
    item: "Teak Veneer Sheet",
    code: "VEN-TEAK-12",
    desc: "Natural teak veneer finishing sheet",
    qty: 60,
    price: 140000,
    image: "teak_veneer_reference.jpg",
  },
  {
    id: "mat4",
    vendorId: "v3",
    item: "Foam Padding Roll",
    code: "FOM-ROL-04",
    desc: "High density foam padding roll",
    qty: 24,
    price: 210000,
    image: "foam_padding_reference.png",
  },
];

const MOCK_WO_TABLE_DATA = [
  {
    wo: "WO-2294824-20251109-00001",
    ord: "ORD-248824-20251109-00001",
    product: "Wooden Chair",
    sku: "CH-WD-23948",
    qty: 100,
    priority: "Medium",
    pColor: "var(--status-orange-primary)",
    pBadge: "yellow-light",
    start: "2025-12-09",
    end: "2026-01-08",
    createdBy: "Natasha",
    status: "Not Started",
    statusKey: "not_started",
    sBadge: "grey",
  },
  {
    wo: "WO-2024-09-015-00003",
    ord: "ORD-99823-202511-00001",
    product: "Lemari Kayu",
    sku: "CUP-WD-4482",
    qty: 20,
    priority: "Medium",
    pColor: "var(--status-orange-primary)",
    pBadge: "yellow-light",
    start: "2025-12-15",
    end: "2026-01-20",
    createdBy: "Joko",
    status: "Ready to Process",
    statusKey: "ready_to_process",
    sBadge: "blue",
  },
  {
    wo: "WO-2026-03-025-00008",
    ord: "ORD-55523-202603-00008",
    product: "Cabinet Premium",
    sku: "CAB-PR-9921",
    qty: 100,
    priority: "High",
    pColor: "var(--status-red-primary)",
    pBadge: "red-light",
    start: "2026-03-20",
    end: "2026-04-15",
    createdBy: "Budi",
    status: "In Progress",
    statusKey: "in_progress",
    sBadge: "yellow",
    outsourceSteps: [2, 3],
    vendors: [
      {
        id: 1,
        name: "Internal",
        output: "30",
        date: "2026-04-15",
        status: "Not Started",
      },
      {
        id: 2,
        name: "CV Kayu Makmur",
        output: "20",
        receivedOutput: 20,
        date: "2026-03-25",
        status: "Completed",
        receivedDate: "2026-03-25",
        attachment: "proof_of_delivery_01.pdf",
        poNumber: "PO-202603-0005",
        isPoApproved: true,
        receipts: [
          {
            amount: 20,
            date: "2026-03-25",
            attachment: "proof_of_delivery_01.pdf",
            note: "Delivered in full and received in good condition.",
          },
        ],
      },
      {
        id: 3,
        name: "PT Mitra Sejahtera",
        output: "8",
        receivedOutput: 4,
        date: "2026-03-28",
        status: "Partially Received",
        receivedDate: "",
        attachment: "proof_of_delivery_02.pdf",
        poNumber: "PO-202603-0002",
        isPoApproved: true,
        receipts: [
          {
            amount: 4,
            date: "2026-03-26",
            attachment: "proof_of_delivery_02.pdf",
            note: "Partial delivery received. Remaining quantity still pending.",
          },
        ],
      },
      {
        id: 4,
        name: "Bintang Sejahtera",
        output: "2",
        receivedOutput: 0,
        date: "2026-03-29",
        status: "Waiting",
        receivedDate: "",
        attachment: "",
        poNumber: "PO-202603-0008",
        isPoApproved: false,
        receipts: [],
      },
      {
        id: 5,
        name: "PT Cahaya Abadi",
        output: "10",
        receivedOutput: 0,
        date: "2026-03-30",
        status: "Waiting",
        receivedDate: "",
        attachment: "",
        poNumber: "PO-202603-0004",
        isPoApproved: true,
        receipts: [],
      },
    ],
    routingStages: [
      {
        step: 1,
        route: "Production Stage Firstahnders...",
        op: "Cutting and Ever...",
        prog: 0,
        comp: 40,
      },
      { step: 2, route: "Production", op: "Assemble", prog: 0, comp: 0 },
      { step: 3, route: "Cat", op: "Paint", prog: 0, comp: 0 },
      { step: 4, route: "Cat", op: "Polish", prog: 0, comp: 0 },
      { step: 5, route: "Production", op: "Packing", prog: 0, comp: 0 },
    ],
  },
  {
    wo: "WO-2024-08-012-00002",
    ord: "ORD-38023-204802-00001",
    product: "Meja Makan",
    sku: "TBL-WD-8293",
    qty: 15,
    priority: "High",
    pColor: "var(--status-red-primary)",
    pBadge: "red-light",
    start: "2025-12-20",
    end: "2025-12-25",
    createdBy: "Akbar Jaya",
    status: "In Progress",
    statusKey: "in_progress",
    sBadge: "yellow",
  },
  {
    wo: "WO-2024-08-012-00001",
    ord: "ORD-38023-204802-00001",
    product: "Meja Makan Coklat K...",
    sku: "TBL-WD-8293-B",
    qty: 15,
    priority: "Low",
    pColor: "var(--feature-brand-primary)",
    pBadge: "blue-light",
    start: "2025-12-20",
    end: "2025-12-25",
    createdBy: "Naomi",
    status: "Completed",
    statusKey: "completed",
    sBadge: "green",
    outsourceSteps: [2, 3],
    vendors: [
      {
        id: 1,
        name: "Internal",
        output: "5",
        receivedOutput: 5,
        date: "2025-12-25",
        status: "Completed",
        receivedDate: "2025-12-25",
        receipts: [
          {
            amount: 5,
            date: "2025-12-25",
            attachment: "Internal routing completion",
            note: "Work Order-recorded from internal routing completion.",
          },
        ],
      },
      {
        id: 2,
        name: "CV Kayu Makmur",
        output: "10",
        receivedOutput: 10,
        date: "2025-12-24",
        status: "Completed",
        receivedDate: "2025-12-24",
        attachment: "proof_of_delivery_03.pdf",
        poNumber: "PO-202603-0005",
        isPoApproved: true,
        receipts: [
          {
            amount: 10,
            date: "2025-12-24",
            attachment: "proof_of_delivery_03.pdf",
            note: "Delivered in full and received in good condition.",
          },
        ],
      },
    ],
    routingStages: [
      { step: 1, route: "Production", op: "Cutting", prog: 0, comp: 15 },
      { step: 2, route: "Production", op: "Assemble", prog: 0, comp: 5 },
      { step: 3, route: "Finishing", op: "Paint", prog: 0, comp: 5 },
      { step: 4, route: "Finishing", op: "Polish", prog: 0, comp: 15 },
      { step: 5, route: "Production", op: "Packing", prog: 0, comp: 15 },
    ],
  },
];

const MOCK_PO_TABLE_DATA = [
  {
    poNumber: "PO-202603-0001",
    vendorName: "PT Mitra Sejahtera",
    amount: "Rp 15.000.000",
    createdDate: "2026-03-20",
    status: "Draft",
    statusKey: "draft",
    sBadge: "grey",
  },
  {
    poNumber: "PO-202603-0002",
    vendorName: "PT Mitra Sejahtera",
    amount: "Rp 8.500.000",
    createdDate: "2026-03-21",
    status: "Need Revision",
    statusKey: "need_revision",
    sBadge: "yellow",
  },
  {
    poNumber: "PO-202603-0003",
    vendorName: "Bintang Sejahtera",
    amount: "Rp 22.000.000",
    createdDate: "2026-03-22",
    status: "Waiting for Approval",
    statusKey: "ready_to_send",
    sBadge: "orange",
  },
  {
    poNumber: "PO-202603-0004",
    vendorName: "PT Cahaya Abadi",
    amount: "Rp 5.250.000",
    createdDate: "2026-03-23",
    status: "Issued",
    statusKey: "issued",
    sBadge: "blue",
  },
  {
    poNumber: "PO-202603-0005",
    vendorName: "CV Kayu Makmur",
    amount: "Rp 11.000.000",
    createdDate: "2026-03-24",
    status: "Completed",
    statusKey: "completed",
    sBadge: "green",
  },
  {
    poNumber: "PO-202603-0006",
    vendorName: "PT Sumber Berkah",
    amount: "Rp 7.000.000",
    createdDate: "2026-03-25",
    status: "Canceled",
    statusKey: "rejected",
    sBadge: "red",
  },
  {
    poNumber: "PO-202603-0007",
    vendorName: "CV Maju Terus",
    amount: "Rp 4.500.000",
    createdDate: "2026-03-25",
    status: "Need Revision",
    statusKey: "need_revision",
    sBadge: "yellow",
  },
  {
    poNumber: "PO-202603-0008",
    vendorName: "Bintang Sejahtera",
    amount: "Rp 18.200.000",
    createdDate: "2026-03-26",
    status: "Draft",
    statusKey: "draft",
    sBadge: "grey",
  },
];

const MOCK_ACTIVITIES = [
  {
    date: "2026-03-22 10:30",
    user: "Natasha Smith",
    action: "Approved Purchase Order",
  },
  {
    date: "2026-03-21 14:00",
    user: "Joko",
    action: "Submitted Purchase Order for Approval",
  },
  {
    date: "2026-03-21 13:45",
    user: "Joko",
    action: "Created Purchase Order Draft",
  },
];

const MOCK_PO_DOCUMENTS = [
  {
    id: "doc-1",
    name: "invoice-march-2026.pdf",
    description: "March invoice",
    meta: "Uploaded by Joko on Mar 20, 2026",
    type: "pdf",
    documentType: "invoice",
    size: "2.4 MB",
  },
  {
    id: "doc-2",
    name: "delivery-note-batch-14.pdf",
    description: "Delivery note for batch 14",
    meta: "Uploaded by Natasha Smith on Mar 20, 2026",
    type: "pdf",
    documentType: "delivery_note",
    size: "1.1 MB",
  },
  {
    id: "doc-3",
    name: "vendor-quotation.pdf",
    description: "Vendor quotation comparison",
    meta: "Uploaded by Joko on Mar 19, 2026",
    type: "pdf",
    documentType: "quotation_vendor",
    size: "860 KB",
  },
  {
    id: "doc-4",
    name: "packing-list-wood-frame.png",
    description: "Packing list for wood frame order",
    meta: "Uploaded by Natasha Smith on Mar 18, 2026",
    type: "image",
    documentType: "packing_list",
    size: "540 KB",
  },
];

const MOCK_ADMIN_USERS = [
  {
    id: "user-1",
    name: "Natasha Smith",
    email: "natasha.smith@labamu.com",
    role: "Owner",
    group: "Executive",
    status: "Active",
  },
  {
    id: "user-2",
    name: "Joko",
    email: "joko@labamu.com",
    role: "Procurement Admin",
    group: "Procurement",
    status: "Active",
  },
  {
    id: "user-3",
    name: "Naomi",
    email: "naomi@labamu.com",
    role: "Finance Manager",
    group: "Finance",
    status: "Active",
  },
  {
    id: "user-4",
    name: "Budi Santoso",
    email: "budi.santoso@labamu.com",
    role: "Production Planner",
    group: "Operations",
    status: "Active",
  },
  {
    id: "user-5",
    name: "Sarah Johnson",
    email: "sarah.johnson@labamu.com",
    role: "Sales Coordinator",
    group: "Commercial",
    status: "Inactive",
  },
];

const MOCK_ADMIN_ROLES = [
  {
    id: "role-1",
    name: "Owner",
    description: "Full access to all modules and configurations.",
    scope: "Full Access",
    status: "Active",
  },
  {
    id: "role-2",
    name: "Procurement Admin",
    description: "Manage purchase orders, receipts, and vendor documents.",
    scope: "Procurement",
    status: "Active",
  },
  {
    id: "role-3",
    name: "Finance Manager",
    description: "Review values, tax, and approval-related settings.",
    scope: "Finance",
    status: "Active",
  },
  {
    id: "role-4",
    name: "Production Planner",
    description: "Manage work orders, routing stages, and outsource requests.",
    scope: "Manufacturing",
    status: "Active",
  },
  {
    id: "role-5",
    name: "Sales Coordinator",
    description: "Handle RFQ, quotes, and customer-facing processes.",
    scope: "Sales",
    status: "Inactive",
  },
];

const MOCK_ADMIN_GROUPS = [
  {
    id: "group-1",
    name: "Executive",
    description: "Leadership team for business-wide oversight.",
    members: ["Natasha Smith"],
    allowedRoles: ["Owner"],
  },
  {
    id: "group-2",
    name: "Procurement",
    description: "Purchasing, vendor, and receipt operations.",
    members: ["Joko"],
    allowedRoles: ["Procurement Admin", "Finance Manager"],
  },
  {
    id: "group-3",
    name: "Operations",
    description: "Work order planning and production execution.",
    members: ["Budi Santoso"],
    allowedRoles: ["Production Planner"],
  },
  {
    id: "group-4",
    name: "Commercial",
    description: "Customer quotation and sales follow-up workflows.",
    members: ["Sarah Johnson"],
    allowedRoles: ["Sales Coordinator"],
  },
];

const NOTIFICATION_DELIVERY_OPTIONS = [
  { value: "Suggested", label: "Suggested" },
  { value: "Instant", label: "Instant" },
  { value: "Hourly Digest", label: "Hourly Digest" },
  { value: "Daily Digest", label: "Daily Digest" },
  { value: "Only High Priority", label: "Only High Priority" },
  { value: "Only Critical", label: "Only Critical" },
  { value: "Mentions Only", label: "Mentions Only" },
];

const DEFAULT_NOTIFICATION_SETTINGS = [
  {
    id: "email",
    title: "Email Notifications",
    description:
      "Send structured updates for approvals, task progress, and cross-team handoffs directly to the user's email inbox.",
    items: [
      {
        id: "po_approval_request",
        title: "Purchase Order approval request",
        description:
          "Notify approvers when a new purchase order is waiting for approval.",
        module: "Purchase Order",
        enabled: true,
        delivery: "Instant",
      },
      {
        id: "po_revision_cancel",
        title: "Purchase Order revision and cancellation",
        description:
          "Alert requesters when a purchase order needs revision or is canceled.",
        module: "Purchase Order",
        enabled: true,
        delivery: "Instant",
      },
      {
        id: "receipt_confirmation",
        title: "Receipt confirmation and discrepancy",
        description:
          "Send updates when receipt is confirmed, partially received, or mismatched.",
        module: "Receipt",
        enabled: true,
        delivery: "Suggested",
      },
      {
        id: "wo_ready_process",
        title: "Work Order ready to process",
        description:
          "Notify planners and assignees when planned dates are set and work is ready to begin.",
        module: "Work Order",
        enabled: false,
        delivery: "Suggested",
      },
      {
        id: "rfq_quote_update",
        title: "RFQ and quote status update",
        description:
          "Inform commercial and procurement teams when RFQ, quote, or approval status changes.",
        module: "Sales",
        enabled: true,
        delivery: "Daily Digest",
      },
      {
        id: "daily_digest",
        title: "Daily operational digest",
        description:
          "Summarize approvals, receipts, routing exceptions, and pending work in one digest.",
        module: "Cross Module",
        enabled: true,
        delivery: "Daily Digest",
      },
    ],
  },
  {
    id: "push",
    title: "Push Notifications",
    description:
      "Send actionable alerts to mobile or desktop push so users can respond quickly to approval and execution events.",
    items: [
      {
        id: "pending_approval_task",
        title: "Pending approval task",
        description:
          "Push approvers immediately when a purchase order, material request, or role change needs action.",
        module: "Approvals",
        enabled: true,
        delivery: "Instant",
      },
      {
        id: "routing_delay_blocked",
        title: "Routing delay or blocked stage",
        description:
          "Alert the responsible team when a routing stage is overdue or progress is blocked.",
        module: "Routing Stages",
        enabled: true,
        delivery: "Only High Priority",
      },
      {
        id: "outsource_assignment_update",
        title: "Outsource assignment and vendor update",
        description:
          "Notify owners when vendor assignment, PO linkage, or outsource details change.",
        module: "Outsource Detail",
        enabled: true,
        delivery: "Suggested",
      },
      {
        id: "material_shortage_alert",
        title: "Material shortage and request escalation",
        description:
          "Push urgent stock shortage alerts and approved material request escalations.",
        module: "Material Request",
        enabled: true,
        delivery: "Only Critical",
      },
      {
        id: "quote_response_received",
        title: "Quote response received",
        description:
          "Alert the commercial team when a new quote response or customer feedback arrives.",
        module: "Quotes",
        enabled: false,
        delivery: "Suggested",
      },
    ],
  },
  {
    id: "in_app",
    title: "In-App Notifications",
    description:
      "Show contextual notifications inside the platform so users can follow task status without leaving the workflow.",
    items: [
      {
        id: "status_transition",
        title: "Status transition updates",
        description:
          "Notify when purchase orders, work orders, receipts, and RFQs change status.",
        module: "Cross Module",
        enabled: true,
        delivery: "Suggested",
      },
      {
        id: "comments_mentions",
        title: "Comments and mentions",
        description:
          "Show notifications when a user is mentioned in approval notes, receipt notes, or request discussions.",
        module: "Collaboration",
        enabled: true,
        delivery: "Instant",
      },
      {
        id: "document_uploaded",
        title: "Document upload and replacement",
        description:
          "Notify users when invoices, packing lists, delivery notes, or proof documents are added or replaced.",
        module: "Documents",
        enabled: true,
        delivery: "Suggested",
      },
      {
        id: "assignment_changes",
        title: "Assignment and responsibility changes",
        description:
          "Show updates when a user is assigned to a group, role, purchase order, or work order responsibility.",
        module: "Administration",
        enabled: true,
        delivery: "Instant",
      },
      {
        id: "system_announcements",
        title: "System announcements and release notes",
        description:
          "Highlight platform maintenance, new features, and important admin notices.",
        module: "System",
        enabled: true,
        delivery: "Only High Priority",
      },
    ],
  },
  {
    id: "realtime",
    title: "Real-Time Notifications",
    description:
      "Control live notification behavior for browser toasts, sounds, task badges, and urgent alerts while users are online.",
    items: [
      {
        id: "browser_toast",
        title: "Desktop toast notifications",
        description:
          "Show browser toast alerts for approvals, receipt confirmations, and urgent exceptions.",
        module: "Real-Time",
        enabled: true,
        delivery: "Suggested",
      },
      {
        id: "sound_alert",
        title: "Notification sound",
        description:
          "Play a sound for new tasks, urgent delays, and critical approval requests.",
        module: "Real-Time",
        enabled: true,
        delivery: "Only High Priority",
      },
      {
        id: "header_badge",
        title: "Unread badge counter",
        description:
          "Keep the top-header notification badge synced with unread items across the system.",
        module: "Real-Time",
        enabled: true,
        delivery: "Suggested",
      },
      {
        id: "focus_mode",
        title: "Focus mode filtering",
        description:
          "Reduce interruptions by limiting live popups to critical approvals and blocked operations.",
        module: "Real-Time",
        enabled: false,
        delivery: "Only Critical",
      },
    ],
  },
];

const cloneNotificationSettings = (settings = DEFAULT_NOTIFICATION_SETTINGS) =>
  settings.map((section) => ({
    ...section,
    items: section.items.map((item) => ({ ...item })),
  }));

const NOTIFICATION_CATEGORY_OPTIONS = [
  { id: "approvals", label: "Approvals" },
  { id: "operations", label: "Operations" },
  { id: "documents", label: "Documents" },
  { id: "collaboration", label: "Collaboration" },
  { id: "system_updates", label: "System Updates" },
];

const DEFAULT_NOTIFICATION_CENTER_PREFERENCES = {
  hideRead: false,
  pushNotifications: true,
  selectedCategories: NOTIFICATION_CATEGORY_OPTIONS.map(
    (category) => category.id
  ),
};

const DEFAULT_SYSTEM_NOTIFICATIONS = [
  {
    id: "notification-1",
    ruleId: "po_approval_request",
    channel: "in_app",
    category: "approvals",
    timeGroup: "Today",
    unread: true,
    icon: "approvals",
    headline: "Joko submitted PO-202604-0018 for your approval",
    detail:
      "Total amount IDR 82,500,000 from PT Mitra Sejahtera is waiting for your decision.",
    meta: "09:14 WIB • Purchase Order",
  },
  {
    id: "notification-2",
    ruleId: "pending_approval_task",
    channel: "push",
    category: "approvals",
    timeGroup: "Today",
    unread: true,
    icon: "approvals",
    headline: "Material Request MR-202604-004 needs your approval",
    detail:
      "Production requested teak wood panel stock for WO-202604-0012.",
    meta: "08:42 WIB • Material Request",
  },
  {
    id: "notification-3",
    ruleId: "receipt_confirmation",
    channel: "in_app",
    category: "documents",
    timeGroup: "Today",
    unread: true,
    icon: "documents",
    headline: "Receipt confirmed for PO-202603-0013",
    detail:
      "120 pcs were received by Natasha Smith and synced to the linked outsource detail.",
    meta: "07:55 WIB • Receipt",
  },
  {
    id: "notification-4",
    ruleId: "document_uploaded",
    channel: "in_app",
    category: "documents",
    timeGroup: "Today",
    unread: false,
    icon: "documents",
    headline: "New vendor invoice uploaded to PO-202603-0013",
    detail: "Invoice April batch and packing list were added by Joko.",
    meta: "07:18 WIB • Documents",
  },
  {
    id: "notification-5",
    ruleId: "comments_mentions",
    channel: "in_app",
    category: "collaboration",
    timeGroup: "Today",
    unread: true,
    icon: "collaboration",
    headline: "Naomi mentioned you in a Purchase Order revision note",
    detail:
      "Please recheck the tax setup before resubmitting PO-202604-0011.",
    meta: "06:31 WIB • Collaboration",
  },
  {
    id: "notification-6",
    ruleId: "routing_delay_blocked",
    channel: "push",
    category: "operations",
    timeGroup: "This Week",
    unread: true,
    icon: "operations",
    headline: "Routing stage Painting is blocked in WO-202604-0008",
    detail:
      "Completed output is still below planned quantity and the stage is overdue by 1 day.",
    meta: "Yesterday • Routing Stages",
  },
  {
    id: "notification-7",
    ruleId: "outsource_assignment_update",
    channel: "push",
    category: "operations",
    timeGroup: "This Week",
    unread: false,
    icon: "operations",
    headline: "Vendor assignment updated for WO-202604-0008",
    detail:
      "PT Citra Metal is now linked to the outsource detail for routing stages 2 to 4.",
    meta: "Yesterday • Outsource Detail",
  },
  {
    id: "notification-8",
    ruleId: "status_transition",
    channel: "in_app",
    category: "operations",
    timeGroup: "This Week",
    unread: true,
    icon: "operations",
    headline: "WO-202604-0010 is ready to process",
    detail:
      "Planned dates are complete and routing stages can start execution.",
    meta: "2 days ago • Work Order",
  },
  {
    id: "notification-9",
    ruleId: "material_shortage_alert",
    channel: "push",
    category: "operations",
    timeGroup: "This Week",
    unread: true,
    icon: "operations",
    headline: "Material shortage alert for oak veneer sheet",
    detail:
      "Available stock is below required quantity for two active work orders.",
    meta: "2 days ago • Material Request",
  },
  {
    id: "notification-10",
    ruleId: "rfq_quote_update",
    channel: "in_app",
    category: "collaboration",
    timeGroup: "This Week",
    unread: false,
    icon: "collaboration",
    headline: "RFQ-202604-004 was approved and moved to quote creation",
    detail:
      "Commercial team can continue with vendor quotation comparison.",
    meta: "3 days ago • Sales",
  },
  {
    id: "notification-11",
    ruleId: "assignment_changes",
    channel: "in_app",
    category: "collaboration",
    timeGroup: "Older Than Week",
    unread: false,
    icon: "collaboration",
    headline: "Your group membership was updated to Procurement",
    detail:
      "You can now access procurement-related dashboards and notifications.",
    meta: "6 days ago • Administration",
  },
  {
    id: "notification-12",
    ruleId: "system_announcements",
    channel: "in_app",
    category: "system_updates",
    timeGroup: "Older Than Week",
    unread: true,
    icon: "system_updates",
    headline: "System maintenance scheduled for Friday 21:00 WIB",
    detail:
      "Notification delivery and document uploads may be delayed for 30 minutes.",
    meta: "1 week ago • System",
  },
  {
    id: "notification-13",
    ruleId: "po_revision_cancel",
    channel: "in_app",
    category: "approvals",
    timeGroup: "Older Than Week",
    unread: false,
    icon: "approvals",
    headline: "PO-202603-0009 was sent back for revision",
    detail:
      "Delivery date and approval comment must be updated before resubmission.",
    meta: "1 week ago • Purchase Order",
  },
  {
    id: "notification-14",
    ruleId: "daily_digest",
    channel: "email",
    category: "system_updates",
    timeGroup: "Older Than Week",
    unread: false,
    icon: "system_updates",
    headline: "Daily operational digest is ready",
    detail:
      "You have 3 approvals, 2 receipt confirmations, and 1 delayed routing stage to review.",
    meta: "1 week ago • Daily Digest",
  },
  {
    id: "notification-15",
    ruleId: "browser_toast",
    channel: "realtime",
    category: "system_updates",
    timeGroup: "Older Than Week",
    unread: false,
    icon: "system_updates",
    headline: "Desktop alerts are active for urgent notifications",
    detail:
      "Browser toast alerts will appear for approvals, receipts, and critical delays.",
    meta: "2 weeks ago • Real-Time",
  },
];

const getEnabledNotificationRuleIds = (settings = []) =>
  new Set(
    settings.flatMap((section) =>
      (section.items || [])
        .filter((item) => item.enabled)
        .map((item) => item.id)
    )
  );

const LANGUAGE_OPTIONS = [
  { id: "en", shortLabel: "EN", label: "English", flag: "🇺🇸" },
  { id: "id", shortLabel: "ID", label: "Bahasa Indonesia", flag: "🇮🇩" },
];

const TRANSLATIONS = {
  en: {
    sidebar: {
      dashboard: "Dashboard",
      product: "Product",
      product_catalog: "Product Catalog",
      custom_product_request: "Custom Product Request",
      sales: "Sales",
      request_for_quotes: "Request for Quotes",
      quotes: "Quotes",
      orders: "Orders",
      invoices: "Invoices",
      customers: "Customers",
      resources: "Resources",
      material_request: "Material Request",
      manufacturing: "Manufacturing",
      analytics: "Analytics",
      reports: "Reports",
      financing: "Domestic Financing",
      work_order: "Work Order",
      purchase_order: "Purchase Order",
      bill_of_materials: "Bill of Materials",
      routing: "Routing",
      administration: "Administration",
      user_management: "User Management",
      fx_management: "FX Management",
      notification_settings: "Notification Settings",
      company_settings: "Company Settings",
      labamu_staff: "Labamu Staff",
      user_guide: "User Guide",
    },
    role: {
      owner: "Owner",
    },
    message: {
      under_construction: "This module is under construction",
    },
    work_order: {
      title: "Work Order",
      settings: "Settings",
      summary: {
        not_started: "Not Started",
        ready_to_process: "Ready to Process",
        in_progress: "In Progress",
        completed: "Completed",
        canceled: "Canceled",
      },
    },
    purchase_order: {
      title: "Purchase Order",
      settings: "Settings",
      new: "New PO",
    },
  },
  id: {
    sidebar: {
      dashboard: "Dasbor",
      product: "Produk",
      product_catalog: "Katalog Produk",
      custom_product_request: "Permintaan Produk Kustom",
      sales: "Penjualan",
      request_for_quotes: "Permintaan Penawaran",
      quotes: "Penawaran",
      orders: "Pesanan",
      invoices: "Invoice",
      customers: "Pelanggan",
      resources: "Sumber Daya",
      material_request: "Permintaan Material",
      manufacturing: "Manufaktur",
      analytics: "Analitik",
      reports: "Laporan",
      financing: "Pembiayaan Domestik",
      work_order: "Perintah Kerja",
      purchase_order: "Purchase Order",
      bill_of_materials: "Daftar Material",
      routing: "Rute Produksi",
      administration: "Administrasi",
      user_management: "Manajemen Pengguna",
      fx_management: "Manajemen FX",
      notification_settings: "Pengaturan Notifikasi",
      company_settings: "Pengaturan Perusahaan",
      labamu_staff: "Staf Labamu",
      user_guide: "Panduan Pengguna",
    },
    role: {
      owner: "Pemilik",
    },
    message: {
      under_construction: "Modul ini sedang dalam pengembangan",
    },
    work_order: {
      title: "Perintah Kerja",
      settings: "Pengaturan",
      summary: {
        not_started: "Belum Dimulai",
        ready_to_process: "Siap Diproses",
        in_progress: "Sedang Berjalan",
        completed: "Selesai",
        canceled: "Dibatalkan",
      },
    },
    purchase_order: {
      title: "Purchase Order",
      settings: "Pengaturan",
      new: "PO Baru",
    },
  },
};

const getTranslation = (language, key, fallback = "") => {
  const resolved = key
    .split(".")
    .reduce(
      (acc, part) => (acc && acc[part] !== undefined ? acc[part] : undefined),
      TRANSLATIONS[language]
    );
  if (resolved !== undefined) return resolved;
  const fallbackResolved = key
    .split(".")
    .reduce(
      (acc, part) => (acc && acc[part] !== undefined ? acc[part] : undefined),
      TRANSLATIONS.en
    );
  return fallbackResolved !== undefined ? fallbackResolved : fallback;
};

const INDONESIAN_EXACT_TEXT = {
  MANUFACTURING: "MANUFAKTUR",
  Dashboard: "Dasbor",
  Product: "Produk",
  Sales: "Penjualan",
  Resources: "Sumber Daya",
  Manufacturing: "Manufaktur",
  Analytics: "Analitik",
  "Domestic Financing": "Pembiayaan Domestik",
  "Work Order": "Perintah Kerja",
  "Purchase Order": "Purchase Order",
  "Bill of Materials": "Daftar Material",
  Routing: "Rute Produksi",
  Administration: "Administrasi",
  "User Management": "Manajemen Pengguna",
  "FX Management": "Manajemen FX",
  "Notification Settings": "Pengaturan Notifikasi",
  "Company Settings": "Pengaturan Perusahaan",
  "Labamu Staff": "Staf Labamu",
  "All Channels": "Semua Kanal",
  "Restore Defaults": "Pulihkan Default",
  "Search notification, module, or rule": "Cari notifikasi, modul, atau aturan",
  "Operational approvals and execution alerts across procurement, manufacturing, sales, and administration.":
    "Peringatan persetujuan dan eksekusi operasional di seluruh pengadaan, manufaktur, penjualan, dan administrasi.",
  "Active Rules": "Aturan Aktif",
  "Critical Alerts": "Peringatan Kritis",
  "Digest Rules": "Aturan Ringkasan",
  "Live Alerts": "Peringatan Langsung",
  Rules: "Aturan",
  Module: "Modul",
  "No notification rules found.": "Tidak ada aturan notifikasi yang ditemukan.",
  "Adjust the search or channel filter to see more notification configurations.":
    "Sesuaikan pencarian atau filter kanal untuk melihat lebih banyak konfigurasi notifikasi.",
  "Email Notifications": "Notifikasi Email",
  "Push Notifications": "Notifikasi Push",
  "In-App Notifications": "Notifikasi Dalam Aplikasi",
  "Real-Time Notifications": "Notifikasi Real-Time",
  Notification: "Notifikasi",
  All: "Semua",
  Approvals: "Persetujuan",
  Operations: "Operasional",
  Documents: "Dokumen",
  Collaboration: "Kolaborasi",
  "System Updates": "Pembaruan Sistem",
  "Mark All as Read": "Tandai Semua Sudah Dibaca",
  "No new notifications": "Tidak ada notifikasi baru",
  "You're all caught up.": "Semua notifikasi sudah tertangani.",
  "View All Notifications": "Lihat Semua Notifikasi",
  "Show Less": "Tampilkan Lebih Sedikit",
  "Hide All Read": "Sembunyikan Semua yang Sudah Dibaca",
  "Filter Preferences": "Preferensi Filter",
  "Notification Filters": "Filter Notifikasi",
  "Kindly indicate the notifications you wish to receive.":
    "Silakan tentukan notifikasi yang ingin Anda terima.",
  "All Notifications": "Semua Notifikasi",
  "Deselected notifications will not show up in your notification center.":
    "Notifikasi yang tidak dipilih tidak akan muncul di pusat notifikasi Anda.",
  Today: "Hari Ini",
  "This Week": "Minggu Ini",
  "Older Than Week": "Lebih Lama dari Seminggu",
  User: "Pengguna",
  Role: "Peran",
  Group: "Grup",
  Users: "Pengguna",
  Roles: "Peran",
  Groups: "Grup",
  Owner: "Pemilik",
  Settings: "Pengaturan",
  "Not Started": "Belum Dimulai",
  "Ready to Process": "Siap Diproses",
  "In Progress": "Sedang Berjalan",
  Completed: "Selesai",
  Canceled: "Dibatalkan",
  "Need Revision": "Perlu Revisi",
  Draft: "Draf",
  Issued: "Diterbitkan",
  Approved: "Disetujui",
  Rejected: "Ditolak",
  Pending: "Menunggu",
  Waiting: "Menunggu",
  "Waiting for Approval": "Menunggu Persetujuan",
  "Partially Received": "Diterima Sebagian",
  "Material Request": "Permintaan Material",
  "Request Material": "Minta Material",
  "Set Planned Date": "Atur Tanggal Rencana",
  Continue: "Lanjutkan",
  "Confirm Action": "Konfirmasi Tindakan",
  "Are you sure you want to proceed?": "Apakah Anda yakin ingin melanjutkan?",
  "You cannot change the outsourced steps later":
    "Anda tidak dapat mengubah tahapan outsourcing nanti",
  "after the work order is marked as ready to process.":
    "setelah perintah kerja ditandai siap diproses.",
  "Yes, Proceed": "Ya, Lanjutkan",
  "Work Order No.": "No. Perintah Kerja",
  "Order Number": "Nomor Pesanan",
  Product: "Produk",
  Qty: "Jumlah",
  Quantity: "Jumlah",
  Priority: "Prioritas",
  "Planned Start Date": "Tanggal Mulai Rencana",
  "Planned End Date": "Tanggal Selesai Rencana",
  "Created By": "Dibuat Oleh",
  Status: "Status",
  "Search work order number": "Cari nomor perintah kerja",
  "Search PO number, vendor": "Cari nomor PO atau vendor",
  "No work orders found.": "Tidak ada work order ditemukan.",
  "No purchase orders found.": "Tidak ada purchase order ditemukan.",
  "Work Order Detail": "Detail Perintah Kerja",
  "Edit Work Order": "Ubah Perintah Kerja",
  "Created On": "Dibuat Pada",
  "Target Product": "Target Produk",
  "Bill of Material": "Daftar Material",
  No: "No",
  Material: "Material",
  "Required Qty": "Jumlah Dibutuhkan",
  "Requested Qty": "Jumlah Diminta",
  "Received Qty": "Jumlah Diterima",
  "Routing Stages": "Routing Stages",
  "Allow Outsourcing": "Izinkan Outsourcing",
  Step: "Tahap",
  Routing: "Rute",
  Operation: "Operasi",
  "Yet to Start": "Belum Dimulai",
  Progress: "Progres",
  Outsourced: "Dialihdayakan",
  Hybrid: "Hibrida",
  Manage: "Kelola",
  "Waiting for items": "Menunggu item",
  "Outsource Detail": "Detail Outsourcing",
  "Needs Assignment": "Butuh Penugasan",
  "Assign Vendor": "Tugaskan Vendor",
  "Outsourced Stages": "Tahap Outsourcing",
  "Vendor Name": "Nama Vendor",
  "Assigned Output": "Output Ditugaskan",
  "Received Output": "Output Diterima",
  "Est. Recv Date": "Estimasi Tgl. Terima",
  "Received Date": "Tanggal Diterima",
  "No vendor assigned yet": "Belum ada vendor yang ditugaskan",
  "Create New PO": "Buat PO Baru",
  "Select Existing PO": "Pilih PO yang Sudah Ada",
  "More actions": "Aksi lainnya",
  "PO Approved": "PO Disetujui",
  "Edit Details": "Ubah Detail",
  "Remove Assignment": "Hapus Penugasan",
  "Cancel Vendor": "Batalkan Vendor",
  "Receipt History": "Riwayat Penerimaan",
  "Confirm Receipt": "Konfirmasi Penerimaan",
  "You can now allow outsourcing for selected stages.":
    "Anda sekarang dapat mengizinkan outsourcing untuk tahap yang dipilih.",
  "Each selected stage can be handled by external vendors or together with your internal team.":
    "Setiap tahap yang dipilih dapat dikerjakan oleh vendor eksternal atau bersama tim internal Anda.",
  "Select Existing Purchase Order": "Pilih Purchase Order yang Sudah Ada",
  "Select purchase order": "Pilih purchase order",
  "Edit Assigned Vendor": "Ubah Vendor yang Ditugaskan",
  "Add Assigned Vendor": "Tambah Vendor yang Ditugaskan",
  "Select Vendor": "Pilih Vendor",
  "Select purchase order (optional)": "Pilih purchase order (opsional)",
  "Planned Start - End Date": "Rencana Tanggal Mulai - Selesai",
  "Actual Start - End Date": "Aktual Tanggal Mulai - Selesai",
  "Est. Received Date": "Estimasi Tanggal Diterima",
  Save: "Simpan",
  Cancel: "Batal",
  "Create Purchase Order": "Buat Purchase Order",
  "PO Date": "Tanggal PO",
  "Expected Delivery Date": "Tanggal Perkiraan Pengiriman",
  Currency: "Mata Uang",
  "Unit Price": "Harga Satuan",
  "Tax (%)": "Pajak (%)",
  "Additional Fees": "Biaya Tambahan",
  Notes: "Catatan",
  Terms: "Syarat",
  "Save Purchase Order": "Simpan Purchase Order",
  "Save as Draft": "Simpan sebagai Draf",
  "Receive Output": "Terima Output",
  "Receive Vendor Output": "Terima Output Vendor",
  "Received Quantity": "Jumlah Diterima",
  "Upload Proof Document": "Unggah Dokumen Bukti",
  Update: "Perbarui",
  Download: "Unduh",
  Edit: "Ubah",
  Delete: "Hapus",
  Remove: "Hapus",
  Date: "Tanggal",
  Document: "Dokumen",
  "No receipts found.": "Tidak ada riwayat penerimaan.",
  "Created Date": "Tanggal Dibuat",
  "Remove Filter": "Hapus Filter",
  Approvers: "Penyetuju",
  Approver: "Penyetuju",
  "Purchase Order Detail": "Detail Purchase Order",
  "Approval Settings": "Pengaturan Persetujuan",
  "Activate Approval Setting": "Aktifkan Pengaturan Persetujuan",
  "Enable approval workflow for Purchase Order":
    "Aktifkan alur persetujuan untuk Purchase Order",
  "Require Comment for Approval": "Wajibkan Komentar untuk Persetujuan",
  "Edit PO": "Ubah PO",
  Print: "Cetak",
  "Revision Requested": "Permintaan Revisi",
  "Purchase Order Canceled": "Purchase Order Dibatalkan",
  "PO Details": "Detail PO",
  Receipt: "Penerimaan",
  Documents: "Dokumen",
  Logs: "Log",
  "Vendor Information": "Informasi Vendor",
  "Phone Number": "Nomor Telepon",
  Email: "Email",
  Address: "Alamat",
  "Ship To": "Kirim Ke",
  "Recipient Name": "Nama Penerima",
  Type: "Tipe",
  Image: "Gambar",
  Name: "Nama",
  Description: "Deskripsi",
  "WO Ref": "Referensi WO",
  Subtotal: "Subtotal",
  Fees: "Biaya",
  Total: "Total",
  Filter: "Filter",
  "All Types": "Semua Tipe",
  Spreadsheet: "Spreadsheet",
  Video: "Video",
  Upload: "Unggah",
  "Document Type": "Tipe Dokumen",
  "Uploaded By": "Diunggah Oleh",
  "Date Modified": "Tanggal Diubah",
  "File Size": "Ukuran File",
  Action: "Aksi",
  Activity: "Aktivitas",
  Position: "Posisi",
  Contract: "Kontrak",
  "Delivery Note": "Surat Jalan",
  "Packing List": "Daftar Pengepakan",
  Invoice: "Invoice",
  "Quotation (Vendor)": "Penawaran (Vendor)",
  "Contract / Agreement": "Kontrak / Perjanjian",
  Other: "Lainnya",
  Primary: "Utama",
  Document: "Dokumen",
  "Cancel PO": "Batalkan PO",
  Approve: "Setujui",
  Okay: "Oke",
  "Submit PO?": "Ajukan PO?",
  "Yes, Submit": "Ya, Ajukan",
  "Keep Editing": "Lanjut Mengedit",
  "Edit Document": "Ubah Dokumen",
  Submit: "Kirim",
  "Approve Purchase Order": "Setujui Purchase Order",
  "Cancel Purchase Order": "Batalkan Purchase Order",
  "Ask for Revision": "Minta Revisi",
  "Submit PO": "Ajukan PO",
  "Approval Logs": "Log Persetujuan",
  "Activity Logs": "Log Aktivitas",
  "Requested By": "Diminta Oleh",
  "Requested At": "Diminta Pada",
  Comments: "Komentar",
  "Purchase Order Information": "Informasi Purchase Order",
  "Purchase Order Date": "Tanggal Purchase Order",
  "Used for all prices in this purchase order.":
    "Digunakan untuk semua harga pada purchase order ini.",
  "The date when this purchase order is created.":
    "Tanggal saat purchase order ini dibuat.",
  "Estimated receiving date from the vendor.":
    "Perkiraan tanggal penerimaan dari vendor.",
  "Use Company Detail": "Gunakan Detail Perusahaan",
  "The recipient name for this delivery.":
    "Nama penerima untuk pengiriman ini.",
  "The destination address for the order.": "Alamat tujuan untuk pesanan ini.",
  "Purchase Order Lines": "Baris Purchase Order",
  "Add PO Line": "Tambah Baris PO",
  "No purchase order lines added.": "Belum ada baris purchase order.",
  "No purchase order lines added yet. Click “Add PO Line” to get started.":
    'Belum ada baris purchase order. Klik "Tambah Baris PO" untuk memulai.',
  "Notes & Terms": "Catatan & Syarat",
  Price: "Harga",
  "Add Fee": "Tambah Biaya",
  Tax: "Pajak",
  Summary: "Ringkasan",
  "Total Amount": "Total Nilai",
  "Fee Name": "Nama Biaya",
  Amount: "Jumlah",
  Fee: "Biaya",
  Images: "Gambar",
  "Image is taken from the selected work order.":
    "Gambar diambil dari perintah kerja yang dipilih.",
  "You can upload up to 5 images.": "Anda dapat mengunggah hingga 5 gambar.",
  "Add Purchase Order Line": "Tambah Baris Purchase Order",
  "Edit Purchase Order Line": "Ubah Baris Purchase Order",
  Manual: "Manual",
  "Add a product line manually by filling in the product details.":
    "Tambahkan baris produk secara manual dengan mengisi detail produk.",
  "Select a material and adjust the editable fields as needed.":
    "Pilih material dan sesuaikan kolom yang dapat diedit sesuai kebutuhan.",
  "Use an available work order line and adjust the editable fields as needed.":
    "Gunakan baris perintah kerja yang tersedia dan sesuaikan kolom yang dapat diedit sesuai kebutuhan.",
  "SKU / Code": "SKU / Kode",
  "Select material": "Pilih material",
  "No materials available.": "Tidak ada material yang tersedia.",
  "Select work order": "Pilih perintah kerja",
  "This item is linked to a work order and cannot be changed.":
    "Item ini terhubung ke perintah kerja dan tidak dapat diubah.",
  "No work orders available for the selected vendor.":
    "Tidak ada perintah kerja yang tersedia untuk vendor yang dipilih.",
  "Save Changes": "Simpan Perubahan",
  "Save as Draft?": "Simpan sebagai Draf?",
  "Fill at least one field in the form to proceed.":
    "Isi setidaknya satu kolom dalam formulir untuk melanjutkan.",
  "Yes, Submit": "Ya, Ajukan",
  "This PO will be submitted for approval.":
    "PO ini akan diajukan untuk persetujuan.",
  "This PO will be automatically approved upon submission.":
    "PO ini akan otomatis disetujui saat diajukan.",
  "Discard changes?": "Buang perubahan?",
  "You have unsaved changes in this purchase order. Are you sure you want to leave this page?":
    "Anda memiliki perubahan yang belum disimpan pada purchase order ini. Yakin ingin meninggalkan halaman ini?",
  "Discard Changes": "Buang Perubahan",
  "Add New Purchase Order": "Tambah Purchase Order Baru",
  "Edit Purchase Order": "Ubah Purchase Order",
  "Select an existing vendor or add a new one.":
    "Pilih vendor yang sudah ada atau tambahkan vendor baru.",
  "Type to search or add vendor": "Ketik untuk mencari atau menambahkan vendor",
  "Input email": "Masukkan email",
  "Input vendor address": "Masukkan alamat vendor",
  "Input recipient name": "Masukkan nama penerima",
  "Input address": "Masukkan alamat",
  "Edit line": "Ubah baris",
  "This work order line cannot be removed":
    "Baris perintah kerja ini tidak dapat dihapus",
  "Remove line": "Hapus baris",
  "Input notes": "Masukkan catatan",
  "Input terms": "Masukkan syarat",
  "Input fee name": "Masukkan nama biaya",
  "Search country or code...": "Cari negara atau kode...",
  "Input phone number": "Masukkan nomor telepon",
  "Search by name or position...": "Cari berdasarkan nama atau jabatan...",
  "Approvers must provide a comment when approving or rejecting":
    "Penyetuju harus memberikan komentar saat menyetujui atau menolak",
  "Select users who can approve Purchase Orders":
    "Pilih pengguna yang dapat menyetujui Purchase Orders",
  "No user found.": "Pengguna tidak ditemukan.",
  "Settings saved successfully": "Pengaturan berhasil disimpan",
  "Marked as ready to process": "Ditandai siap diproses",
  "Purchase order draft saved successfully":
    "Draf purchase order berhasil disimpan",
  "Purchase order submitted for approval":
    "Purchase order berhasil diajukan untuk persetujuan",
  "Purchase order approved successfully": "Purchase order berhasil disetujui",
  "Purchase order approved": "Purchase order disetujui",
  "Purchase order canceled": "Purchase order dibatalkan",
  "Revision has been requested": "Revisi telah diminta",
  "Comment is required.": "Komentar wajib diisi.",
  "Add a reason for canceling this purchase order.":
    "Tambahkan alasan pembatalan purchase order ini.",
  "Add revision notes for the requester.":
    "Tambahkan catatan revisi untuk pemohon.",
  "Comment is required before approving this purchase order.":
    "Komentar wajib diisi sebelum menyetujui purchase order ini.",
  "Add a comment for approval if needed.":
    "Tambahkan komentar persetujuan jika diperlukan.",
  "PO Created": "PO Dibuat",
  "PO Submitted": "PO Diajukan",
  "PO Canceled": "PO Dibatalkan",
  "PO Completed": "PO Selesai",
  "All ordered items have been fully received.":
    "Semua item yang dipesan telah diterima sepenuhnya.",
  "Purchase order has been canceled and will not proceed further.":
    "Purchase order telah dibatalkan dan tidak akan dilanjutkan.",
  "Please update the delivery timeline and review the requested changes before resubmitting this purchase order.":
    "Silakan perbarui jadwal pengiriman dan tinjau perubahan yang diminta sebelum mengajukan ulang purchase order ini.",
  "No Date Set": "Tanggal Belum Diatur",
  "Not Set": "Belum Diatur",
  "Not Defined": "Belum Ditentukan",
  "Search documents": "Cari dokumen",
  "Upload Proof Document": "Unggah Dokumen Bukti",
  "Receipt confirmation is only available when the purchase order status is Issued.":
    "Konfirmasi penerimaan hanya tersedia saat status purchase order adalah Diterbitkan.",
  "Receipt Logs": "Log Penerimaan",
  "Receipt Details": "Detail Penerimaan",
  "Received By": "Diterima Oleh",
  "Proof Document": "Dokumen Bukti",
  "No receipt history yet.": "Belum ada riwayat penerimaan.",
  Item: "Item",
  SKU: "SKU",
  "Item / Product Name": "Nama Item / Produk",
  "Ordered Qty": "Jumlah Dipesan",
  "Remaining Qty": "Sisa Jumlah",
  "Received Item": "Item Diterima",
  "Receive Now": "Terima Sekarang",
  Note: "Catatan",
  "Add note for this receipt": "Tambahkan catatan untuk penerimaan ini",
  "Click to upload file": "Klik untuk mengunggah file",
  "PDF, JPG, or PNG (Max 5MB)": "PDF, JPG, atau PNG (Maks 5MB)",
  "Allowed formats (PDF, JPG, JPEG, PNG, WebP)":
    "Format yang diizinkan (PDF, JPG, JPEG, PNG, WebP)",
  "Allowed formats (JPG, JPEG, PNG, WebP)":
    "Format yang diizinkan (JPG, JPEG, PNG, WebP)",
  "Drag file or browse file": "Tarik file atau telusuri file",
  "Max 1 file, 25MB each": "Maks 1 file, 25MB per file",
  "Max 3 files, 25MB each": "Maks 3 file, 25MB per file",
  "Max size 25MB per file": "Ukuran maksimum 25MB per file",
  "Please choose a file": "Silakan pilih file",
  "File Description": "Deskripsi File",
  "Enter File Description": "Masukkan Deskripsi File",
  "Upload at least one proof document": "Unggah setidaknya satu dokumen bukti",
  "Add description for each proof document":
    "Tambahkan deskripsi untuk setiap dokumen bukti",
  "Description is required": "Deskripsi wajib diisi",
  "You can upload 1 photo.": "Anda dapat mengunggah 1 foto.",
  "Receipt Date & Time": "Tanggal & Waktu Penerimaan",
  "Receipt Number": "Nomor Penerimaan",
  "Received Quantity (This Transaction)": "Jumlah Diterima (Transaksi Ini)",
  "Received Qty": "Jumlah Diterima",
  "Proof Document": "Dokumen Bukti",
  Close: "Tutup",
  Back: "Kembali",
  "Enter receiver name": "Masukkan nama penerima",
  "Upload File": "Unggah File",
  "Accepts any file type, max 10 MB": "Menerima semua jenis file, maks 10 MB",
  "File size exceeds the 10 MB limit": "Ukuran file melebihi batas 10 MB",
  "Receive now cannot exceed remaining qty":
    "Jumlah diterima sekarang tidak boleh melebihi sisa jumlah",
  "Fill at least one Receive Now field to proceed":
    "Isi setidaknya satu kolom Terima Sekarang untuk melanjutkan",
  "Complete Required Information": "Lengkapi Informasi Wajib",
  "Please fill in the required information below before submitting this purchase order.":
    "Silakan isi informasi wajib berikut sebelum mengajukan purchase order ini.",
  "Content for this tab will be added next.":
    "Konten untuk tab ini akan ditambahkan berikutnya.",
  "Receipt Confirmed": "Penerimaan Dikonfirmasi",
  "Receipt confirmed successfully": "Penerimaan berhasil dikonfirmasi",
  "Receipt confirmed successfully. Purchase order marked as completed":
    "Penerimaan berhasil dikonfirmasi. Purchase order ditandai selesai",
  "Create Purchase Order": "Buat Purchase Order",
  "Fill in the details to generate a PO for the outsourced item.":
    "Isi detail untuk membuat PO bagi item outsourcing.",
  "Order Information": "Informasi Pesanan",
  "No receipts found.": "Tidak ada riwayat penerimaan.",
  "This module is under construction": "Modul ini sedang dalam pengembangan",
};

const INDONESIAN_FRAGMENT_REPLACEMENTS = [
  ["Waiting for Approval", "Menunggu Persetujuan"],
  ["Ready to Process", "Siap Diproses"],
  ["Partially Received", "Diterima Sebagian"],
  ["Work Order", "Perintah Kerja"],
  ["work order", "perintah kerja"],
  ["Received Date", "Tanggal Diterima"],
  ["Expected Delivery Date", "Tanggal Perkiraan Pengiriman"],
  ["Created Date", "Tanggal Dibuat"],
  ["Created By", "Dibuat Oleh"],
  ["Uploaded By", "Diunggah Oleh"],
  ["Date Modified", "Tanggal Diubah"],
  ["File Size", "Ukuran File"],
  ["Document Type", "Tipe Dokumen"],
  ["Recipient Name", "Nama Penerima"],
  ["Phone Number", "Nomor Telepon"],
  ["Vendor Name", "Nama Vendor"],
  ["Assigned Output", "Output Ditugaskan"],
  ["Received Output", "Output Diterima"],
  ["Unit Price", "Harga Satuan"],
  ["Additional Fees", "Biaya Tambahan"],
  ["Notes: ", "Catatan: "],
  ["Tax (", "Pajak ("],
  ["Input ", "Masukkan "],
  ["Search ", "Cari "],
  ["Drag file or ", "Tarik file atau "],
  ["browse file", "telusuri file"],
];

const INDONESIAN_DYNAMIC_TEXT = [
  {
    pattern: /^Uploaded by (.+) on (.+)$/i,
    replacer: (_, name, date) => `Diunggah oleh ${name} pada ${date}`,
  },
  {
    pattern: /^Remaining to receive: (\d+) pcs$/i,
    replacer: (_, qty) => `Sisa untuk diterima: ${qty} pcs`,
  },
  {
    pattern: /^Step (\d+) to (\d+)$/i,
    replacer: (_, start, end) => `Tahap ${start} sampai ${end}`,
  },
  {
    pattern: /^Step (\d+)$/i,
    replacer: (_, step) => `Tahap ${step}`,
  },
  {
    pattern: /^\+ Add "(.+)" as new vendor$/i,
    replacer: (_, vendor) => `+ Tambah "${vendor}" sebagai vendor baru`,
  },
  {
    pattern: /^([^:]+): Received (\d+) pcs$/i,
    replacer: (_, label, received) => `${label}: Diterima ${received} pcs`,
  },
  {
    pattern: /^from (\d+) rows$/i,
    replacer: (_, count) => `dari ${count} baris`,
  },
];

const LOCALIZABLE_ATTRIBUTES = ["placeholder", "title", "aria-label"];

const preserveWhitespace = (input, replacement) => {
  const leading = input.match(/^\s*/)?.[0] || "";
  const trailing = input.match(/\s*$/)?.[0] || "";
  return `${leading}${replacement}${trailing}`;
};

const translateToIndonesian = (value) => {
  if (typeof value !== "string" || value.length === 0) return value;

  const trimmedValue = value.trim();
  const exactMatch =
    INDONESIAN_EXACT_TEXT[value] || INDONESIAN_EXACT_TEXT[trimmedValue];
  if (exactMatch) {
    return preserveWhitespace(value, exactMatch);
  }

  let localized = value;

  INDONESIAN_DYNAMIC_TEXT.forEach(({ pattern, replacer }) => {
    localized = localized.replace(pattern, replacer);
  });

  INDONESIAN_FRAGMENT_REPLACEMENTS.forEach(([source, target]) => {
    if (localized.includes(source)) {
      localized = localized.split(source).join(target);
    }
  });

  return localized;
};

const localizeVisibleText = (value, language) => {
  if (typeof value !== "string") return value;
  if (language !== "id") return value;
  return translateToIndonesian(value);
};

const shouldSkipTextNode = (node) => {
  if (!node?.nodeValue || !node.nodeValue.trim()) return true;
  const parentTag = node.parentElement?.tagName;
  return (
    parentTag === "STYLE" || parentTag === "SCRIPT" || parentTag === "NOSCRIPT"
  );
};

const applyDomLocalization = (rootNode, language) => {
  if (
    !rootNode ||
    typeof document === "undefined" ||
    typeof NodeFilter === "undefined"
  )
    return;

  const textWalker = document.createTreeWalker(rootNode, NodeFilter.SHOW_TEXT, {
    acceptNode: (node) =>
      shouldSkipTextNode(node)
        ? NodeFilter.FILTER_REJECT
        : NodeFilter.FILTER_ACCEPT,
  });

  let currentTextNode = textWalker.nextNode();
  while (currentTextNode) {
    const currentNodeValue = currentTextNode.nodeValue;
    const storedOriginalText =
      currentTextNode.__labamuOriginalText ?? currentNodeValue;
    const translatedStoredText = translateToIndonesian(storedOriginalText);

    if (language === "id") {
      if (
        currentTextNode.__labamuOriginalText === undefined ||
        currentNodeValue !== translatedStoredText
      ) {
        currentTextNode.__labamuOriginalText = currentNodeValue;
      }

      const nextTextValue = translateToIndonesian(
        currentTextNode.__labamuOriginalText
      );
      if (currentTextNode.nodeValue !== nextTextValue) {
        currentTextNode.nodeValue = nextTextValue;
      }
    } else {
      if (
        currentNodeValue === translatedStoredText &&
        currentNodeValue !== storedOriginalText
      ) {
        currentTextNode.nodeValue = storedOriginalText;
      }
      currentTextNode.__labamuOriginalText = currentTextNode.nodeValue;
    }

    currentTextNode = textWalker.nextNode();
  }

  rootNode.querySelectorAll("*").forEach((element) => {
    LOCALIZABLE_ATTRIBUTES.forEach((attribute) => {
      const currentAttributeValue = element.getAttribute(attribute);
      const originalAttributeKey = `__labamuOriginal${attribute.replace(
        /[^a-z0-9]/gi,
        ""
      )}`;

      if (currentAttributeValue === null) return;

      const storedOriginalAttribute =
        element[originalAttributeKey] ?? currentAttributeValue;
      const translatedStoredAttribute = translateToIndonesian(
        storedOriginalAttribute
      );

      if (language === "id") {
        if (
          element[originalAttributeKey] === undefined ||
          currentAttributeValue !== translatedStoredAttribute
        ) {
          element[originalAttributeKey] = currentAttributeValue;
        }

        const nextAttributeValue = translateToIndonesian(
          element[originalAttributeKey]
        );
        if (currentAttributeValue !== nextAttributeValue) {
          element.setAttribute(attribute, nextAttributeValue);
        }
      } else {
        if (
          currentAttributeValue === translatedStoredAttribute &&
          currentAttributeValue !== storedOriginalAttribute
        ) {
          element.setAttribute(attribute, storedOriginalAttribute);
        }
        element[originalAttributeKey] = element.getAttribute(attribute);
      }
    });
  });
};

const UPLOAD_MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024;
const ALLOWED_DOCUMENT_EXTENSIONS = ["pdf", "jpg", "jpeg", "png", "webp"];
const ALLOWED_IMAGE_EXTENSIONS = ["jpg", "jpeg", "png", "webp"];
const MAX_PROOF_UPLOAD_FILES = 3;
const FILE_DESCRIPTION_MAX_LENGTH = 40;

const getFileExtension = (fileName = "") =>
  String(fileName).split(".").pop()?.toLowerCase() || "";

const formatUploadFileSize = (sizeBytes = 0) => {
  const value = Number(sizeBytes) || 0;
  if (value <= 0) return "-";
  if (value >= 1024 * 1024) return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  if (value >= 1024) return `${Math.max(1, Math.round(value / 1024))} KB`;
  return `${value} B`;
};

const getUploadDocumentKind = (fileName = "") => {
  const extension = getFileExtension(fileName);
  if (extension === "pdf") return "pdf";
  if (ALLOWED_IMAGE_EXTENSIONS.includes(extension)) return "image";
  return "document";
};

const validateUploadFile = (
  file,
  allowedExtensions = ALLOWED_DOCUMENT_EXTENSIONS,
  maxSizeBytes = UPLOAD_MAX_FILE_SIZE_BYTES,
  invalidFormatMessage = "Allowed formats (PDF, JPG, JPEG, PNG, WebP)"
) => {
  if (!file) return "Please choose a file";

  const extension = getFileExtension(file.name);
  const mimeType = String(file.type || "").toLowerCase();
  const mimeMatches = allowedExtensions.some((allowedExt) => {
    if (allowedExt === "pdf") return mimeType === "application/pdf";
    if (["jpg", "jpeg", "png", "webp"].includes(allowedExt))
      return mimeType.startsWith("image/");
    return false;
  });

  if (!allowedExtensions.includes(extension) && !mimeMatches) {
    return invalidFormatMessage;
  }

  if ((Number(file.size) || 0) > maxSizeBytes) {
    return "Max size 25MB per file";
  }

  return "";
};

const createUploadDocumentRecord = (file, overrides = {}) => {
  if (!file) return null;

  let previewUrl =
    overrides.previewUrl !== undefined ? overrides.previewUrl : "";

  if (
    !previewUrl &&
    typeof URL !== "undefined" &&
    typeof URL.createObjectURL === "function" &&
    file &&
    typeof file === "object"
  ) {
    try {
      previewUrl = URL.createObjectURL(file);
    } catch (error) {
      previewUrl = "";
    }
  }

  return {
    id:
      overrides.id ||
      `upload-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name: file.name || "Attachment",
    description: overrides.description ?? "",
    sizeBytes: Number(file.size) || 0,
    size: overrides.size || formatUploadFileSize(file.size),
    type: overrides.type || getUploadDocumentKind(file.name),
    previewUrl,
    ...overrides,
  };
};

const normalizeProofDocuments = (documents = [], fallbackProof = "") => {
  if (Array.isArray(documents) && documents.length > 0) {
    return documents
      .map((doc, index) => {
        if (!doc) return null;
        const name = doc.name || doc.fileName || `Attachment-${index + 1}`;
        return {
          id: doc.id || `proof-${index}-${name}`,
          name,
          description: doc.description || doc.label || "Proof Document",
          type: doc.type || getUploadDocumentKind(name),
          sizeBytes: Number(doc.sizeBytes) || 0,
          size: doc.size || formatUploadFileSize(doc.sizeBytes),
          previewUrl: doc.previewUrl || "",
        };
      })
      .filter(Boolean);
  }

  if (fallbackProof) {
    return [
      {
        id: `proof-${fallbackProof}`,
        name: fallbackProof,
        description: "Proof Document",
        type: getUploadDocumentKind(fallbackProof),
        sizeBytes: 0,
        size: "-",
        previewUrl: "",
      },
    ];
  }

  return [];
};

const getDocumentPrimaryLabel = (doc) =>
  doc?.description?.trim() || doc?.name || "-";
const getDocumentSecondaryLabel = (doc) =>
  doc?.description?.trim() ? doc?.name || "-" : "";

const createSyntheticInputEvent = (value) => ({
  target: { value },
  currentTarget: { value },
});

const createImageUploadRecord = (fileOrName, overrides = {}) => {
  if (!fileOrName) return null;
  if (typeof fileOrName === "string") {
    return {
      id:
        overrides.id ||
        `image-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      name: fileOrName,
      previewUrl: overrides.previewUrl || "",
      type: "image",
      ...overrides,
    };
  }
  return createUploadDocumentRecord(fileOrName, {
    type: "image",
    ...overrides,
  });
};

const getImageUploadName = (imageRecord) =>
  typeof imageRecord === "string" ? imageRecord : imageRecord?.name || "";

const getImageUploadPreviewUrl = (imageRecord) =>
  typeof imageRecord === "string" ? "" : imageRecord?.previewUrl || "";

const padDateUnit = (value) => String(value).padStart(2, "0");

const parseIsoDateString = (value = "") => {
  if (!value || typeof value !== "string") return null;
  const parts = value.split("-").map((part) => Number(part));
  if (parts.length !== 3 || parts.some((part) => Number.isNaN(part))) {
    return null;
  }
  const [year, month, day] = parts;
  const date = new Date(year, month - 1, day);
  if (
    date.getFullYear() !== year ||
    date.getMonth() !== month - 1 ||
    date.getDate() !== day
  ) {
    return null;
  }
  return date;
};

const formatIsoDateString = (date) => {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) return "";
  return `${date.getFullYear()}-${padDateUnit(date.getMonth() + 1)}-${padDateUnit(
    date.getDate()
  )}`;
};

const DATE_PICKER_MONTHS = [
  "JAN",
  "FEB",
  "MAR",
  "APR",
  "MAY",
  "JUN",
  "JUL",
  "AUG",
  "SEP",
  "OCT",
  "NOV",
  "DEC",
];

const DATE_PICKER_WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const DATE_PICKER_POPOVER_WIDTH = 440;

const buildCalendarDays = (viewDate) => {
  const baseDate =
    viewDate instanceof Date && !Number.isNaN(viewDate.getTime())
      ? viewDate
      : new Date();
  const monthStart = new Date(
    baseDate.getFullYear(),
    baseDate.getMonth(),
    1
  );
  const gridStart = new Date(monthStart);
  gridStart.setDate(monthStart.getDate() - monthStart.getDay());

  return Array.from({ length: 35 }, (_, index) => {
    const date = new Date(gridStart);
    date.setDate(gridStart.getDate() + index);
    return {
      date,
      iso: formatIsoDateString(date),
      day: date.getDate(),
      isCurrentMonth: date.getMonth() === monthStart.getMonth(),
    };
  });
};

// --- DESIGN SYSTEM ---
const LabamuStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@600;700&family=Lato:ital,wght@0,400;0,600;0,700;0,900;1,400&display=swap');

    :root {
      --font-family-base: 'Lato', sans-serif;
      --font-family-display: 'Inter', sans-serif;

      --neutral-background-primary: #F5F5F7;
      --neutral-surface-primary: #FFFFFF;
      --neutral-surface-grey-lighter: #F4F4F4;
      --neutral-surface-grey-darker: #E9E9E9;
      --neutral-surface-reverse: #7E7E7E;

      --neutral-on-surface-primary: #282828;
      --neutral-on-surface-secondary: #7E7E7E;
      --neutral-on-surface-tertiary: #A9A9A9;
      --neutral-on-surface-reverse: #FFFFFF;
      --neutral-on-surface-blue: #006BFF;

      --neutral-line-separator-1: #E9E9E9;
      --neutral-line-separator-2: #D4D4D4;
      --neutral-line-outline: #E9E9E9;
      --neutral-line-border: #E9E9E9;
      --neutral-line-scroller: #E9E9E9;

      --feature-brand-primary: #006BFF;
      --feature-brand-on-primary: #FFFFFF;
      --feature-brand-container: #E6F0FF;
      --feature-brand-container-darker: #E6F0FF;
      --feature-brand-container-lighter: #F3F7FE;
      --feature-brand-on-container: #005DE0;

      --feature-cashier-primary: #26C3BB;
      --feature-cashier-container: #E9F9F8;
      --feature-product-primary: #782AAE;
      --feature-product-container: #F2EAF7;
      --feature-invoice-primary: #FF9100;
      --feature-invoice-container: #FFF4E6;

      --status-grey-primary: #A9A9A9;
      --status-grey-on-primary: #FFFFFF;
      --status-grey-container: #E9E9E9;
      --status-grey-on-container: #535353;

      --status-green-primary: #54A73F;
      --status-green-on-primary: #FFFFFF;
      --status-green-container: #EEF6EC;
      --status-green-on-container: #52A33E;

      --status-yellow-primary: #F2CE17;
      --status-yellow-on-primary: #FFFFFF;
      --status-yellow-container: #FEFAE8;
      --status-yellow-on-container: #E0B20C;

      --status-orange-primary: #FF9100;
      --status-orange-on-primary: #FFFFFF;
      --status-orange-container: #FFF4E6;
      --status-orange-on-container: #E07F00;

      --status-red-primary: #D0021B;
      --status-red-on-primary: #FFFFFF;
      --status-red-container: #FAE6E8;
      --status-red-on-container: #D0021B;

      --text-display-large: 52px;
      --text-large-title: 26px;
      --text-big-title: 24px;
      --text-headline: 20px;
      --text-title-1: 18px;
      --text-title-2: 16px;
      --text-title-3: 14px;
      --text-subtitle-1: 16px;
      --text-subtitle-2: 14px;
      --text-body: 12px;
      --text-desc: 10px;
      
      --font-weight-regular: 400;
      --font-weight-semi-bold: 600;
      --font-weight-bold: 700;
      --font-weight-black: 900;

      --spacing-xx-sm: 4px;
      --spacing-x-sm: 8px;
      --spacing-sm: 12px;
      --spacing-md: 16px;
      --spacing-big: 20px;
      --spacing-x-big: 24px;
      --spacing-xx-big: 28px;
      --spacing-xxx-big: 32px;
      --spacing-lg: 40px;
      --spacing-x-lg: 48px;
      --spacing-xx-lg: 64px;

      --radius-full: 100px;
      --radius-2xl: 24px;
      --radius-xl: 16px;
      --radius-lg: 12px;
      --radius-md: 8px;
      --radius-sm: 4px;

      --radius: var(--radius-lg);
      --radius-button: var(--radius-lg);
      --radius-card: var(--radius-xl);
      --radius-input: 10px;
      --radius-medium: var(--radius-lg);
      --radius-small: var(--radius-md);
      --radius-xxs: var(--radius-sm);

      --elevation-sm: 0px 4px 12px rgba(0, 0, 0, 0.12);
      --elevation-sticky: 0px -3px 10px rgba(0, 0, 0, 0.04);
    }

    * {
      box-sizing: border-box;
      font-family: var(--font-family-base);
    }

    body {
      margin: 0;
      padding: 0;
      background-color: var(--neutral-background-primary);
      color: var(--neutral-on-surface-primary);
      line-height: 1.45;
      -webkit-font-smoothing: antialiased;
      text-rendering: optimizeLegibility;
    }
    
    ::-webkit-scrollbar {
      width: 6px;
      height: 6px;
    }
    ::-webkit-scrollbar-track {
      background: transparent;
    }
    ::-webkit-scrollbar-thumb {
      background: var(--neutral-line-separator-2);
      border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: var(--neutral-on-surface-tertiary);
    }

    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
    input[type=number] {
      -moz-appearance: textfield;
    }
  `}</style>
);

// --- UI COMPONENTS ---

const Button = ({
  variant = "filled",
  size = "small",
  leftIcon: LeftIcon,
  children,
  onClick,
  className = "",
  style = {},
  disabled = false,
  type = "button",
  ...props
}) => {
  const isFilled = variant === "filled";
  const isDanger = variant === "danger";
  const isGhost = variant === "ghost";
  const isTertiary = variant === "tertiary";
  const isOutlined = !isFilled && !isDanger && !isGhost && !isTertiary;

  const sizeStyles = {
    xlarge: {
      height: "56px",
      padding: "0 24px",
      borderRadius: "var(--radius-button)",
      fontSize: "var(--text-title-2)",
      gap: "8px",
      fontWeight: "var(--font-weight-bold)",
    },
    large: {
      height: "50px",
      padding: "0 24px",
      borderRadius: "var(--radius-button)",
      fontSize: "var(--text-title-2)",
      gap: "8px",
    },
    medium: {
      height: "44px",
      padding: "0 24px",
      borderRadius: "var(--radius-small)",
      fontSize: "var(--text-title-2)",
      gap: "8px",
    },
    small: {
      height: "32px",
      padding: "0 12px",
      borderRadius: "var(--radius-small)",
      fontSize: "var(--text-title-3)",
      gap: "4px",
    },
  }[size];

  let border =
    isFilled || isGhost || isTertiary
      ? "1px solid transparent"
      : "1px solid var(--feature-brand-primary)";
  let bg = isFilled
    ? "var(--feature-brand-primary)"
    : isOutlined
      ? "var(--neutral-surface-primary)"
      : "transparent";
  let textCol = isFilled
    ? "var(--feature-brand-on-primary)"
    : "var(--feature-brand-primary)";

  if (isDanger) {
    border = "1px solid var(--status-red-primary)";
    bg = "transparent";
    textCol = "var(--status-red-primary)";
  }

  if (isGhost) {
    textCol = "var(--neutral-on-surface-secondary)";
  }

  if (disabled) {
    border = "1px solid transparent";
    bg = "var(--neutral-surface-grey-lighter)";
    textCol = "var(--neutral-on-surface-tertiary)";
  }

  const computedPadding = isTertiary
    ? size === "small"
      ? "0 4px"
      : "0 8px"
    : sizeStyles.padding;

  const baseStyles = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: isTertiary
      ? "var(--font-weight-bold)"
      : sizeStyles.fontWeight || "var(--font-weight-regular)",
    whiteSpace: "nowrap",
    transition: "all 0.15s ease",
    cursor: disabled ? "not-allowed" : "pointer",
    border,
    background: bg,
    color: textCol,
    opacity: 1,
    outline: "none",
    ...sizeStyles,
    padding: computedPadding,
  };

  return (
    <button
      type={type}
      style={{ ...baseStyles, ...style }}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      onMouseEnter={(e) => {
        if (disabled) return;
        if (isFilled) {
          e.currentTarget.style.background = "#005CE8";
          e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,104,255,0.28)";
        } else if (isDanger) {
          e.currentTarget.style.background = "var(--status-red-container)";
        } else if (isGhost) {
          e.currentTarget.style.background =
            "var(--neutral-surface-grey-lighter)";
          e.currentTarget.style.color = "var(--neutral-on-surface-primary)";
        } else if (isTertiary) {
          e.currentTarget.style.background =
            "var(--feature-brand-container-lighter)";
        } else {
          e.currentTarget.style.background =
            "var(--feature-brand-container-lighter)";
        }
      }}
      onMouseLeave={(e) => {
        if (disabled) return;
        if (isFilled) {
          e.currentTarget.style.background = "var(--feature-brand-primary)";
          e.currentTarget.style.boxShadow = "none";
        } else if (isDanger) {
          e.currentTarget.style.background = "transparent";
        } else if (isGhost) {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.color = "var(--neutral-on-surface-secondary)";
        } else if (isTertiary) {
          e.currentTarget.style.background = "transparent";
        } else {
          e.currentTarget.style.background = "var(--neutral-surface-primary)";
        }
      }}
      className={className}
      {...props}
    >
      {LeftIcon ? (
        <LeftIcon
          size={
            size === "xlarge" || size === "large"
              ? 20
              : size === "medium"
                ? 18
                : 16
          }
        />
      ) : null}
      <span>{children}</span>
    </button>
  );
};

const IconButton = ({
  icon: Icon,
  onClick,
  size = "medium",
  disabled = false,
  color = "var(--neutral-on-surface-secondary)",
  hoverBackground = "var(--neutral-surface-grey-lighter)",
  style = {},
  title,
  ...props
}) => {
  const sizeMap = {
    xs: { button: 18, icon: 12, radius: 4 },
    small: { button: 32, icon: 16, radius: 8 },
    medium: { button: 44, icon: 18, radius: 8 },
    large: { button: 50, icon: 20, radius: 12 },
    xlarge: { button: 56, icon: 20, radius: 12 },
  }[size];

  return (
    <button
      type="button"
      title={title}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      style={{
        width: `${sizeMap.button}px`,
        height: `${sizeMap.button}px`,
        border: "none",
        background: disabled
          ? "var(--neutral-surface-grey-lighter)"
          : "transparent",
        borderRadius: `${sizeMap.radius}px`,
        padding: 0,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: 1,
        transition: "background 0.15s ease, opacity 0.15s ease",
        ...style,
      }}
      onMouseEnter={(e) => {
        if (disabled) return;
        e.currentTarget.style.background = hoverBackground;
      }}
      onMouseLeave={(e) => {
        if (disabled) return;
        e.currentTarget.style.background = "transparent";
      }}
      {...props}
    >
      <Icon
        size={sizeMap.icon}
        color={disabled ? "var(--neutral-on-surface-tertiary)" : color}
      />
    </button>
  );
};

const StatusBadge = ({ variant = "grey", children }) => {
  const getColors = () => {
    switch (variant) {
      case "blue":
        return {
          bg: "var(--feature-brand-primary)",
          color: "var(--feature-brand-on-primary)",
        };
      case "green":
        return {
          bg: "var(--status-green-primary)",
          color: "var(--status-green-on-primary)",
        };
      case "yellow":
        return {
          bg: "var(--status-yellow-primary)",
          color: "var(--status-yellow-on-primary)",
        };
      case "orange":
        return {
          bg: "var(--status-orange-primary)",
          color: "var(--status-orange-on-primary)",
        };
      case "red":
        return {
          bg: "var(--status-red-primary)",
          color: "var(--status-red-on-primary)",
        };
      case "blue-light":
        return { bg: "#E6F0FF", color: "#005DE0" };
      case "grey-light":
        return { bg: "var(--neutral-line-separator-1)", color: "#535353" };
      case "yellow-light":
        return { bg: "#FEFAE8", color: "#E0B20C" };
      case "green-light":
        return { bg: "#EEF6EC", color: "#52A33E" };
      case "red-light":
        return { bg: "#FAE6E8", color: "var(--status-red-primary)" };
      case "orange-light":
        return {
          bg: "var(--status-orange-container)",
          color: "var(--status-orange-on-container)",
        };
      case "grey":
      default:
        return {
          bg: "var(--neutral-on-surface-tertiary)",
          color: "var(--status-grey-on-primary)",
        };
    }
  };

  const { bg, color } = getColors();

  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        height: "24px",
        padding: "2px 8px",
        borderRadius: "var(--radius-xxs)",
        background: bg,
        color: color,
        fontSize: "var(--text-body)",
        fontWeight: "var(--font-weight-regular)",
        whiteSpace: "nowrap",
        flexShrink: 0,
      }}
    >
      {children}
    </div>
  );
};

const FilterPill = ({ label, active = false, isOpen = false, count = 0 }) => {
  const isHighlighted = active || isOpen;
  const showCount = active && count > 0;

  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        height: "44px",
        padding: showCount ? "0 12px 0 10px" : "0 16px",
        borderRadius: "14px",
        border: `1px solid ${isHighlighted ? "var(--feature-brand-primary)" : "#AEAEAE"
          }`,
        background:
          active && !isOpen ? "#EAF1FF" : "var(--neutral-surface-primary)",
        color: isHighlighted ? "var(--feature-brand-primary)" : "#A1A1A1",
        fontSize: "var(--text-title-3)",
        fontWeight: "var(--font-weight-regular)",
        cursor: "pointer",
        gap: "8px",
        whiteSpace: "nowrap",
        boxSizing: "border-box",
        boxShadow: "none",
        transition:
          "border-color 0.2s ease, background 0.2s ease, color 0.2s ease",
      }}
    >
      {showCount ? (
        <span
          style={{
            width: "20px",
            height: "20px",
            borderRadius: "50%",
            background: "var(--feature-brand-primary)",
            color: "var(--feature-brand-on-primary)",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "11px",
            fontWeight: "var(--font-weight-bold)",
            flexShrink: 0,
          }}
        >
          {count}
        </span>
      ) : null}
      {label}
      <ChevronDownIcon
        size={16}
        color={
          isHighlighted
            ? "var(--feature-brand-primary)"
            : "var(--neutral-on-surface-tertiary)"
        }
        style={{
          transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
          transition: "transform 0.2s ease",
        }}
      />
    </div>
  );
};

const ListStatusCounterCard = ({
  label,
  count,
  badgeVariant,
  active = false,
  onClick,
}) => (
  <button
    type="button"
    onClick={onClick}
    style={{
      minWidth: "180px",
      flex: 1,
      minHeight: "80px",
      padding: "14px 16px",
      borderRadius: "16px",
      border: `1px solid ${active
          ? "var(--feature-brand-primary)"
          : "var(--neutral-line-separator-1)"
        }`,
      background: active
        ? "var(--feature-brand-container-lighter)"
        : "var(--neutral-surface-primary)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "12px",
      cursor: "pointer",
      boxSizing: "border-box",
    }}
  >
    <span
      style={{
        fontSize: "var(--text-title-2)",
        lineHeight: 1.3,
        color: active
          ? "var(--feature-brand-primary)"
          : "var(--neutral-on-surface-primary)",
        fontWeight: active
          ? "var(--font-weight-bold)"
          : "var(--font-weight-regular)",
        textAlign: "left",
      }}
    >
      {label}
    </span>
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "8px",
        flexShrink: 0,
      }}
    >
      <StatusBadge variant={badgeVariant}>{count}</StatusBadge>
      {active ? (
        <CloseIcon size={16} color="var(--feature-brand-primary)" />
      ) : (
        <ChevronRightIcon
          size={16}
          color="var(--neutral-on-surface-tertiary)"
        />
      )}
    </div>
  </button>
);

const TABLE_ROWS_PER_PAGE_OPTIONS = [10, 25, 50];

const TableSearchField = ({
  value = "",
  onChange,
  placeholder,
  width = "360px",
}) => {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <div
      style={{
        position: "relative",
        width,
        minWidth: "280px",
        maxWidth: "100%",
        height: "46px",
        borderRadius: "12px",
        border: `1px solid ${isFocused ? "var(--feature-brand-primary)" : "transparent"
          }`,
        background: "var(--neutral-surface-grey-lighter)",
        display: "flex",
        alignItems: "center",
        boxSizing: "border-box",
        boxShadow: isFocused ? "0 0 0 3px rgba(0, 104, 255, 0.08)" : "none",
        transition: "border-color 0.2s ease, box-shadow 0.2s ease",
      }}
    >
      <SearchIcon
        size={18}
        color="var(--neutral-on-surface-tertiary)"
        style={{
          position: "absolute",
          left: "16px",
          top: "50%",
          transform: "translateY(-50%)",
        }}
      />
      <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        style={{
          width: "100%",
          height: "100%",
          border: "none",
          outline: "none",
          background: "transparent",
          padding: "0 16px 0 46px",
          fontSize: "var(--text-subtitle-1)",
          color: value
            ? "var(--neutral-on-surface-primary)"
            : "var(--neutral-on-surface-secondary)",
          boxSizing: "border-box",
        }}
      />
    </div>
  );
};

const ToggleSwitch = ({ checked = false, onChange, disabled = false }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    disabled={disabled}
    onClick={() => {
      if (!disabled) onChange?.(!checked);
    }}
    style={{
      width: "52px",
      height: "28px",
      padding: 0,
      borderRadius: "999px",
      border: `1px solid ${checked ? "var(--feature-brand-primary)" : "#d9d9d9"
        }`,
      background: checked ? "var(--feature-brand-primary)" : "#d9d9d9",
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: 1,
      transition:
        "background 0.2s ease, border-color 0.2s ease, opacity 0.2s ease",
      boxSizing: "border-box",
      flexShrink: 0,
    }}
  >
    <span
      style={{
        position: "absolute",
        left: "2px",
        top: "2px",
        width: "22px",
        height: "22px",
        borderRadius: "50%",
        background: "var(--neutral-surface-primary)",
        boxShadow: "0 1px 3px rgba(16, 24, 40, 0.24)",
        transform: `translateX(${checked ? "24px" : "0px"})`,
        transition: "transform 0.2s ease",
      }}
    />
  </button>
);

const TablePaginationFooter = ({
  totalRows,
  rowsPerPage,
  onRowsPerPageChange,
  currentPage,
  totalPages,
  onPageChange,
}) => {
  const isPrevDisabled = currentPage <= 1;
  const isNextDisabled = currentPage >= totalPages;

  return (
    <div
      style={{
        borderTop: "1px solid var(--neutral-line-separator-1)",
        padding: "16px 20px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "16px",
        background: "var(--neutral-surface-primary)",
        flexWrap: "wrap",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        <div style={{ position: "relative", width: "112px", height: "40px" }}>
          <DropdownSelect
            value={rowsPerPage}
            onChange={(nextValue) => onRowsPerPageChange(Number(nextValue))}
            options={TABLE_ROWS_PER_PAGE_OPTIONS.map((option) => ({
              value: option,
              label: String(option),
            }))}
            fieldHeight="40px"
            borderRadius="12px"
            fontSize="var(--text-title-2)"
            optionFontSize="var(--text-title-3)"
            menuWidth={112}
            showSelectedCheck={false}
            style={{ height: "40px" }}
          />
        </div>
        <span
          style={{
            fontSize: "var(--text-title-2)",
            color: "var(--neutral-on-surface-secondary)",
          }}
        >{`from ${totalRows} rows`}</span>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
        <button
          type="button"
          onClick={() => !isPrevDisabled && onPageChange(currentPage - 1)}
          disabled={isPrevDisabled}
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "12px",
            border: `1px solid ${isPrevDisabled ? "transparent" : baseInputBorderColor}`,
            background: isPrevDisabled
              ? "var(--neutral-surface-grey-lighter)"
              : "var(--neutral-surface-primary)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: isPrevDisabled ? "not-allowed" : "pointer",
            opacity: 1,
          }}
        >
          <ChevronLeftIcon
            size={18}
            color="var(--neutral-on-surface-secondary)"
          />
        </button>
        <div
          style={{
            minWidth: "40px",
            height: "40px",
            padding: "0 12px",
            borderRadius: "12px",
            background: "var(--feature-brand-primary)",
            color: "var(--feature-brand-on-primary)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "var(--text-title-3)",
            fontWeight: "var(--font-weight-bold)",
          }}
        >
          {currentPage}
        </div>
        <button
          type="button"
          onClick={() => !isNextDisabled && onPageChange(currentPage + 1)}
          disabled={isNextDisabled}
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "12px",
            border: `1px solid ${isNextDisabled ? "transparent" : baseInputBorderColor}`,
            background: isNextDisabled
              ? "var(--neutral-surface-grey-lighter)"
              : "var(--neutral-surface-primary)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: isNextDisabled ? "not-allowed" : "pointer",
            opacity: 1,
          }}
        >
          <ChevronRightIcon
            size={18}
            color="var(--neutral-on-surface-secondary)"
          />
        </button>
      </div>
    </div>
  );
};

const Checkbox = ({ checked, disabled, onChange }) => {
  return (
    <div
      onClick={() => {
        if (!disabled) onChange(!checked);
      }}
      style={{
        width: "20px",
        height: "20px",
        borderRadius: "4px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: disabled ? "not-allowed" : "pointer",
        background: disabled
          ? "var(--neutral-surface-grey-lighter)"
          : checked
            ? "var(--feature-brand-primary)"
            : "transparent",
        border: `1px solid ${disabled
            ? "var(--neutral-line-outline)"
            : checked
              ? "var(--feature-brand-primary)"
              : "var(--neutral-line-outline)"
          }`,
        flexShrink: 0,
        transition: "all 0.15s ease",
      }}
    >
      {checked ? (
        <CheckIcon
          size={14}
          color={
            disabled
              ? "var(--neutral-on-surface-tertiary)"
              : "var(--feature-brand-on-primary)"
          }
        />
      ) : null}
    </div>
  );
};

const ProgressRing = ({ percentage, color = "inherit" }) => {
  const radius = 6;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
      <svg
        width="16"
        height="16"
        viewBox="0 0 16 16"
        style={{ transform: "rotate(-90deg)" }}
      >
        <circle
          cx="8"
          cy="8"
          r={radius}
          fill="none"
          stroke="var(--neutral-line-separator-2)"
          strokeWidth="2"
        />
        <circle
          cx="8"
          cy="8"
          r={radius}
          fill="none"
          stroke="var(--feature-brand-primary)"
          strokeWidth="2"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
        />
      </svg>
      <span style={{ color }}>{percentage}%</span>
    </div>
  );
};

const Tooltip = ({ content, children }) => {
  const [isVisible, setIsVisible] = useState(false);
  return (
    <div
      style={{
        position: "relative",
        display: "inline-flex",
        alignItems: "center",
      }}
      onMouseEnter={() => setIsVisible(true)}
      onMouseLeave={() => setIsVisible(false)}
    >
      {children}
      {isVisible ? (
        <div
          style={{
            position: "absolute",
            bottom: "100%",
            left: "50%",
            transform: "translateX(-50%)",
            marginBottom: "8px",
            width: "80vw",
            maxWidth: "1600px",
            width: "max-content",
            padding: "8px 12px",
            borderRadius: "8px",
            background: "var(--neutral-on-surface-primary)",
            color: "var(--neutral-surface-primary)",
            fontSize: "var(--text-desc)",
            lineHeight: "1.6",
            boxShadow: "var(--elevation-sm)",
            zIndex: 1000,
            textAlign: "center",
            pointerEvents: "none",
          }}
        >
          {content}
          <div
            style={{
              position: "absolute",
              top: "100%",
              left: "50%",
              transform: "translateX(-50%)",
              borderWidth: "6px",
              borderStyle: "solid",
              borderColor:
                "var(--neutral-on-surface-primary) transparent transparent transparent",
            }}
          />
        </div>
      ) : null}
    </div>
  );
};

const LabelValue = ({ label, value, badge }) => {
  const displayValue =
    typeof value === "object" && value !== null ? JSON.stringify(value) : value;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      <span
        style={{
          fontSize: "var(--text-body)",
          color: "var(--neutral-on-surface-secondary)",
        }}
      >
        {label}
      </span>
      <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
        {badge ? (
          <StatusBadge variant={badge.variant}>{badge.text}</StatusBadge>
        ) : (
          <span
            style={{
              fontSize: "var(--text-title-3)",
              fontWeight: "var(--font-weight-bold)",
              color: "var(--neutral-on-surface-primary)",
            }}
          >
            {displayValue}
          </span>
        )}
      </div>
    </div>
  );
};

const FormField = ({
  label,
  required = false,
  children,
  error,
  helperText,
}) => (
  <div
    style={{
      display: "flex",
      flexDirection: "column",
      gap: "8px",
      width: "100%",
    }}
  >
    {label ? (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "2px",
          fontSize: "var(--text-body)",
          fontWeight: "var(--font-weight-regular)",
        }}
      >
        {required ? (
          <span style={{ color: "var(--status-red-primary)" }}>*</span>
        ) : null}
        <span style={{ color: "var(--neutral-on-surface-primary)" }}>
          {label}
        </span>
      </div>
    ) : null}
    {children}
    {error ? (
      <span
        style={{
          fontSize: "var(--text-body)",
          color: "var(--status-red-primary)",
        }}
      >
        {error}
      </span>
    ) : null}
    {!error && helperText ? (
      <span
        style={{
          fontSize: "var(--text-desc)",
          color: "var(--neutral-on-surface-secondary)",
        }}
      >
        {helperText}
      </span>
    ) : null}
  </div>
);

const baseInputBorderColor = "#e9e9e9";

const UnifiedInputShell = ({
  children,
  disabled = false,
  hasError = false,
  style = {},
  onFocus,
  onBlur,
}) => (
  <div
    style={{
      minHeight: "46px",
      height: "auto",
      width: "100%",
      display: "flex",
      alignItems: "center",
      gap: "8px",
      border: `1px solid ${hasError
          ? "var(--status-red-primary)"
          : disabled
            ? "var(--neutral-line-outline)"
            : baseInputBorderColor
        }`,
      borderRadius: "10px",
      background: disabled
        ? "var(--neutral-surface-grey-lighter)"
        : "var(--neutral-surface-primary)",
      padding: "0 16px",
      transition: "border-color 0.2s ease, box-shadow 0.2s ease",
      boxSizing: "border-box",
      overflow: "visible",
      ...style,
    }}
    onFocus={onFocus}
    onBlur={onBlur}
  >
    {children}
  </div>
);

const PhoneInputField = ({
  label,
  required = false,
  value = "",
  onChange,
  disabled,
  error,
  helperText,
}) => {
  const normalizePhoneValue = (input) => {
    if (!input) return { countryCode: "+62", number: "" };
    const matched = COUNTRY_CODE_OPTIONS.find(
      (opt) => input.startsWith(`${opt.code} `) || input === opt.code
    );
    if (matched) {
      const nextNumber = input
        .replace(`${matched.code} `, "")
        .replace(matched.code, "")
        .trim();
      return { countryCode: matched.code, number: nextNumber };
    }
    return { countryCode: "+62", number: input.trim() };
  };

  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [popoverPos, setPopoverPos] = useState({ top: 0, left: 0, width: 500 });
  const parsedValue = normalizePhoneValue(value);
  const selectedOption =
    COUNTRY_CODE_OPTIONS.find((opt) => opt.code === parsedValue.countryCode) ||
    COUNTRY_CODE_OPTIONS[0];
  const filteredOptions = COUNTRY_CODE_OPTIONS.filter((opt) => {
    const q = search.toLowerCase();
    return (
      opt.code.toLowerCase().includes(q) || opt.label.toLowerCase().includes(q)
    );
  });

  const emitChange = (nextCountryCode, nextNumber) => {
    const composed = nextNumber?.trim()
      ? `${nextCountryCode} ${nextNumber.trim()}`
      : nextCountryCode;
    onChange?.(composed);
  };

  const updatePopoverPosition = (el) => {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    setPopoverPos({
      top: rect.bottom + 12,
      left: rect.left,
      width: Math.max(rect.width, 500),
    });
  };

  return (
    <FormField
      label={label}
      required={required}
      error={error}
      helperText={helperText}
    >
      <UnifiedInputShell
        disabled={disabled}
        hasError={!!error}
        style={{ position: "relative", zIndex: isOpen ? 200 : "auto" }}
        onFocus={(e) => focusInputFrame(e.currentTarget)}
        onBlur={(e) => {
          if (!e.currentTarget.contains(e.relatedTarget)) {
            blurInputFrame(e.currentTarget, !!disabled, !!error);
          }
        }}
      >
        <div style={{ position: "relative", flexShrink: 0 }}>
          <button
            type="button"
            disabled={disabled}
            onClick={(e) => {
              if (disabled) return;
              const nextOpen = !isOpen;
              if (nextOpen) updatePopoverPosition(e.currentTarget);
              setIsOpen(nextOpen);
            }}
            style={{
              background: "transparent",
              border: "none",
              padding: 0,
              display: "flex",
              alignItems: "center",
              gap: "8px",
              cursor: disabled ? "not-allowed" : "pointer",
              color: disabled
                ? "var(--neutral-on-surface-tertiary)"
                : "var(--neutral-on-surface-primary)",
              fontSize: "var(--text-subtitle-1)",
              fontFamily: "Lato, sans-serif",
              flexShrink: 0,
            }}
          >
            <span style={{ fontSize: "18px", lineHeight: 1 }}>
              {selectedOption.flag}
            </span>
            <span style={{ whiteSpace: "nowrap" }}>{selectedOption.code}</span>
            <ChevronDownIcon
              size={18}
              color="var(--neutral-on-surface-secondary)"
              style={{
                transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
                transition: "transform 0.2s ease",
              }}
            />
          </button>

          {isOpen && !disabled ? (
            <>
              <div
                style={{ position: "fixed", inset: 0, zIndex: 9998 }}
                onClick={() => {
                  setIsOpen(false);
                  setSearch("");
                }}
              />
              <div
                style={{
                  position: "fixed",
                  top: `${popoverPos.top}px`,
                  left: `${popoverPos.left}px`,
                  width: `${popoverPos.width}px`,
                  background: "var(--neutral-surface-primary)",
                  border: `1px solid ${baseInputBorderColor}`,
                  borderRadius: "16px",
                  boxShadow: "0px 8px 24px rgba(0, 0, 0, 0.12)",
                  zIndex: 9999,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    padding: "16px",
                    borderBottom: `1px solid ${baseInputBorderColor}`,
                  }}
                >
                  <div style={{ position: "relative" }}>
                    <SearchIcon
                      size={18}
                      color="var(--neutral-on-surface-tertiary)"
                      style={{
                        position: "absolute",
                        left: "14px",
                        top: "50%",
                        transform: "translateY(-50%)",
                      }}
                    />
                    <input
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder="Search country or code..."
                      style={{
                        height: "48px",
                        width: "100%",
                        border: `1px solid ${baseInputBorderColor}`,
                        borderRadius: "8px",
                        padding: "0 16px 0 46px",
                        outline: "none",
                        fontSize: "var(--text-subtitle-1)",
                        color: "var(--neutral-on-surface-primary)",
                        background: "var(--neutral-surface-primary)",
                      }}
                    />
                  </div>
                </div>
                <div style={{ maxHeight: "320px", overflowY: "auto" }}>
                  {filteredOptions.map((opt) => (
                    <div
                      key={opt.code}
                      onClick={() => {
                        emitChange(opt.code, parsedValue.number);
                        setIsOpen(false);
                        setSearch("");
                      }}
                      onMouseEnter={(e) =>
                      (e.currentTarget.style.background =
                        "var(--neutral-surface-grey-lighter)")
                      }
                      onMouseLeave={(e) =>
                      (e.currentTarget.style.background =
                        "var(--neutral-surface-primary)")
                      }
                      style={{
                        padding: "20px 20px",
                        display: "flex",
                        alignItems: "center",
                        gap: "14px",
                        cursor: "pointer",
                      }}
                    >
                      <span style={{ fontSize: "20px", lineHeight: 1 }}>
                        {opt.flag}
                      </span>
                      <span
                        style={{
                          fontSize: "18px",
                          color: "var(--neutral-on-surface-primary)",
                          minWidth: "44px",
                        }}
                      >
                        {opt.code}
                      </span>
                      <span
                        style={{
                          fontSize: "18px",
                          color: "var(--neutral-on-surface-secondary)",
                        }}
                      >
                        {opt.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : null}
        </div>
        <input
          type="text"
          placeholder="Input phone number"
          value={parsedValue.number}
          onChange={(e) => emitChange(selectedOption.code, e.target.value)}
          disabled={disabled}
          style={{
            flex: 1,
            height: "100%",
            minWidth: 0,
            border: "none",
            outline: "none",
            padding: 0,
            background: "transparent",
            fontSize: "var(--text-subtitle-1)",
            color: disabled
              ? "var(--neutral-on-surface-tertiary)"
              : parsedValue.number
                ? "var(--neutral-on-surface-primary)"
                : "var(--neutral-on-surface-tertiary)",
            fontFamily: "Lato, sans-serif",
          }}
        />
      </UnifiedInputShell>
    </FormField>
  );
};

const DateInputControl = ({
  value = "",
  onChange,
  disabled = false,
  hasError = false,
  placeholder = "yyyy-mm-dd",
  fieldHeight = "48px",
  borderRadius = "10px",
  fontSize = "var(--text-subtitle-1)",
  style = {},
}) => {
  const triggerRef = useRef(null);
  const popoverRef = useRef(null);
  const selectedDate = parseIsoDateString(value);
  const [isOpen, setIsOpen] = useState(false);
  const [viewDate, setViewDate] = useState(
    selectedDate || parseIsoDateString(formatIsoDateString(new Date())) || new Date()
  );
  const [popoverPos, setPopoverPos] = useState({
    top: 0,
    left: 0,
    width: 320,
    placement: "bottom",
  });

  const updatePopoverPosition = () => {
    if (!triggerRef.current || typeof window === "undefined") return;
    const rect = triggerRef.current.getBoundingClientRect();
    const width = Math.max(
      320,
      Math.min(DATE_PICKER_POPOVER_WIDTH, window.innerWidth - 16)
    );
    const estimatedHeight = 360;
    const openAbove =
      window.innerHeight - rect.bottom < estimatedHeight + 16 &&
      rect.top > estimatedHeight + 16;
    const maxLeft = Math.max(8, window.innerWidth - width - 8);
    const centeredLeft = rect.left + rect.width / 2 - width / 2;
    const left = Math.min(Math.max(8, centeredLeft), maxLeft);
    setPopoverPos({
      left,
      top: openAbove ? rect.top - 8 : rect.bottom + 8,
      width,
      placement: openAbove ? "top" : "bottom",
    });
  };

  useEffect(() => {
    if (!isOpen) return;
    updatePopoverPosition();

    const handlePointerDown = (event) => {
      if (
        triggerRef.current?.contains(event.target) ||
        popoverRef.current?.contains(event.target)
      ) {
        return;
      }
      setIsOpen(false);
    };

    const handleViewportChange = () => updatePopoverPosition();

    document.addEventListener("mousedown", handlePointerDown);
    window.addEventListener("resize", handleViewportChange);
    window.addEventListener("scroll", handleViewportChange, true);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      window.removeEventListener("resize", handleViewportChange);
      window.removeEventListener("scroll", handleViewportChange, true);
    };
  }, [isOpen]);

  const calendarDays = buildCalendarDays(viewDate);
  const monthLabel = DATE_PICKER_MONTHS[viewDate.getMonth()];
  const yearLabel = viewDate.getFullYear();

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        disabled={disabled}
        onClick={() => {
          if (disabled) return;
          setViewDate(selectedDate || new Date());
          setIsOpen((prev) => !prev);
        }}
        style={{
          width: "100%",
          height: fieldHeight,
          border: `1px solid ${
            hasError
              ? "var(--status-red-primary)"
              : isOpen
                ? "var(--feature-brand-primary)"
                : disabled
                  ? "var(--neutral-line-outline)"
                  : baseInputBorderColor
          }`,
          borderRadius,
          background: disabled
            ? "var(--neutral-surface-grey-lighter)"
            : "var(--neutral-surface-primary)",
          boxShadow: isOpen ? "0 0 0 3px rgba(0, 104, 255, 0.08)" : "none",
          padding: "0 16px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "12px",
          cursor: disabled ? "not-allowed" : "pointer",
          textAlign: "left",
          transition: "border-color 0.2s ease, box-shadow 0.2s ease",
          ...style,
        }}
      >
        <span
          style={{
            fontSize,
            color: disabled
              ? "var(--neutral-on-surface-tertiary)"
              : value
                ? "var(--neutral-on-surface-primary)"
                : "var(--neutral-on-surface-tertiary)",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {value || placeholder}
        </span>
        <CalendarIcon
          size={18}
          color={
            disabled
              ? "var(--neutral-line-outline)"
              : "var(--neutral-on-surface-secondary)"
          }
        />
      </button>

      {isOpen ? (
        <div
          ref={popoverRef}
          style={{
            position: "fixed",
            top: `${popoverPos.top}px`,
            left: `${popoverPos.left}px`,
            width: `${popoverPos.width}px`,
            transform:
              popoverPos.placement === "top" ? "translateY(-100%)" : "none",
            background: "var(--neutral-surface-primary)",
            border: "1px solid var(--neutral-line-separator-2)",
            borderRadius: "12px",
            boxShadow: "0px 6px 15px -2px rgba(16, 24, 40, 0.08)",
            padding: "20px",
            display: "flex",
            flexDirection: "column",
            gap: "8px",
            zIndex: 10020,
          }}
        >
          <div
            style={{
              border: "1px solid var(--neutral-line-separator-1)",
              borderRadius: "8px",
              padding: "12px",
              display: "grid",
              gridTemplateColumns: "24px 1fr 1fr 24px",
              alignItems: "center",
              gap: "12px",
            }}
          >
            <button
              type="button"
              onClick={() =>
                setViewDate(
                  new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1)
                )
              }
              style={{
                width: "24px",
                height: "24px",
                border: "none",
                background: "transparent",
                padding: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
              }}
            >
              <ChevronLeftIcon size={18} color="var(--neutral-on-surface-primary)" />
            </button>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                padding: "12px",
                fontSize: "var(--text-title-2)",
                fontWeight: "var(--font-weight-bold)",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              {monthLabel}
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                padding: "12px",
                fontSize: "var(--text-title-2)",
                fontWeight: "var(--font-weight-bold)",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              {yearLabel}
            </div>
            <button
              type="button"
              onClick={() =>
                setViewDate(
                  new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1)
                )
              }
              style={{
                width: "24px",
                height: "24px",
                border: "none",
                background: "transparent",
                padding: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
              }}
            >
              <ChevronRightIcon
                size={18}
                color="var(--neutral-on-surface-primary)"
              />
            </button>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7, minmax(0, 1fr))",
              rowGap: "4px",
              paddingTop: "4px",
            }}
          >
            {DATE_PICKER_WEEKDAYS.map((weekday) => (
              <div
                key={weekday}
                style={{
                  display: "flex",
                  justifyContent: "center",
                  padding: "8px 0",
                  fontSize: "var(--text-title-3)",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                {weekday}
              </div>
            ))}
          </div>

          <div
            style={{
              height: "4px",
              background: "var(--neutral-surface-grey-lighter)",
              width: "100%",
            }}
          />

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7, minmax(0, 1fr))",
              rowGap: "4px",
            }}
          >
            {calendarDays.map((day) => {
              const isSelected = day.iso === value;
              return (
                <button
                  key={day.iso}
                  type="button"
                  onClick={() => {
                    onChange?.(createSyntheticInputEvent(day.iso));
                    setIsOpen(false);
                  }}
                  style={{
                    width: "40px",
                    height: "40px",
                    margin: "0 auto",
                    border: "none",
                    borderRadius: "999px",
                    background: isSelected
                      ? "var(--feature-brand-primary)"
                      : "transparent",
                    color: isSelected
                      ? "var(--feature-brand-on-primary)"
                      : day.isCurrentMonth
                        ? "var(--neutral-on-surface-primary)"
                        : "var(--neutral-line-separator-2)",
                    fontSize: "var(--text-subtitle-1)",
                    cursor: "pointer",
                  }}
                >
                  {day.day}
                </button>
              );
            })}
          </div>
        </div>
      ) : null}
    </>
  );
};

const InputField = ({
  label,
  required,
  type = "text",
  placeholder,
  value,
  onChange,
  disabled,
  icon: Icon,
  max,
  multiline = false,
  error,
  helperText,
  ...rest
}) => (
  <FormField
    label={label}
    required={required}
    error={error}
    helperText={helperText}
  >
    <div style={{ position: "relative", width: "100%" }}>
      {multiline ? (
        <textarea
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          disabled={disabled}
          {...rest}
          style={{
            minHeight: "88px",
            padding: "12px 16px",
            width: "100%",
            resize: "vertical",
            border: "1px solid transparent",
            background: disabled
              ? "var(--neutral-surface-grey-lighter)"
              : "var(--neutral-surface-primary)",
            ...inputFrameStyle(disabled, !!error),
            ...inputControlStyle(disabled, !!value),
            cursor: disabled ? "not-allowed" : "text",
          }}
          onFocus={(e) => focusInputFrame(e.currentTarget)}
          onBlur={(e) => blurInputFrame(e.currentTarget, disabled, !!error)}
        />
      ) : type === "date" ? (
        <DateInputControl
          value={value}
          onChange={onChange}
          disabled={disabled}
          hasError={!!error}
          placeholder={placeholder || "yyyy-mm-dd"}
        />
      ) : (
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          disabled={disabled}
          max={max}
          {...rest}
          style={{
            height: "48px",
            padding: Icon ? "0 40px 0 16px" : "0 16px",
            border: "1px solid transparent",
            background: disabled
              ? "var(--neutral-surface-grey-lighter)"
              : "var(--neutral-surface-primary)",
            ...inputFrameStyle(disabled, !!error),
            ...inputControlStyle(disabled, !!value),
            cursor: disabled ? "not-allowed" : "text",
          }}
          onFocus={(e) => focusInputFrame(e.currentTarget)}
          onBlur={(e) => blurInputFrame(e.currentTarget, disabled, !!error)}
        />
      )}
      {Icon && type !== "date" ? (
        <Icon
          size={20}
          color={
            disabled
              ? "var(--neutral-line-outline)"
              : "var(--neutral-on-surface-tertiary)"
          }
          style={{
            position: "absolute",
            right: "16px",
            top: "50%",
            transform: "translateY(-50%)",
            pointerEvents: "none",
          }}
        />
      ) : null}
    </div>
  </FormField>
);

const openDocumentLink = (doc, fallbackHandler) => {
  if (doc?.previewUrl && typeof window !== "undefined") {
    window.open(doc.previewUrl, "_blank", "noopener,noreferrer");
    return;
  }
  fallbackHandler?.(doc);
};

const DocumentTypeBadge = ({ fileName = "", type = "", size = "default" }) => {
  const normalizedType = (
    getFileExtension(fileName) ||
    (type === "pdf" ? "PDF" : type === "image" ? "JPG" : "DOC")
  ).toUpperCase();
  const palette = {
    DOC: { bg: "#6E90C7", fold: "#A8BFE2" },
    XLS: { bg: "#0D7C44", fold: "#56B182" },
    PDF: { bg: "#E0001B", fold: "#F3A0AA" },
    ZIP: { bg: "#D4D100", fold: "#ECE87A" },
    JPG: { bg: "#FF980C", fold: "#FFD39C" },
    JPEG: { bg: "#FF980C", fold: "#FFD39C" },
    PNG: { bg: "#456FB4", fold: "#A9BDE2" },
    SVG: { bg: "#605CED", fold: "#AFAEFF" },
    WEBP: { bg: "#767F90", fold: "#AEB5C1" },
  }[normalizedType] || { bg: "#6E90C7", fold: "#A8BFE2" };
  const sizeMap = {
    compact: {
      width: 28,
      height: 32,
      fontSize: "4.8px",
      fold: 9,
      paddingBottom: "7px",
      radius: "6px",
    },
    preview: {
      width: 34,
      height: 40,
      fontSize: "7px",
      fold: 10,
      paddingBottom: "8px",
      radius: "7px",
    },
    default: {
      width: 30,
      height: 36,
      fontSize: "6.6px",
      fold: 10,
      paddingBottom: "7px",
      radius: "7px",
    },
  }[size] || {
    width: 30,
    height: 36,
    fontSize: "6.6px",
    fold: 10,
    paddingBottom: "7px",
    radius: "7px",
  };

  return (
    <div
      style={{
        width: sizeMap.width,
        height: sizeMap.height,
        borderRadius: sizeMap.radius,
        background: palette.bg,
        position: "relative",
        flexShrink: 0,
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
        paddingBottom: sizeMap.paddingBottom,
        boxSizing: "border-box",
        overflow: "hidden",
        clipPath:
          "polygon(0 0, calc(100% - 10px) 0, 100% 10px, 100% 100%, 0 100%)",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 0,
          right: 0,
          width: 0,
          height: 0,
          borderLeft: `${sizeMap.fold}px solid transparent`,
          borderTop: `${sizeMap.fold}px solid ${palette.fold}`,
        }}
      />
      <span
        style={{
          fontSize: sizeMap.fontSize,
          fontWeight: "var(--font-weight-bold)",
          color: "#fff",
          lineHeight: 1,
          letterSpacing: "0.18px",
        }}
      >
        {normalizedType.slice(0, 4)}
      </span>
    </div>
  );
};

const UploadDropzone = ({
  multiple = false,
  accept = ".pdf,.jpg,.jpeg,.png,.webp",
  maxFiles = 1,
  maxText,
  allowedText = "Allowed formats (PDF, JPG, JPEG, PNG, WebP)",
  disabled = false,
  error = "",
  onFilesSelected,
}) => {
  const handleIncomingFiles = (fileList) => {
    if (disabled) return;
    const nextFiles = Array.from(fileList || []);
    if (nextFiles.length === 0) return;
    onFilesSelected?.(nextFiles);
  };

  return (
    <label
      onDragOver={(e) => {
        if (disabled) return;
        e.preventDefault();
      }}
      onDrop={(e) => {
        if (disabled) return;
        e.preventDefault();
        handleIncomingFiles(e.dataTransfer?.files);
      }}
      style={{
        width: "100%",
        minHeight: "168px",
        borderRadius: "24px",
        border: `2px dashed ${error ? "var(--status-red-primary)" : "var(--feature-brand-primary)"
          }`,
        background: "var(--neutral-surface-primary)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: "8px",
        padding: "24px",
        textAlign: "center",
        boxSizing: "border-box",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.55 : 1,
      }}
    >
      <CloudUploadIcon
        size={40}
        color={
          error ? "var(--status-red-primary)" : "var(--feature-brand-primary)"
        }
      />
      <span
        style={{
          fontSize: "var(--text-body)",
          color: "#A9A9A9",
          lineHeight: "18px",
          letterSpacing: "0.0825px",
        }}
      >
        {maxText ||
          (maxFiles === 1 ? "Max 1 file, 25MB each" : "Max 3 files, 25MB each")}
      </span>
      <span
        style={{
          fontSize: "var(--text-body)",
          color: "#A9A9A9",
          lineHeight: "18px",
          letterSpacing: "0.0825px",
        }}
      >
        {allowedText}
      </span>
      <span
        style={{
          fontSize: "var(--text-body)",
          color: "var(--neutral-on-surface-primary)",
          lineHeight: "18px",
          letterSpacing: "0.0825px",
        }}
      >
        Drag file or{" "}
        <span style={{ color: "var(--feature-brand-primary)" }}>
          browse file
        </span>
      </span>
      <input
        type="file"
        accept={accept}
        multiple={multiple}
        disabled={disabled}
        style={{ display: "none" }}
        onChange={(e) => {
          handleIncomingFiles(e.target.files);
          e.target.value = "";
        }}
      />
    </label>
  );
};

const UploadDescriptionCard = ({
  file,
  onRemove,
  onDescriptionChange,
  descriptionRequired = false,
  descriptionError = "",
  hideDescriptionField = false,
}) => (
  <div
    style={{
      border: "1px solid var(--neutral-line-separator-1)",
      borderRadius: "24px",
      padding: "20px 24px",
      display: "flex",
      flexDirection: "column",
      gap: "18px",
      background: "var(--neutral-surface-primary)",
    }}
  >
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "12px",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "16px",
          minWidth: 0,
        }}
      >
        <DocumentTypeBadge fileName={file?.name} type={file?.type} />
        <span
          style={{
            fontSize: "var(--text-title-3)",
            lineHeight: "20px",
            letterSpacing: "0.09625px",
            fontWeight: "var(--font-weight-regular)",
            color: "var(--neutral-on-surface-primary)",
            minWidth: 0,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {file?.name || "-"}
        </span>
      </div>
      {onRemove ? (
        <Button variant="danger" size="medium" onClick={onRemove}>
          Remove
        </Button>
      ) : null}
    </div>

    {!hideDescriptionField ? (
      <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: "12px",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "2px",
              fontSize: "var(--text-title-2)",
            }}
          >
            {descriptionRequired ? (
              <span style={{ color: "var(--status-red-primary)" }}>*</span>
            ) : null}
            <span style={{ color: "var(--neutral-on-surface-primary)" }}>
              File Description
            </span>
          </div>
          <span
            style={{
              fontSize: "var(--text-title-2)",
              color: "var(--neutral-on-surface-tertiary)",
            }}
          >
            {(file?.description || "").length}/{FILE_DESCRIPTION_MAX_LENGTH}
          </span>
        </div>
        <input
          type="text"
          value={file?.description || ""}
          maxLength={FILE_DESCRIPTION_MAX_LENGTH}
          placeholder="Enter File Description"
          onChange={(e) => onDescriptionChange?.(e.target.value)}
          style={{
            height: "48px",
            padding: "0 16px",
            width: "100%",
            ...inputFrameStyle(false, !!descriptionError),
            ...inputControlStyle(false, !!file?.description),
            background: "var(--neutral-surface-primary)",
          }}
          onFocus={(e) => focusInputFrame(e.currentTarget)}
          onBlur={(e) =>
            blurInputFrame(e.currentTarget, false, !!descriptionError)
          }
        />
        {descriptionError ? (
          <span
            style={{
              fontSize: "var(--text-body)",
              color: "var(--status-red-primary)",
            }}
          >
            {descriptionError}
          </span>
        ) : null}
      </div>
    ) : null}
  </div>
);

const ImageUploadField = ({
  label = "Images",
  images = [],
  maxFiles = 1,
  disabled = false,
  error = "",
  helperText = "",
  onFilesSelected,
  onRemove,
}) => {
  const normalizedImages = images
    .map((image) => createImageUploadRecord(image))
    .filter(Boolean)
    .slice(0, maxFiles);
  const canAddMore = !disabled && normalizedImages.length < maxFiles;

  const handleIncomingFiles = (fileList) => {
    if (disabled) return;
    const nextFiles = Array.from(fileList || []).slice(
      0,
      Math.max(0, maxFiles - normalizedImages.length)
    );
    if (nextFiles.length === 0) return;
    onFilesSelected?.(nextFiles);
  };

  const renderEmptyTile = () => (
    <label
      onDragOver={(e) => {
        if (disabled) return;
        e.preventDefault();
      }}
      onDrop={(e) => {
        if (disabled) return;
        e.preventDefault();
        handleIncomingFiles(e.dataTransfer?.files);
      }}
      style={{
        width: "120px",
        height: "120px",
        borderRadius: "12px",
        border: `1px dashed ${error ? "var(--status-red-primary)" : "#A9A9A9"}`,
        background: "var(--neutral-surface-primary)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: disabled ? "not-allowed" : "pointer",
        flexShrink: 0,
      }}
    >
      <div
        style={{
          width: "36px",
          height: "36px",
          borderRadius: "999px",
          background: "var(--neutral-surface-grey-lighter)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <AddIcon size={20} color="var(--neutral-on-surface-tertiary)" />
      </div>
      <input
        type="file"
        accept=".jpg,.jpeg,.png,.webp"
        multiple={maxFiles > 1}
        disabled={disabled}
        style={{ display: "none" }}
        onChange={(e) => {
          handleIncomingFiles(e.target.files);
          e.target.value = "";
        }}
      />
    </label>
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <span
        style={{
          fontSize: "var(--text-title-3)",
          color: "var(--neutral-on-surface-secondary)",
        }}
      >
        {label}
      </span>

      <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
        {normalizedImages.map((image, index) => {
          const previewUrl = getImageUploadPreviewUrl(image);
          const imageName = getImageUploadName(image);
          return (
            <div
              key={image.id || `${imageName}-${index}`}
              style={{
                position: "relative",
                width: "120px",
                height: "120px",
                borderRadius: "12px",
                border:
                  index === 0
                    ? "2px solid var(--feature-brand-primary)"
                    : "1px solid var(--neutral-line-separator-2)",
                padding: "4px",
                background: "var(--neutral-surface-primary)",
                flexShrink: 0,
              }}
            >
              <div
                style={{
                  width: "100%",
                  height: "100%",
                  borderRadius: "12px",
                  background: "var(--neutral-surface-grey-lighter)",
                  overflow: "hidden",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {previewUrl ? (
                  <img
                    src={previewUrl}
                    alt={imageName}
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                    }}
                  />
                ) : (
                  <span
                    style={{
                      padding: "0 10px",
                      textAlign: "center",
                      fontSize: "var(--text-body)",
                      color: "var(--neutral-on-surface-secondary)",
                      lineHeight: "18px",
                      wordBreak: "break-word",
                    }}
                  >
                    {imageName || "Image"}
                  </span>
                )}
              </div>
              {!disabled ? (
                <button
                  type="button"
                  onClick={() => onRemove?.(image)}
                  style={{
                    position: "absolute",
                    top: "-10px",
                    right: "-10px",
                    width: "28px",
                    height: "28px",
                    borderRadius: "999px",
                    border: "1px solid var(--status-red-primary)",
                    background: "var(--neutral-surface-primary)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    padding: 0,
                  }}
                >
                  <CloseIcon size={14} color="var(--status-red-primary)" />
                </button>
              ) : null}
            </div>
          );
        })}

        {canAddMore ? renderEmptyTile() : null}
      </div>

      {error ? (
        <span
          style={{
            fontSize: "var(--text-body)",
            color: "var(--status-red-primary)",
          }}
        >
          {error}
        </span>
      ) : null}

      {helperText ? (
        <span
          style={{
            fontSize: "var(--text-body)",
            color: "var(--neutral-on-surface-secondary)",
          }}
        >
          {helperText}
        </span>
      ) : null}
    </div>
  );
};

const ProofDocumentList = ({ documents = [], onDocumentClick }) => {
  const normalizedDocuments = normalizeProofDocuments(documents);

  if (normalizedDocuments.length === 0) {
    return (
      <span
        style={{
          fontSize: "var(--text-title-3)",
          color: "var(--neutral-on-surface-secondary)",
        }}
      >
        -
      </span>
    );
  }

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        gap: "8px",
      }}
    >
      {normalizedDocuments.map((doc, index) => (
        <div
          key={doc.id || `${doc.name}-${index}`}
          style={{ display: "flex", alignItems: "center", gap: "12px" }}
        >
          <DocumentTypeBadge
            fileName={doc.name}
            type={doc.type}
            size="compact"
          />
          <button
            type="button"
            onClick={() => openDocumentLink(doc, onDocumentClick)}
            style={{
              minWidth: 0,
              display: "flex",
              flexDirection: "column",
              gap: "2px",
              alignItems: "flex-start",
              background: "transparent",
              border: "none",
              padding: 0,
              cursor: "pointer",
              textAlign: "left",
            }}
          >
            <span
              style={{
                fontSize: "var(--text-title-3)",
                fontWeight: "var(--font-weight-bold)",
                color: "var(--feature-brand-primary)",
                lineHeight: "20px",
                letterSpacing: "0.09625px",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {getDocumentPrimaryLabel(doc)}
            </span>
            <span
              style={{
                fontSize: "var(--text-body)",
                color: "var(--feature-brand-primary)",
                lineHeight: "18px",
                letterSpacing: "0.0825px",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {doc.name}
            </span>
          </button>
        </div>
      ))}
    </div>
  );
};

const InputGroup = ({
  label,
  required = false,
  prefix,
  suffix,
  value,
  onChange,
  placeholder,
  disabled = false,
  type = "text",
  hasError = false,
  error,
  helperText,
  inputStyle = {},
  containerStyle = {},
  prefixStyle = {},
  suffixStyle = {},
  ...rest
}) => {
  return (
    <FormField
      label={label}
      required={required}
      error={error}
      helperText={helperText}
    >
      <UnifiedInputShell
        disabled={disabled}
        hasError={hasError || !!error}
        style={containerStyle}
        onFocus={(e) => focusInputFrame(e.currentTarget)}
        onBlur={(e) =>
          blurInputFrame(e.currentTarget, disabled, hasError || !!error)
        }
      >
        {prefix ? (
          <span
            style={{
              fontSize: "var(--text-subtitle-1)",
              color: disabled
                ? "var(--neutral-on-surface-tertiary)"
                : "var(--neutral-on-surface-secondary)",
              whiteSpace: "nowrap",
              flexShrink: 0,
              ...prefixStyle,
            }}
          >
            {prefix}
          </span>
        ) : null}

        <input
          type={type}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          disabled={disabled}
          {...rest}
          style={{
            flex: 1,
            height: "100%",
            minWidth: 0,
            border: "none",
            outline: "none",
            background: "transparent",
            padding: 0,
            fontSize: "var(--text-subtitle-1)",
            color: disabled
              ? "var(--neutral-on-surface-tertiary)"
              : value
                ? "var(--neutral-on-surface-primary)"
                : "var(--neutral-on-surface-tertiary)",
            fontFamily: "Lato, sans-serif",
            boxSizing: "border-box",
            ...inputStyle,
          }}
        />

        {suffix ? (
          <span
            style={{
              fontSize: "var(--text-subtitle-1)",
              color: disabled
                ? "var(--neutral-on-surface-tertiary)"
                : "var(--neutral-on-surface-secondary)",
              whiteSpace: "nowrap",
              flexShrink: 0,
              ...suffixStyle,
            }}
          >
            {suffix}
          </span>
        ) : null}
      </UnifiedInputShell>
    </FormField>
  );
};

const SectionCard = ({ title, children, rightAction }) => (
  <div
    style={{
      background: "var(--neutral-surface-primary)",
      borderRadius: "var(--radius-card)",
      border: "1px solid var(--neutral-line-separator-1)",
      padding: "24px",
      display: "flex",
      flexDirection: "column",
      gap: "24px",
    }}
  >
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
        <div
          style={{
            width: "4px",
            height: "20px",
            background: "var(--feature-brand-primary)",
            borderRadius: "2px",
          }}
        />
        <h2
          style={{
            margin: 0,
            fontSize: "var(--text-title-1)",
            fontWeight: "var(--font-weight-bold)",
            color: "var(--neutral-on-surface-primary)",
          }}
        >
          {title}
        </h2>
      </div>
      {rightAction ? <div>{rightAction}</div> : null}
    </div>
    {children}
  </div>
);

const Card = ({ children, style = {} }) => (
  <div
    style={{
      background: "var(--neutral-surface-primary)",
      borderRadius: "var(--radius-card)",
      border: "1px solid var(--neutral-line-separator-1)",
      padding: "24px",
      display: "flex",
      flexDirection: "column",
      gap: "20px",
      ...style,
    }}
  >
    {children}
  </div>
);

const cellStyle = (overrides) => ({
  minWidth: 0,
  height: "56px",
  padding: "0 12px",
  display: "flex",
  alignItems: "center",
  fontSize: "var(--text-title-3)",
  color: "var(--neutral-on-surface-primary)",
  ...overrides,
});

const systemTableShellStyle = {
  display: "flex",
  flexDirection: "column",
  border: "1px solid var(--neutral-line-separator-1)",
  borderRadius: "12px",
  overflow: "hidden",
  background: "var(--neutral-surface-primary)",
};

const systemTableHeaderCellStyle = (overrides = {}) => ({
  minWidth: 0,
  height: "49px",
  display: "flex",
  alignItems: "center",
  padding: "0 12px",
  fontSize: "var(--text-title-3)",
  fontWeight: "var(--font-weight-bold)",
  color: "var(--neutral-on-surface-primary)",
  boxSizing: "border-box",
  ...overrides,
});

const systemTableCellStyle = (overrides = {}) => ({
  minWidth: 0,
  minHeight: "56px",
  display: "flex",
  alignItems: "center",
  padding: "0 12px",
  fontSize: "var(--text-title-3)",
  color: "var(--neutral-on-surface-primary)",
  boxSizing: "border-box",
  ...overrides,
});

const systemTableEmptyStateStyle = {
  padding: "32px 24px",
  textAlign: "center",
  fontSize: "var(--text-title-3)",
  color: "var(--neutral-on-surface-tertiary)",
};

const poReferenceTableFrameStyle = {
  border: "none",
  borderRadius: "0",
  overflow: "hidden",
  width: "100%",
};

const poReferenceTableScrollerStyle = {
  overflowX: "auto",
  width: "100%",
};

const poReferenceTableInnerStyle = (minWidth = "100%") => ({
  minWidth,
  width: "100%",
  display: "flex",
  flexDirection: "column",
});

const poReferenceTableHeaderRowStyle = (gridTemplateColumns) => ({
  display: "grid",
  gridTemplateColumns,
  gap: "0",
  padding: "0 16px",
  height: "49px",
  alignItems: "center",
  background: "var(--neutral-surface-primary)",
  borderBottom: "1px solid var(--neutral-line-separator-1)",
  fontSize: "var(--text-title-3)",
  fontWeight: "var(--font-weight-bold)",
  color: "var(--neutral-on-surface-primary)",
});

const poReferenceTableRowStyle = (
  gridTemplateColumns,
  isLast = false,
  overrides = {}
) => ({
  display: "grid",
  gridTemplateColumns,
  gap: "0",
  padding: "0 16px",
  minHeight: "64px",
  alignItems: "center",
  borderBottom: isLast ? "none" : "1px solid var(--neutral-line-separator-1)",
  background: "var(--neutral-surface-primary)",
  ...overrides,
});

const poReferenceTableHeaderCellStyle = (overrides = {}) => ({
  minWidth: 0,
  display: "flex",
  alignItems: "center",
  ...overrides,
});

const poReferenceTableCellStyle = (overrides = {}) => ({
  minWidth: 0,
  display: "flex",
  alignItems: "center",
  fontSize: "var(--text-title-3)",
  color: "var(--neutral-on-surface-primary)",
  ...overrides,
});

const poReferenceTableEmptyStateStyle = {
  padding: "32px",
  textAlign: "center",
  fontSize: "var(--text-title-3)",
  color: "var(--neutral-on-surface-tertiary)",
  background: "var(--neutral-surface-primary)",
};

const formatCurrency = (val) => {
  if (isNaN(val) || val === null || val === undefined) return "Rp 0";
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(val);
};

const tabButtonStyle = (isActive) => ({
  height: "40px",
  padding: "0 18px",
  borderRadius: "100px",
  border: isActive
    ? "1px solid var(--feature-brand-primary)"
    : "1px solid transparent",
  background: isActive
    ? "var(--neutral-surface-primary)"
    : "rgba(255,255,255,0.56)",
  color: isActive
    ? "var(--feature-brand-primary)"
    : "var(--neutral-on-surface-secondary)",
  fontSize: "var(--text-title-3)",
  fontWeight: isActive
    ? "var(--font-weight-bold)"
    : "var(--font-weight-regular)",
  cursor: "pointer",
});

const inputFrameStyle = (disabled = false, hasError = false) => ({
  border: `1px solid ${hasError
      ? "var(--status-red-primary)"
      : disabled
        ? "var(--neutral-line-outline)"
        : baseInputBorderColor
    }`,
  borderRadius: "10px",
  background: disabled
    ? "var(--neutral-surface-grey-lighter)"
    : "var(--neutral-surface-primary)",
  transition: "border-color 0.2s ease, box-shadow 0.2s ease",
  boxSizing: "border-box",
});

const inputControlStyle = (disabled = false, hasValue = false) => ({
  width: "100%",
  outline: "none",
  fontSize: "var(--text-subtitle-1)",
  color: disabled
    ? "var(--neutral-on-surface-tertiary)"
    : hasValue
      ? "var(--neutral-on-surface-primary)"
      : "var(--neutral-on-surface-tertiary)",
  fontFamily: "Lato, sans-serif",
  boxSizing: "border-box",
});

const focusInputFrame = (el) => {
  if (!el) return;
  el.style.borderColor = "var(--feature-brand-primary)";
  el.style.boxShadow = "0 0 0 3px rgba(0, 104, 255, 0.08)";
};

const blurInputFrame = (el, disabled = false, hasError = false) => {
  if (!el) return;
  if (!el) return;
  el.style.borderColor = hasError
    ? "var(--status-red-primary)"
    : disabled
      ? "var(--neutral-line-outline)"
      : baseInputBorderColor;
  el.style.boxShadow = "none";
};

const fieldStyle = (disabled = false, hasValue = false, hasError = false) => ({
  height: "46px",
  padding: "0 16px",
  width: "100%",
  border: "none",
  background: "transparent",
  ...inputFrameStyle(disabled, hasError),
  ...inputControlStyle(disabled, hasValue),
});

const textareaFieldStyle = (
  disabled = false,
  hasValue = false,
  hasError = false
) => ({
  minHeight: "88px",
  padding: "12px 16px",
  width: "100%",
  resize: "vertical",
  border: "none",
  background: "transparent",
  ...inputFrameStyle(disabled, hasError),
  ...inputControlStyle(disabled, hasValue),
});

const selectFieldStyle = (
  disabled = false,
  hasValue = false,
  hasError = false
) => ({
  height: "46px",
  padding: "0 40px 0 16px",
  width: "100%",
  appearance: "none",
  WebkitAppearance: "none",
  MozAppearance: "none",
  cursor: disabled ? "not-allowed" : "pointer",
  border: "1px solid transparent",
  background: disabled
    ? "var(--neutral-surface-grey-lighter)"
    : "var(--neutral-surface-primary)",
  ...inputFrameStyle(disabled, hasError),
  ...inputControlStyle(disabled, hasValue),
});

const DropdownSelect = ({
  value,
  onChange,
  options = [],
  placeholder = "Select option",
  disabled = false,
  hasError = false,
  style = {},
  menuWidth,
  menuStyle = {},
  fieldHeight = "46px",
  borderRadius = "10px",
  fontSize = "var(--text-subtitle-1)",
  optionFontSize = "var(--text-title-3)",
  showSelectedCheck = true,
  emptyText = "No options found",
  renderOption = null,
  borderless = false,
  variant = "default",
}) => {
  const triggerRef = useRef(null);
  const menuRef = useRef(null);
  const [isOpen, setIsOpen] = useState(false);
  const [menuPosition, setMenuPosition] = useState({
    top: 0,
    left: 0,
    width: 0,
    placement: "bottom",
  });

  const normalizedOptions = options.map((option) =>
    typeof option === "object"
      ? option
      : { value: option, label: String(option) }
  );
  const selectedOption = normalizedOptions.find(
    (option) => String(option.value) === String(value)
  );
  const hasValue =
    selectedOption !== undefined &&
    selectedOption !== null &&
    String(selectedOption.value ?? "") !== "" &&
    String(selectedOption.value ?? "") !== "all";

  const updateMenuPosition = () => {
    if (!triggerRef.current || typeof window === "undefined") return;
    const rect = triggerRef.current.getBoundingClientRect();
    const width = Number(menuWidth) || rect.width;
    const estimatedMenuHeight = Math.min(
      16 + Math.max(normalizedOptions.length, 1) * 41,
      284
    );
    const shouldOpenAbove =
      window.innerHeight - rect.bottom < estimatedMenuHeight + 16 &&
      rect.top > estimatedMenuHeight + 16;

    setMenuPosition({
      left: rect.left,
      top: shouldOpenAbove ? rect.top - 8 : rect.bottom + 8,
      width,
      placement: shouldOpenAbove ? "top" : "bottom",
    });
  };

  useEffect(() => {
    if (!isOpen) return;

    updateMenuPosition();

    const handlePointerDown = (event) => {
      if (
        triggerRef.current?.contains(event.target) ||
        menuRef.current?.contains(event.target)
      ) {
        return;
      }
      setIsOpen(false);
    };

    const handleViewportChange = () => updateMenuPosition();

    document.addEventListener("mousedown", handlePointerDown);
    window.addEventListener("resize", handleViewportChange);
    window.addEventListener("scroll", handleViewportChange, true);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      window.removeEventListener("resize", handleViewportChange);
      window.removeEventListener("scroll", handleViewportChange, true);
    };
  }, [isOpen, menuWidth, normalizedOptions.length]);

  useEffect(() => {
    if (!isOpen || !menuRef.current || !triggerRef.current || typeof window === "undefined") return;

    const menuRect = menuRef.current.getBoundingClientRect();
    const triggerRect = triggerRef.current.getBoundingClientRect();

    if (menuPosition.placement === "bottom" && menuRect.bottom > window.innerHeight - 8) {
      setMenuPosition((prev) => ({
        ...prev,
        top: triggerRect.top - 8,
        placement: "top",
      }));
    }

    if (menuPosition.placement === "top" && menuRect.top < 8) {
      setMenuPosition((prev) => ({
        ...prev,
        top: triggerRect.bottom + 8,
        placement: "bottom",
      }));
    }
  }, [isOpen, menuPosition.placement, normalizedOptions.length]);

  const isHighlighted = variant === "filter" ? (isOpen || hasValue) : isOpen;

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        disabled={disabled}
        onClick={() => {
          if (disabled) return;
          setIsOpen((prev) => !prev);
        }}
        style={{
          width: "100%",
          minHeight: borderless ? "auto" : (variant === "filter" ? "44px" : fieldHeight),
          height: "auto",
          border: borderless ? "none" : `1px solid ${
            hasError
              ? "var(--status-red-primary)"
              : isHighlighted
                ? "var(--feature-brand-primary)"
                : disabled
                  ? "var(--neutral-line-outline)"
                  : (variant === "filter" ? "#AEAEAE" : baseInputBorderColor)
          }`,
          borderRadius: variant === "filter" ? "14px" : borderRadius,
          background: borderless ? "transparent" : (disabled
            ? "var(--neutral-surface-grey-lighter)"
            : (variant === "filter" && hasValue && !isOpen ? "#EAF1FF" : "var(--neutral-surface-primary)")),
          boxShadow: (!borderless && isOpen) ? "0 0 0 3px rgba(0, 104, 255, 0.08)" : "none",
          padding: borderless ? "4px 8px" : "0 16px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "12px",
          cursor: disabled ? "not-allowed" : "pointer",
          transition: "border-color 0.2s ease, box-shadow 0.2s ease, background 0.2s ease",
          ...style,
        }}
      >
        <span
          style={{
            flex: 1,
            minWidth: 0,
            textAlign: "left",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            fontSize,
            lineHeight: "22px",
            letterSpacing: "0.11px",
            fontWeight: (variant === "filter" && isHighlighted) ? "var(--font-weight-bold)" : "var(--font-weight-regular)",
            color: disabled
              ? "var(--neutral-on-surface-secondary)"
              : (variant === "filter" ? (isHighlighted ? "var(--feature-brand-primary)" : "#A1A1A1") : (hasValue
                ? "var(--neutral-on-surface-primary)"
                : "var(--neutral-on-surface-tertiary)")),
          }}
        >
          {hasValue ? selectedOption?.label : placeholder}
        </span>
        <ChevronDownIcon
          size={16}
          color={
            disabled
              ? "var(--neutral-on-surface-tertiary)"
              : (isHighlighted ? "var(--feature-brand-primary)" : "var(--neutral-on-surface-secondary)")
          }
          style={{
            flexShrink: 0,
            transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
            transition: "transform 0.2s ease",
          }}
        />
      </button>

      {isOpen ? (
        <div
          ref={menuRef}
          style={{
            position: "fixed",
            left: `${menuPosition.left}px`,
            top: `${menuPosition.top}px`,
            minWidth: `${menuPosition.width}px`,
            width: menuWidth ? `${menuWidth}px` : "max-content",
            maxWidth: "320px",
            transform:
              menuPosition.placement === "top" ? "translateY(-100%)" : "none",
            background: "var(--neutral-surface-primary)",
            border: "1px solid var(--neutral-line-separator-1)",
            borderRadius: "12px",
            boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.08)",
            overflow: "hidden",
            zIndex: 10000,
            ...menuStyle,
          }}
        >
          {variant === "filter" && (
            <div
              style={{
                padding: "16px 16px 8px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "12px",
                borderBottom: "1px solid var(--neutral-line-separator-1)",
                marginBottom: "4px",
              }}
            >
              <span
                style={{
                  fontSize: "var(--text-title-3)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--neutral-on-surface-primary)",
                }}
              >
                {placeholder}
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onChange?.("all");
                  setIsOpen(false);
                }}
                style={{
                  border: "none",
                  background: "transparent",
                  fontSize: "12px",
                  color: "var(--status-red-primary)",
                  cursor: "pointer",
                  padding: "4px 0",
                  fontWeight: "var(--font-weight-bold)",
                }}
              >
                Remove Filter
              </button>
            </div>
          )}
          {normalizedOptions.length > 0 ? (
            <div
              style={{
                padding: "4px 8px 8px",
                maxHeight: "284px",
                overflowY: "auto",
              }}
            >
              {normalizedOptions.map((option, index) => {
                const isAllOption = String(option.value) === "all";
                if (isAllOption && variant === "filter") return null;

                const optionSelected =
                  String(option.value) === String(value) &&
                  String(option.value ?? "") !== "";
                const optionDisabled = !!option.disabled;
                return (
                  <div key={String(option.value ?? `option-${index}`)}>
                    <button
                      type="button"
                      disabled={optionDisabled}
                      onClick={() => {
                        if (optionDisabled) return;
                        onChange?.(option.value, option);
                        setIsOpen(false);
                      }}
                      onMouseEnter={(event) => {
                        if (optionDisabled) return;
                        event.currentTarget.style.background = "var(--neutral-surface-grey-lighter)";
                      }}
                      onMouseLeave={(event) => {
                        if (optionDisabled) return;
                        event.currentTarget.style.background = "transparent";
                      }}
                      style={{
                        width: "100%",
                        minHeight: "40px",
                        padding: "8px 12px",
                        border: "none",
                        background: "transparent",
                        borderRadius: "8px",
                        display: "flex",
                        alignItems: "center",
                        gap: "12px",
                        cursor: optionDisabled ? "not-allowed" : "pointer",
                        transition: "background 0.2s ease",
                      }}
                    >
                      {variant === "filter" && (
                        <div
                          style={{
                            width: "20px",
                            height: "20px",
                            borderRadius: "4px",
                            border: `1px solid ${optionSelected ? "var(--feature-brand-primary)" : "var(--neutral-line-separator-2)"}`,
                            background: optionSelected ? "var(--feature-brand-primary)" : "transparent",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            flexShrink: 0,
                          }}
                        >
                          {optionSelected && (
                            <CheckIcon size={14} color="white" />
                          )}
                        </div>
                      )}
                      
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          flex: 1,
                          minWidth: 0,
                        }}
                      >
                        {renderOption ? (
                          renderOption(option, optionSelected)
                        ) : (
                          <span
                            style={{
                              flex: 1,
                              textAlign: "left",
                              fontSize: optionFontSize,
                              color: optionDisabled
                                ? "var(--neutral-on-surface-tertiary)"
                                : "var(--neutral-on-surface-primary)",
                              fontWeight: optionSelected ? "var(--font-weight-bold)" : "var(--font-weight-regular)",
                              whiteSpace: "nowrap",
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                            }}
                          >
                            {option.label}
                          </span>
                        )}
                      </div>

                      {(!variant || variant !== "filter") && optionSelected && showSelectedCheck && (
                        <CheckIcon
                          size={16}
                          color="var(--feature-brand-primary)"
                        />
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            <div style={{ padding: "16px" }}>
              <span
                style={{
                  display: "block",
                  textAlign: "center",
                  fontSize: "var(--text-title-3)",
                  lineHeight: "20px",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                {emptyText}
              </span>
            </div>
          )}
        </div>
      ) : null}
    </>
  );
};

// --- LAYOUT COMPONENTS ---

const Sidebar = ({
  isCollapsed,
  onToggleCollapse,
  activeModule,
  onModuleChange,
  language,
  onLanguageChange,
  t,
}) => {
  const menuItems = [
    {
      icon: DashboardIcon,
      id: "dashboard",
      label: t("sidebar.dashboard"),
      hasChildren: false,
    },
    {
      icon: ProductIcon,
      id: "product",
      label: t("sidebar.product"),
      hasChildren: true,
      children: [
        { id: "product_catalog", label: t("sidebar.product_catalog") },
        {
          id: "custom_product_request",
          label: t("sidebar.custom_product_request"),
        },
      ],
    },
    {
      icon: SalesIcon,
      id: "sales",
      label: t("sidebar.sales"),
      hasChildren: true,
      children: [
        { id: "request_for_quotes", label: t("sidebar.request_for_quotes") },
        { id: "quotes", label: t("sidebar.quotes") },
        { id: "orders", label: t("sidebar.orders") },
        { id: "invoices", label: t("sidebar.invoices") },
        { id: "customers", label: t("sidebar.customers") },
      ],
    },
    {
      icon: ResourcesIcon,
      id: "resources",
      label: t("sidebar.resources"),
      hasChildren: true,
      children: [
        { id: "material_request", label: t("sidebar.material_request") },
      ],
    },
    {
      icon: ManufacturingIcon,
      id: "manufacturing",
      label: t("sidebar.manufacturing"),
      hasChildren: true,
      children: [
        { id: "bill_of_materials", label: t("sidebar.bill_of_materials") },
        { id: "routing", label: t("sidebar.routing") },
        { id: "purchase_order", label: t("sidebar.purchase_order") },
      ],
    },
    {
      icon: AnalyticsIcon,
      id: "analytics",
      label: t("sidebar.analytics"),
      hasChildren: true,
      children: [{ id: "reports", label: t("sidebar.reports") }],
    },
    { icon: FinancingIcon, id: "financing", label: t("sidebar.financing") },
    { icon: WorkOrderIcon, id: "work_order", label: t("sidebar.work_order") },
    {
      icon: Settings,
      id: "administration",
      label: t("sidebar.administration"),
      hasChildren: true,
      children: [
        { id: "user_management", label: t("sidebar.user_management") },
        { id: "fx_management", label: t("sidebar.fx_management") },
        {
          id: "notification_settings",
          label: t("sidebar.notification_settings"),
        },
        { id: "company_settings", label: t("sidebar.company_settings") },
        { id: "labamu_staff", label: t("sidebar.labamu_staff") },
      ],
    },
    {
      icon: UserGuideIcon,
      id: "user_guide",
      label: t("sidebar.user_guide"),
      hasChildren: false,
    },
  ];

  const parentByModuleId = menuItems.reduce((acc, item) => {
    if (item.children?.length) {
      item.children.forEach((child) => {
        acc[child.id] = item.id;
      });
    }
    return acc;
  }, {});

  const activeParentId = parentByModuleId[activeModule] || null;
  const [expandedMenus, setExpandedMenus] = useState(() =>
    activeParentId ? [activeParentId] : []
  );
  const [isLanguageMenuOpen, setIsLanguageMenuOpen] = useState(false);
  const languageMenuRef = useRef(null);

  const toggleMenu = (id) => {
    setExpandedMenus((prev) =>
      prev.includes(id) ? prev.filter((menuId) => menuId !== id) : [...prev, id]
    );
  };

  useEffect(() => {
    if (!activeParentId) return;
    setExpandedMenus((prev) =>
      prev.includes(activeParentId) ? prev : [...prev, activeParentId]
    );
  }, [activeParentId]);

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (
        languageMenuRef.current &&
        !languageMenuRef.current.contains(event.target)
      ) {
        setIsLanguageMenuOpen(false);
      }
    };

    if (isLanguageMenuOpen) {
      document.addEventListener("mousedown", handleOutsideClick);
    }

    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, [isLanguageMenuOpen]);

  const activeLanguage =
    LANGUAGE_OPTIONS.find((option) => option.id === language) ||
    LANGUAGE_OPTIONS[0];
  const expandedWidth = "286px";
  const collapsedWidth = "82px";
  const expandedHeaderHeight = "64px";
  const collapsedHeaderHeight = "64px";

  return (
    <div
      style={{
        width: isCollapsed ? collapsedWidth : expandedWidth,
        transition: "width 0.2s ease",
        height: "100vh",
        position: "fixed",
        left: 0,
        top: 0,
        background: "var(--neutral-surface-primary)",
        borderRight: "1px solid var(--neutral-line-separator-1)",
        display: "flex",
        flexDirection: "column",
        zIndex: 50,
        overflowX: "hidden",
      }}
    >
      <div
        style={{
          height: isCollapsed ? collapsedHeaderHeight : expandedHeaderHeight,
          padding: isCollapsed ? "0" : "0 24px",
          borderBottom: "1px solid var(--neutral-line-separator-1)",
          display: "flex",
          alignItems: "center",
          justifyContent: isCollapsed ? "center" : "flex-start",
          flexShrink: 0,
        }}
      >
        {isCollapsed ? (
          <BrandLogoIcon size={30} title="Labamu" />
        ) : (
          <BrandLogoLockup width={172} title="Labamu Manufacturing" />
        )}
      </div>

      <div
        style={{
          flex: "1 1 auto",
          overflowY: "auto",
          display: "flex",
          flexDirection: "column",
          padding: "0",
          overflowX: "hidden",
        }}
      >
        {menuItems.map((item) => {
          const hasChildRows = !!item.children?.length;
          const isChildSelected = !!item.children?.some(
            (child) => child.id === activeModule
          );
          const isParentSelected = activeModule === item.id || isChildSelected;
          const isExpanded = hasChildRows
            ? expandedMenus.includes(item.id)
            : false;
          const rowColor = isParentSelected
            ? "var(--feature-brand-primary)"
            : "var(--neutral-on-surface-primary)";

          return (
            <div
              key={item.id}
              style={{
                borderBottom: "1px solid var(--neutral-line-separator-1)",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <div
                style={{
                  minHeight: isCollapsed ? "62px" : "52px",
                  padding: isCollapsed ? "6px 0" : "6px 16px",
                }}
              >
                <div
                  style={{
                    position: "relative",
                    minHeight: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: isCollapsed ? "center" : "stretch",
                  }}
                >
                  {isParentSelected ? (
                    <div
                      style={{
                        position: "absolute",
                        left: isCollapsed ? 0 : -16,
                        top: isCollapsed ? "7px" : "6px",
                        bottom: isCollapsed ? "7px" : "6px",
                        width: "5px",
                        borderRadius: "0 999px 999px 0",
                        background: "var(--feature-brand-primary)",
                      }}
                    />
                  ) : null}
                  <button
                    type="button"
                    onClick={() => {
                      if (item.hasChildren) {
                        if (!isCollapsed) toggleMenu(item.id);
                        return;
                      }
                      onModuleChange(item.id);
                    }}
                    style={{
                      width: isCollapsed ? "48px" : "100%",
                      height: isCollapsed ? "48px" : "40px",
                      padding: isCollapsed ? "0" : "0 16px",
                      border: "none",
                      borderRadius: isParentSelected ? "14px" : "12px",
                      background: isParentSelected
                        ? "var(--feature-brand-container-lighter)"
                        : "transparent",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: isCollapsed ? "center" : "flex-start",
                      gap: isCollapsed ? "0" : "14px",
                      cursor: "pointer",
                      color: rowColor,
                      textAlign: "left",
                    }}
                  >
                    <span
                      style={{
                        width: isCollapsed ? "20px" : "24px",
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                      }}
                    >
                      {React.createElement(item.icon, {
                        size: isCollapsed ? 20 : 21,
                        color: rowColor,
                        strokeWidth: 1.8,
                        style: { flexShrink: 0 },
                      })}
                    </span>
                    {!isCollapsed ? (
                      <span
                        style={{
                          flex: 1,
                          fontSize: "var(--text-title-2)",
                          lineHeight: 1.2,
                          fontWeight: isParentSelected
                            ? "var(--font-weight-bold)"
                            : "var(--font-weight-regular)",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {item.label}
                      </span>
                    ) : null}
                    {!isCollapsed && item.hasChildren ? (
                      <span
                        style={{
                          width: "20px",
                          display: "inline-flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                        }}
                      >
                        <ChevronDownIcon
                          size={20}
                          color={
                            isParentSelected
                              ? "var(--feature-brand-primary)"
                              : "var(--neutral-on-surface-primary)"
                          }
                          style={{
                            transform: isExpanded
                              ? "rotate(180deg)"
                              : "rotate(0deg)",
                            transition: "transform 0.2s ease",
                          }}
                        />
                      </span>
                    ) : null}
                  </button>
                </div>
              </div>

              {hasChildRows && !isCollapsed && isExpanded ? (
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "4px",
                    padding: "0 16px 16px 16px",
                  }}
                >
                  {item.children.map((child) => {
                    const isChildActive = activeModule === child.id;
                    return (
                      <button
                        key={child.id}
                        type="button"
                        onClick={() => onModuleChange(child.id)}
                        style={{
                          height: "40px",
                          padding: "0 16px 0 56px",
                          margin: 0,
                          border: "none",
                          borderRadius: isChildActive ? "14px" : "0",
                          background: isChildActive
                            ? "var(--feature-brand-container-lighter)"
                            : "transparent",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "flex-start",
                          cursor: "pointer",
                          color: isChildActive
                            ? "var(--feature-brand-primary)"
                            : "var(--neutral-on-surface-primary)",
                          fontSize: "var(--text-title-3)",
                          fontWeight: isChildActive
                            ? "var(--font-weight-bold)"
                            : "var(--font-weight-regular)",
                          textAlign: "left",
                        }}
                      >
                        {child.label}
                      </button>
                    );
                  })}
                </div>
              ) : null}
            </div>
          );
        })}
      </div>

      <div
        style={{
          borderTop: "1px solid var(--neutral-line-separator-1)",
          padding: isCollapsed ? "14px 10px 18px" : "20px 24px 24px",
          display: "flex",
          flexDirection: "column",
          gap: isCollapsed ? "16px" : "20px",
          flexShrink: 0,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: isCollapsed ? "center" : "flex-start",
          }}
        >
          <div
            onClick={onToggleCollapse}
            style={{
              width: isCollapsed ? "42px" : "56px",
              height: isCollapsed ? "42px" : "56px",
              borderRadius: "50%",
              background: "var(--feature-brand-container-lighter)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              flexShrink: 0,
              border: "1px solid var(--feature-brand-container)",
            }}
          >
            {isCollapsed ? (
              <ChevronRightIcon
                size={20}
                color="var(--neutral-on-surface-primary)"
              />
            ) : (
              <ChevronLeftIcon
                size={22}
                color="var(--neutral-on-surface-primary)"
              />
            )}
          </div>
        </div>

        <div
          ref={languageMenuRef}
          style={{
            display: "flex",
            justifyContent: "center",
            position: "relative",
          }}
        >
          {isLanguageMenuOpen ? (
            <div
              style={{
                position: "absolute",
                bottom: isCollapsed ? "72px" : "92px",
                left: 0,
                right: 0,
                background: "var(--neutral-surface-primary)",
                border: "1px solid var(--neutral-line-separator-1)",
                borderRadius: "20px",
                boxShadow: "0px 12px 32px rgba(17, 24, 39, 0.14)",
                overflow: "hidden",
                zIndex: 80,
              }}
            >
              {LANGUAGE_OPTIONS.map((option, index) => {
                const isActiveLanguage = option.id === language;
                return (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => {
                      onLanguageChange(option.id);
                      setIsLanguageMenuOpen(false);
                    }}
                    style={{
                      width: "100%",
                      minHeight: "72px",
                      border: "none",
                      background: isActiveLanguage
                        ? "var(--feature-brand-container-lighter)"
                        : "var(--neutral-surface-primary)",
                      display: "flex",
                      alignItems: "center",
                      gap: "16px",
                      padding: "0 20px",
                      cursor: "pointer",
                      borderBottom:
                        index === LANGUAGE_OPTIONS.length - 1
                          ? "none"
                          : "1px solid var(--neutral-line-separator-1)",
                    }}
                  >
                    <div
                      style={{
                        width: "28px",
                        height: "28px",
                        borderRadius: "50%",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        background: "var(--neutral-surface-primary)",
                        fontSize: "20px",
                        boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.06)",
                      }}
                    >
                      {option.flag}
                    </div>
                    <span
                      style={{
                        flex: 1,
                        textAlign: "left",
                        fontSize: "18px",
                        fontWeight: isActiveLanguage
                          ? "var(--font-weight-bold)"
                          : "var(--font-weight-regular)",
                        color: isActiveLanguage
                          ? "var(--feature-brand-primary)"
                          : "var(--neutral-on-surface-primary)",
                      }}
                    >
                      {option.label}
                    </span>
                    {isActiveLanguage ? (
                      <CheckIcon
                        size={20}
                        color="var(--feature-brand-primary)"
                      />
                    ) : null}
                  </button>
                );
              })}
            </div>
          ) : null}

          <button
            type="button"
            onClick={() => setIsLanguageMenuOpen((prev) => !prev)}
            style={{
              height: "46px",
              minHeight: "46px",
              width: isCollapsed ? "46px" : "100%",
              border: `1px solid ${isLanguageMenuOpen
                  ? "var(--feature-brand-primary)"
                  : baseInputBorderColor
                }`,
              borderRadius: "10px",
              padding: isCollapsed ? "0" : "0 16px",
              display: "flex",
              alignItems: "center",
              justifyContent: isCollapsed ? "center" : "flex-start",
              gap: "12px",
              cursor: "pointer",
              background: "var(--neutral-surface-primary)",
              boxShadow: isLanguageMenuOpen
                ? "0 0 0 3px rgba(0, 104, 255, 0.08)"
                : "none",
              boxSizing: "border-box",
              transition: "border-color 0.2s ease, box-shadow 0.2s ease",
            }}
          >
            <div
              style={{
                width: "28px",
                height: "28px",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "var(--neutral-surface-primary)",
                fontSize: "20px",
                boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.06)",
              }}
            >
              {activeLanguage.flag}
            </div>
            {!isCollapsed ? (
              <span
                style={{
                  fontSize: "var(--text-subtitle-1)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--neutral-on-surface-primary)",
                }}
              >
                {activeLanguage.shortLabel}
              </span>
            ) : null}
            {!isCollapsed ? (
              <ChevronDownIcon
                size={20}
                color="var(--neutral-on-surface-primary)"
                style={{
                  marginLeft: "auto",
                  transform: isLanguageMenuOpen
                    ? "rotate(180deg)"
                    : "rotate(0deg)",
                  transition: "transform 0.2s ease",
                }}
              />
            ) : null}
          </button>
        </div>
      </div>
    </div>
  );
};

const notificationPopoverChipStyle = (isActive) => ({
  height: "40px",
  padding: "0 16px",
  borderRadius: "999px",
  border: `1px solid ${
    isActive
      ? "var(--feature-brand-primary)"
      : "var(--neutral-line-separator-2)"
  }`,
  background: isActive
    ? "var(--feature-brand-container-lighter)"
    : "var(--neutral-surface-primary)",
  color: isActive
    ? "var(--feature-brand-primary)"
    : "var(--neutral-on-surface-secondary)",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "8px",
  cursor: "pointer",
  fontSize: "var(--text-title-2)",
  fontWeight: isActive
    ? "var(--font-weight-bold)"
    : "var(--font-weight-regular)",
  whiteSpace: "nowrap",
});

const NOTIFICATION_TIME_GROUP_ORDER = [
  "Today",
  "This Week",
  "Older Than Week",
];

const NotificationCenterIcon = ({ kind = "system_updates", unread = false }) => {
  const iconMap = {
    approvals: CheckIcon,
    operations: RoutingIcon,
    documents: DocumentIcon,
    collaboration: NotificationIcon,
    system_updates: Settings,
  };
  const paletteMap = {
    approvals: {
      background: "rgba(0, 107, 255, 0.08)",
      color: "var(--feature-brand-primary)",
    },
    operations: {
      background: "rgba(255, 145, 0, 0.12)",
      color: "var(--status-orange-primary)",
    },
    documents: {
      background: "rgba(84, 167, 63, 0.12)",
      color: "var(--status-green-primary)",
    },
    collaboration: {
      background: "rgba(120, 42, 174, 0.12)",
      color: "var(--feature-product-primary)",
    },
    system_updates: {
      background: "rgba(126, 126, 126, 0.12)",
      color: "var(--neutral-on-surface-secondary)",
    },
  };

  const Icon = iconMap[kind] || Settings;
  const palette = paletteMap[kind] || paletteMap.system_updates;

  return (
    <div
      style={{
        width: "44px",
        height: "44px",
        borderRadius: "12px",
        border: "1px solid var(--neutral-line-separator-1)",
        background: "var(--neutral-surface-primary)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
        flexShrink: 0,
      }}
    >
      <div
        style={{
          width: "24px",
          height: "24px",
          borderRadius: "8px",
          background: palette.background,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Icon size={14} color={palette.color} />
      </div>
      {unread ? (
        <div
          style={{
            position: "absolute",
            top: "-2px",
            right: "-2px",
            width: "10px",
            height: "10px",
            borderRadius: "50%",
            background: "#FF5B5B",
            border: "2px solid var(--neutral-surface-primary)",
          }}
        />
      ) : null}
    </div>
  );
};

const NotificationPreferenceCheckbox = ({
  checked = false,
  onChange,
  disabled = false,
}) => (
  <button
    type="button"
    disabled={disabled}
    onClick={() => {
      if (!disabled) onChange?.(!checked);
    }}
    style={{
      width: "28px",
      height: "28px",
      borderRadius: "4px",
      border: `1px solid ${
        checked
          ? "var(--feature-brand-primary)"
          : "var(--neutral-line-separator-2)"
      }`,
      background: checked
        ? "var(--feature-brand-primary)"
        : "var(--neutral-surface-primary)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: disabled ? "not-allowed" : "pointer",
      padding: 0,
    }}
  >
    {checked ? <CheckIcon size={16} color="#fff" /> : null}
  </button>
);

const TopHeader = ({
  t,
  isSidebarCollapsed,
  notificationSettings,
  notifications,
  onNotificationsChange,
}) => {
  const bellButtonRef = useRef(null);
  const popoverRef = useRef(null);
  const settingsButtonRef = useRef(null);
  const quickMenuRef = useRef(null);
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const [isQuickMenuOpen, setIsQuickMenuOpen] = useState(false);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [activeNotificationTab, setActiveNotificationTab] = useState("all");
  const [showAllNotifications, setShowAllNotifications] = useState(false);
  const [centerPreferences, setCenterPreferences] = useState(
    DEFAULT_NOTIFICATION_CENTER_PREFERENCES
  );
  const [draftSelectedCategories, setDraftSelectedCategories] = useState(
    DEFAULT_NOTIFICATION_CENTER_PREFERENCES.selectedCategories
  );
  const [popoverPosition, setPopoverPosition] = useState({
    top: 76,
    left: 0,
  });
  const [quickMenuPosition, setQuickMenuPosition] = useState({
    top: 120,
    left: 0,
  });

  const updatePopoverPosition = () => {
    if (!bellButtonRef.current || typeof window === "undefined") return;
    const rect = bellButtonRef.current.getBoundingClientRect();
    const width = 440;
    const nextLeft = window.innerWidth - width - 24;

    setPopoverPosition({
      top: rect.bottom + 12,
      left: nextLeft,
    });
  };

  const updateQuickMenuPosition = () => {
    if (!settingsButtonRef.current || typeof window === "undefined") return;
    const rect = settingsButtonRef.current.getBoundingClientRect();
    const width = 260;
    const nextLeft = Math.min(
      Math.max(16, rect.right - width),
      window.innerWidth - width - 16
    );

    setQuickMenuPosition({
      top: rect.bottom + 8,
      left: nextLeft,
    });
  };

  useEffect(() => {
    if (!isPopoverOpen && !isQuickMenuOpen) return undefined;

    updatePopoverPosition();
    updateQuickMenuPosition();

    const handlePointerDown = (event) => {
      if (
        bellButtonRef.current?.contains(event.target) ||
        popoverRef.current?.contains(event.target) ||
        settingsButtonRef.current?.contains(event.target) ||
        quickMenuRef.current?.contains(event.target)
      ) {
        return;
      }
      setIsPopoverOpen(false);
      setIsQuickMenuOpen(false);
    };

    const handleViewportChange = () => {
      updatePopoverPosition();
      updateQuickMenuPosition();
    };

    document.addEventListener("mousedown", handlePointerDown);
    window.addEventListener("resize", handleViewportChange);
    window.addEventListener("scroll", handleViewportChange, true);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      window.removeEventListener("resize", handleViewportChange);
      window.removeEventListener("scroll", handleViewportChange, true);
    };
  }, [isPopoverOpen, isQuickMenuOpen]);

  const enabledRuleIds = getEnabledNotificationRuleIds(notificationSettings);
  const settingsFilteredNotifications = (notifications || []).filter((item) =>
    enabledRuleIds.has(item.ruleId)
  );
  const deliveryFilteredNotifications = centerPreferences.pushNotifications
    ? settingsFilteredNotifications
    : settingsFilteredNotifications.filter((item) => item.channel !== "push");
  const baseVisibleNotifications = deliveryFilteredNotifications.filter(
    (item) => !centerPreferences.hideRead || item.unread
  );
  const categoryFilteredNotifications = baseVisibleNotifications.filter(
    (item) =>
      centerPreferences.selectedCategories.includes(item.category) &&
      (activeNotificationTab === "all" || item.category === activeNotificationTab)
  );
  const visibleNotifications = showAllNotifications
    ? categoryFilteredNotifications
    : categoryFilteredNotifications.slice(0, 5);

  const unreadCount = deliveryFilteredNotifications.filter(
    (item) => item.unread
  ).length;

  const chipOptions = [
    { id: "all", label: "All" },
    ...NOTIFICATION_CATEGORY_OPTIONS.filter((option) =>
      centerPreferences.selectedCategories.includes(option.id)
    ),
  ];

  const chipCountMap = chipOptions.reduce((acc, option) => {
    acc[option.id] =
      option.id === "all"
        ? baseVisibleNotifications.length
        : baseVisibleNotifications.filter(
            (item) => item.category === option.id
          ).length;
    return acc;
  }, {});

  const groupedVisibleNotifications = NOTIFICATION_TIME_GROUP_ORDER.map(
    (timeGroup) => ({
      timeGroup,
      items: visibleNotifications.filter((item) => item.timeGroup === timeGroup),
    })
  ).filter((group) => group.items.length > 0);

  const selectedCategoryCount = centerPreferences.selectedCategories.length;
  const isAllCategorySelected =
    selectedCategoryCount === NOTIFICATION_CATEGORY_OPTIONS.length;

  const markAllAsRead = () => {
    const targetIds = new Set(deliveryFilteredNotifications.map((item) => item.id));
    onNotificationsChange?.((prev) =>
      prev.map((item) =>
        targetIds.has(item.id) ? { ...item, unread: false } : item
      )
    );
  };

  const toggleNotificationRead = (notificationId) => {
    onNotificationsChange?.((prev) =>
      prev.map((item) =>
        item.id === notificationId
          ? { ...item, unread: !item.unread }
          : item
      )
    );
  };

  const saveFilterPreferences = () => {
    setCenterPreferences((prev) => ({
      ...prev,
      selectedCategories: [...draftSelectedCategories],
    }));
    setActiveNotificationTab("all");
    setIsFilterModalOpen(false);
  };

  const hasNotifications = categoryFilteredNotifications.length > 0;

  return (
    <>
      <div
        style={{
          height: "64px",
          padding: "0 24px",
          background: "var(--neutral-surface-primary)",
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
          borderBottom: "1px solid var(--neutral-line-separator-1)",
          position: "fixed",
          top: 0,
          left: isSidebarCollapsed ? "82px" : "286px",
          right: 0,
          zIndex: 40,
          transition: "left 0.2s ease",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "24px" }}>
          <button
            ref={bellButtonRef}
            type="button"
            onClick={() => {
              setIsPopoverOpen((prev) => !prev);
              setIsQuickMenuOpen(false);
            }}
            style={{
              width: "40px",
              height: "40px",
              borderRadius: "999px",
              border: "1px solid var(--neutral-line-separator-1)",
              background: "var(--neutral-surface-primary)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              position: "relative",
            }}
          >
            <NotificationIcon
              size={18}
              color="var(--neutral-on-surface-primary)"
            />
            {unreadCount > 0 ? (
              <div
                style={{
                  position: "absolute",
                  top: "-6px",
                  right: "-6px",
                  minWidth: "22px",
                  height: "22px",
                  borderRadius: "999px",
                  background: "#FF5B5B",
                  color: "#fff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  padding: "0 6px",
                  boxSizing: "border-box",
                  fontSize: "12px",
                  fontWeight: "var(--font-weight-bold)",
                  border: "2px solid var(--neutral-surface-primary)",
                }}
              >
                {unreadCount}
              </div>
            ) : null}
          </button>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              cursor: "pointer",
            }}
          >
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-end",
              }}
            >
              <span
                style={{
                  fontSize: "var(--text-title-3)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--neutral-on-surface-primary)",
                }}
              >
                Natasha Smith
              </span>
              <span
                style={{
                  fontSize: "var(--text-body)",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                {t("role.owner")}
              </span>
            </div>
            <ChevronDownIcon
              size={16}
              color="var(--neutral-on-surface-tertiary)"
            />
          </div>
        </div>
      </div>

      {isPopoverOpen ? (
        <div
          ref={popoverRef}
          style={{
            position: "fixed",
            top: `${popoverPosition.top}px`,
            left: `${popoverPosition.left}px`,
            width: "440px",
            maxWidth: "calc(100vw - 32px)",
            maxHeight: "80vh",
            background: "var(--neutral-surface-primary)",
            border: "1px solid var(--neutral-line-separator-1)",
            borderRadius: "16px",
            boxShadow: "var(--elevation-sm)",
            zIndex: 120,
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              padding: "20px 24px 16px",
              display: "flex",
              flexDirection: "column",
              gap: "16px",
              borderBottom: "1px solid var(--neutral-line-separator-1)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: "12px",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <span
                  style={{
                    fontSize: "var(--text-headline)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  Notification
                </span>
                <StatusBadge variant="red">{unreadCount}</StatusBadge>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <button
                  type="button"
                  onClick={markAllAsRead}
                  disabled={unreadCount === 0}
                  style={{
                    border: "none",
                    background: "transparent",
                    color:
                      unreadCount === 0
                        ? "var(--neutral-on-surface-tertiary)"
                        : "var(--feature-brand-primary)",
                    fontSize: "var(--text-title-2)",
                    cursor: unreadCount === 0 ? "not-allowed" : "pointer",
                  }}
                >
                  Mark All as Read
                </button>
                <button
                  ref={settingsButtonRef}
                  type="button"
                  onClick={() => setIsQuickMenuOpen((prev) => !prev)}
                  style={{
                    width: "32px",
                    height: "32px",
                    borderRadius: "8px",
                    border: "1px solid var(--neutral-line-separator-1)",
                    background: "var(--neutral-surface-primary)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                  }}
                >
                  <Settings
                    size={16}
                    color="var(--neutral-on-surface-primary)"
                  />
                </button>
              </div>
            </div>

            <div
              className="no-scrollbar"
              style={{
                display: "flex",
                gap: "8px",
                flexWrap: "nowrap",
                overflowX: "auto",
                paddingBottom: "4px",
                margin: "0 -4px",
                paddingLeft: "4px",
              }}
            >
              {chipOptions.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => {
                    setActiveNotificationTab(option.id);
                    setShowAllNotifications(false);
                  }}
                  style={notificationPopoverChipStyle(
                    activeNotificationTab === option.id
                  )}
                >
                  <span>{option.label}</span>
                  <span>{chipCountMap[option.id] || 0}</span>
                </button>
              ))}
            </div>
          </div>

          <div
            style={{
              flex: 1,
              overflow: "auto",
              padding: "8px 24px 0",
              display: "flex",
              flexDirection: "column",
              gap: "8px",
            }}
          >
            {hasNotifications ? (
              groupedVisibleNotifications.map((group) => (
                <div
                  key={group.timeGroup}
                  style={{ display: "flex", flexDirection: "column", gap: "6px" }}
                >
                  <span
                    style={{
                      padding: "12px 0 6px",
                      fontSize: "var(--text-title-2)",
                      fontWeight: "var(--font-weight-bold)",
                    }}
                  >
                    {group.timeGroup}
                  </span>

                  {group.items.map((item, index) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        if (item.unread) {
                          onNotificationsChange?.((prev) =>
                            prev.map((entry) =>
                              entry.id === item.id
                                ? { ...entry, unread: false }
                                : entry
                            )
                          );
                        }
                      }}
                      style={{
                        width: "100%",
                        border: "none",
                        background: "transparent",
                        padding: "12px 0",
                        display: "grid",
                        gridTemplateColumns: "44px minmax(0, 1fr) 32px",
                        gap: "14px",
                        textAlign: "left",
                        cursor: "pointer",
                        borderTop:
                          index === 0
                            ? "1px solid var(--neutral-line-separator-1)"
                            : "1px solid var(--neutral-line-separator-1)",
                      }}
                    >
                      <NotificationCenterIcon
                        kind={item.icon}
                        unread={item.unread}
                      />
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "6px",
                          minWidth: 0,
                        }}
                      >
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            lineHeight: "24px",
                            color: "var(--neutral-on-surface-primary)",
                          }}
                        >
                          {item.headline}
                        </span>
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            lineHeight: "20px",
                            color: "var(--neutral-on-surface-secondary)",
                          }}
                        >
                          {item.detail}
                        </span>
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            lineHeight: "18px",
                            color: "var(--neutral-on-surface-tertiary)",
                          }}
                        >
                          {item.meta}
                        </span>
                      </div>
                      <IconButton
                        icon={MoreVerticalIcon}
                        size="small"
                        onClick={(event) => {
                          event.stopPropagation();
                          toggleNotificationRead(item.id);
                        }}
                        title={item.unread ? "Mark as read" : "Mark as unread"}
                        color="var(--neutral-on-surface-secondary)"
                      />
                    </button>
                  ))}
                </div>
              ))
            ) : (
              <div
                style={{
                  padding: "56px 0 48px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "8px",
                }}
              >
                <NotificationIcon
                  size={24}
                  color="var(--neutral-on-surface-tertiary)"
                />
                <span
                  style={{
                    fontSize: "var(--text-title-1)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  No new notifications
                </span>
                <span
                  style={{
                    fontSize: "var(--text-title-3)",
                    color: "var(--neutral-on-surface-secondary)",
                  }}
                >
                  You're all caught up.
                </span>
              </div>
            )}
          </div>

          <div
            style={{
              padding: "16px 24px 24px",
              borderTop: "1px solid var(--neutral-line-separator-1)",
              display: "flex",
              flexDirection: "column",
              gap: "12px",
              alignItems: "center",
            }}
          >
            <span
              style={{
                fontSize: "var(--text-title-3)",
                color: "var(--neutral-on-surface-secondary)",
              }}
            >
              Showing {visibleNotifications.length} out of{" "}
              {categoryFilteredNotifications.length} notifications
            </span>
            <Button
              variant="outlined"
              size="medium"
              style={{ width: "100%" }}
              onClick={() => setShowAllNotifications((prev) => !prev)}
              disabled={categoryFilteredNotifications.length <= 5}
            >
              {showAllNotifications ? "Show Less" : "View All Notifications"}
            </Button>
          </div>
        </div>
      ) : null}

      {isQuickMenuOpen ? (
        <div
          ref={quickMenuRef}
          style={{
            position: "fixed",
            top: `${quickMenuPosition.top}px`,
            left: `${quickMenuPosition.left}px`,
            width: "260px",
            background: "var(--neutral-surface-primary)",
            border: "1px solid var(--neutral-line-separator-1)",
            borderRadius: "16px",
            boxShadow: "var(--elevation-sm)",
            zIndex: 130,
            overflow: "hidden",
          }}
        >
          <div
            style={{
              padding: "20px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
            }}
          >
            {[
              {
                label: "Hide All Read",
                checked: centerPreferences.hideRead,
                onChange: (checked) =>
                  setCenterPreferences((prev) => ({
                    ...prev,
                    hideRead: checked,
                  })),
              },
              {
                label: "Push Notifications",
                checked: centerPreferences.pushNotifications,
                onChange: (checked) =>
                  setCenterPreferences((prev) => ({
                    ...prev,
                    pushNotifications: checked,
                  })),
              },
            ].map((row) => (
              <div
                key={row.label}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: "12px",
                }}
              >
                <span style={{ fontSize: "var(--text-title-2)" }}>{row.label}</span>
                <ToggleSwitch checked={row.checked} onChange={row.onChange} />
              </div>
            ))}

            <button
              type="button"
              onClick={() => {
                setDraftSelectedCategories([
                  ...centerPreferences.selectedCategories,
                ]);
                setIsFilterModalOpen(true);
                setIsQuickMenuOpen(false);
              }}
              style={{
                border: "none",
                background: "transparent",
                padding: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                cursor: "pointer",
                fontSize: "var(--text-title-2)",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              <span>Filter Preferences</span>
              <Settings size={18} color="var(--neutral-on-surface-primary)" />
            </button>
          </div>
        </div>
      ) : null}

      {isFilterModalOpen ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 140,
          }}
        >
          <div
            style={{
              width: "540px",
              maxWidth: "calc(100vw - 32px)",
              background: "var(--neutral-surface-primary)",
              borderRadius: "20px",
              boxShadow: "var(--elevation-sm)",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                padding: "22px 24px",
                borderBottom: "1px solid var(--neutral-line-separator-1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "16px",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <NotificationIcon
                  size={18}
                  color="var(--feature-brand-primary)"
                />
                <span
                  style={{
                    fontSize: "var(--text-headline)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  Notification Filters
                </span>
              </div>
              <IconButton
                icon={CloseIcon}
                size="small"
                onClick={() => setIsFilterModalOpen(false)}
              />
            </div>

            <div
              style={{
                padding: "24px",
                display: "flex",
                flexDirection: "column",
                gap: "16px",
              }}
            >
              <p
                style={{
                  margin: 0,
                  fontSize: "var(--text-title-1)",
                  lineHeight: "28px",
                  color: "var(--neutral-on-surface-primary)",
                }}
              >
                Kindly indicate the notifications you wish to receive.
              </p>

              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  borderTop: "1px solid var(--neutral-line-separator-1)",
                }}
              >
                {[
                  {
                    id: "all",
                    label: "All Notifications",
                    checked: isAllCategorySelected,
                    onChange: (checked) =>
                      setDraftSelectedCategories(
                        checked
                          ? NOTIFICATION_CATEGORY_OPTIONS.map(
                              (category) => category.id
                            )
                          : []
                      ),
                  },
                  ...NOTIFICATION_CATEGORY_OPTIONS.map((category) => ({
                    id: category.id,
                    label: category.label,
                    checked: draftSelectedCategories.includes(category.id),
                    onChange: (checked) =>
                      setDraftSelectedCategories((prev) =>
                        checked
                          ? [...prev, category.id]
                          : prev.filter((item) => item !== category.id)
                      ),
                  })),
                ].map((item) => (
                  <div
                    key={item.id}
                    style={{
                      minHeight: "58px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      gap: "16px",
                      borderBottom: "1px solid var(--neutral-line-separator-1)",
                    }}
                  >
                    <span style={{ fontSize: "var(--text-title-2)" }}>
                      {item.label}
                    </span>
                    <NotificationPreferenceCheckbox
                      checked={item.checked}
                      onChange={item.onChange}
                    />
                  </div>
                ))}
              </div>

              <p
                style={{
                  margin: 0,
                  fontSize: "var(--text-title-3)",
                  lineHeight: "22px",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                Deselected notifications will not show up in your notification
                center.
              </p>
            </div>

            <div
              style={{
                padding: "20px 24px 24px",
                display: "flex",
                justifyContent: "flex-end",
                gap: "12px",
                borderTop: "1px solid var(--neutral-line-separator-1)",
              }}
            >
              <Button
                variant="outlined"
                size="medium"
                onClick={() => setIsFilterModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="filled"
                size="medium"
                onClick={saveFilterPreferences}
              >
                Save Changes
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
};

// --- MODULE: WORK ORDER ---

const WorkOrderList = ({ onNavigate, t }) => {
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [openFilterKey, setOpenFilterKey] = useState(null);
  const [priorityFilters, setPriorityFilters] = useState([]);
  const [creatorFilters, setCreatorFilters] = useState([]);
  const [startDateFilterType, setStartDateFilterType] = useState("all");
  const [startDateRange, setStartDateRange] = useState({ start: "", end: "" });
  const [endDateFilterType, setEndDateFilterType] = useState("all");
  const [endDateRange, setEndDateRange] = useState({ start: "", end: "" });
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [currentPage, setCurrentPage] = useState(1);
  const statusCards = [
    {
      key: "not_started",
      label: t("work_order.summary.not_started"),
      badgeVariant: "grey-light",
    },
    {
      key: "ready_to_process",
      label: t("work_order.summary.ready_to_process"),
      badgeVariant: "blue-light",
    },
    {
      key: "in_progress",
      label: t("work_order.summary.in_progress"),
      badgeVariant: "yellow-light",
    },
    {
      key: "completed",
      label: t("work_order.summary.completed"),
      badgeVariant: "green-light",
    },
    {
      key: "canceled",
      label: t("work_order.summary.canceled"),
      badgeVariant: "red-light",
    },
  ];
  const tableColumns = [
    { label: "Work Order No.", flex: "1.6" },
    { label: "Order Number", flex: "1.6" },
    { label: "Product", flex: "1.4" },
    { label: "Qty", flex: "0.6" },
    { label: "Priority", flex: "0.8" },
    { label: "Planned Start Date", flex: "1.2" },
    { label: "Planned End Date", flex: "1.2" },
    { label: "Created By", flex: "1" },
    { label: "Status", flex: "1.2" },
  ];
  const statusCounts = statusCards.reduce((acc, card) => {
    acc[card.key] = MOCK_WO_TABLE_DATA.filter(
      (row) => row.statusKey === card.key
    ).length;
    return acc;
  }, {});

  const parsedDate = (value) => {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? null : d;
  };
  const referenceNow = new Date("2026-03-31");
  const matchesDateFilter = (rowDateValue, filterType, customRange) => {
    if (filterType === "all") return true;
    const rowDate = parsedDate(rowDateValue);
    if (!rowDate) return false;

    if (filterType === "last7") {
      const start = new Date(referenceNow);
      start.setDate(referenceNow.getDate() - 7);
      return rowDate >= start && rowDate <= referenceNow;
    }
    if (filterType === "last30") {
      const start = new Date(referenceNow);
      start.setDate(referenceNow.getDate() - 30);
      return rowDate >= start && rowDate <= referenceNow;
    }
    if (filterType === "custom" && customRange.start && customRange.end) {
      const start = parsedDate(customRange.start);
      const end = parsedDate(customRange.end);
      if (start && end) return rowDate >= start && rowDate <= end;
      return false;
    }
    return true;
  };
  const priorityOptions = Array.from(
    new Set(MOCK_WO_TABLE_DATA.map((row) => row.priority))
  );
  const creatorOptions = Array.from(
    new Set(MOCK_WO_TABLE_DATA.map((row) => row.createdBy))
  );
  const toggleMultiFilter = (value, setter) => {
    setter((prev) =>
      prev.includes(value) ? prev.filter((item) => item !== value) : [...prev, value]
    );
  };

  const filteredRows = MOCK_WO_TABLE_DATA.filter((row) => {
    const matchesStatus =
      selectedStatus === "all" || row.statusKey === selectedStatus;
    const haystack =
      `${row.wo} ${row.ord} ${row.product} ${row.createdBy} ${row.priority}`.toLowerCase();
    const matchesSearch =
      !searchQuery || haystack.includes(searchQuery.toLowerCase());
    const matchesPriority =
      priorityFilters.length === 0 || priorityFilters.includes(row.priority);
    const matchesCreator =
      creatorFilters.length === 0 || creatorFilters.includes(row.createdBy);
    const matchesStartDate = matchesDateFilter(
      row.start,
      startDateFilterType,
      startDateRange
    );
    const matchesEndDate = matchesDateFilter(
      row.end,
      endDateFilterType,
      endDateRange
    );
    return (
      matchesStatus &&
      matchesSearch &&
      matchesPriority &&
      matchesCreator &&
      matchesStartDate &&
      matchesEndDate
    );
  });

  const totalPages = Math.max(1, Math.ceil(filteredRows.length / rowsPerPage));
  const visibleRows = filteredRows.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );
  const workOrderTableBodyMaxHeight = "calc(100vh - 412px)";

  useEffect(() => {
    setCurrentPage(1);
  }, [
    selectedStatus,
    searchQuery,
    priorityFilters.join("|"),
    creatorFilters.join("|"),
    startDateFilterType,
    startDateRange.start,
    startDateRange.end,
    endDateFilterType,
    endDateRange.start,
    endDateRange.end,
    rowsPerPage,
  ]);

  useEffect(() => {
    setCurrentPage((prev) => Math.min(prev, totalPages));
  }, [totalPages]);

  return (
    <div
      style={{
        height: "calc(100vh - 64px)",
        padding: "24px",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        gap: "24px",
        overflow: "hidden",
        minHeight: 0,
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <h1
          style={{
            margin: "0",
            fontSize: "var(--text-big-title)",
            fontWeight: "var(--font-weight-bold)",
          }}
        >
          {t("work_order.title")}
        </h1>
        <Button variant="outlined" leftIcon={Settings}>
          {t("work_order.settings")}
        </Button>
      </div>

      <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
        {statusCards.map((card) => (
          <ListStatusCounterCard
            key={card.key}
            label={card.label}
            count={statusCounts[card.key] || 0}
            badgeVariant={card.badgeVariant}
            active={selectedStatus === card.key}
            onClick={() =>
              setSelectedStatus((prev) =>
                prev === card.key ? "all" : card.key
              )
            }
          />
        ))}
      </div>

      <div
        style={{
          background: "var(--neutral-surface-primary)",
          borderRadius: "var(--radius-card)",
          border: "1px solid var(--neutral-line-separator-1)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          minHeight: 0,
        }}
      >
        <div
          style={{
            padding: "16px 20px",
            borderBottom: "1px solid var(--neutral-line-separator-2)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "12px",
            flexShrink: 0,
          }}
        >
          <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
            <div
              style={{
                display: "flex",
                gap: "12px",
                flexWrap: "wrap",
                position: "relative",
              }}
            >
              <div
                onClick={() =>
                  setOpenFilterKey((prev) => (prev === "priority" ? null : "priority"))
                }
              >
                <FilterPill
                  label="Priority"
                  active={priorityFilters.length > 0}
                  isOpen={openFilterKey === "priority"}
                  count={priorityFilters.length}
                />
              </div>
              <div
                onClick={() =>
                  setOpenFilterKey((prev) => (prev === "start" ? null : "start"))
                }
              >
                <FilterPill
                  label="Planned Start Date"
                  active={startDateFilterType !== "all"}
                  isOpen={openFilterKey === "start"}
                  count={startDateFilterType !== "all" ? 1 : 0}
                />
              </div>
              <div
                onClick={() =>
                  setOpenFilterKey((prev) => (prev === "end" ? null : "end"))
                }
              >
                <FilterPill
                  label="Planned End Date"
                  active={endDateFilterType !== "all"}
                  isOpen={openFilterKey === "end"}
                  count={endDateFilterType !== "all" ? 1 : 0}
                />
              </div>
              <div
                onClick={() =>
                  setOpenFilterKey((prev) => (prev === "creator" ? null : "creator"))
                }
              >
                <FilterPill
                  label="Created By"
                  active={creatorFilters.length > 0}
                  isOpen={openFilterKey === "creator"}
                  count={creatorFilters.length}
                />
              </div>

              {openFilterKey ? (
                <>
                  <div
                    style={{ position: "fixed", inset: 0, zIndex: 80 }}
                    onClick={() => setOpenFilterKey(null)}
                  />
                  <div
                    style={{
                      position: "absolute",
                      top: "calc(100% + 8px)",
                      left:
                        openFilterKey === "priority"
                          ? 0
                          : openFilterKey === "start"
                            ? 112
                            : openFilterKey === "end"
                              ? 287
                              : 448,
                      width: "360px",
                      background: "var(--neutral-surface-primary)",
                      border: "1px solid var(--neutral-line-separator-1)",
                      borderRadius: "var(--radius-card)",
                      boxShadow: "var(--elevation-sm)",
                      padding: "16px",
                      display: "flex",
                      flexDirection: "column",
                      gap: "16px",
                      zIndex: 81,
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <span
                        style={{
                          fontSize: "var(--text-title-2)",
                          fontWeight: "var(--font-weight-bold)",
                        }}
                      >
                        {openFilterKey === "priority"
                          ? "Priority"
                          : openFilterKey === "creator"
                            ? "Created By"
                            : openFilterKey === "start"
                              ? "Planned Start Date"
                              : "Planned End Date"}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          if (openFilterKey === "priority") setPriorityFilters([]);
                          if (openFilterKey === "creator") setCreatorFilters([]);
                          if (openFilterKey === "start") {
                            setStartDateFilterType("all");
                            setStartDateRange({ start: "", end: "" });
                          }
                          if (openFilterKey === "end") {
                            setEndDateFilterType("all");
                            setEndDateRange({ start: "", end: "" });
                          }
                        }}
                        style={{
                          background: "none",
                          border: "none",
                          padding: 0,
                          color: "var(--status-red-primary)",
                          cursor: "pointer",
                          fontSize: "var(--text-body)",
                          fontWeight: "var(--font-weight-bold)",
                        }}
                      >
                        Remove Filter
                      </button>
                    </div>

                    {openFilterKey === "priority" || openFilterKey === "creator" ? (
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "12px",
                        }}
                      >
                        {(openFilterKey === "priority"
                          ? priorityOptions
                          : creatorOptions
                        ).map((option) => {
                          const selectedList =
                            openFilterKey === "priority"
                              ? priorityFilters
                              : creatorFilters;
                          const selectedSetter =
                            openFilterKey === "priority"
                              ? setPriorityFilters
                              : setCreatorFilters;
                          return (
                            <label
                              key={option}
                              style={{
                                display: "flex",
                                alignItems: "center",
                                gap: "12px",
                                cursor: "pointer",
                                fontSize: "var(--text-title-3)",
                              }}
                            >
                              <Checkbox
                                checked={selectedList.includes(option)}
                                onChange={() => toggleMultiFilter(option, selectedSetter)}
                              />
                              <span>{option}</span>
                            </label>
                          );
                        })}
                      </div>
                    ) : (
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "12px",
                        }}
                      >
                        {[
                          { key: "all", label: "All" },
                          { key: "last7", label: "Last 7 days" },
                          { key: "last30", label: "Last 30 days" },
                          { key: "custom", label: "Custom date" },
                        ].map((option) => {
                          const activeValue =
                            openFilterKey === "start"
                              ? startDateFilterType
                              : endDateFilterType;
                          const setter =
                            openFilterKey === "start"
                              ? setStartDateFilterType
                              : setEndDateFilterType;
                          return (
                            <label
                              key={option.key}
                              style={{
                                display: "flex",
                                alignItems: "center",
                                gap: "12px",
                                cursor: "pointer",
                                fontSize: "var(--text-title-3)",
                              }}
                            >
                              <input
                                type="radio"
                                checked={activeValue === option.key}
                                onChange={() => setter(option.key)}
                              />
                              <span>{option.label}</span>
                            </label>
                          );
                        })}

                        {(openFilterKey === "start"
                          ? startDateFilterType
                          : endDateFilterType) === "custom" ? (
                          <div
                            style={{
                              display: "grid",
                              gridTemplateColumns: "1fr 1fr",
                              gap: "8px",
                            }}
                          >
                            <DateInputControl
                              value={
                                openFilterKey === "start"
                                  ? startDateRange.start
                                  : endDateRange.start
                              }
                              onChange={(e) => {
                                const nextValue = e.target.value;
                                if (openFilterKey === "start") {
                                  setStartDateRange((prev) => ({
                                    ...prev,
                                    start: nextValue,
                                  }));
                                } else {
                                  setEndDateRange((prev) => ({
                                    ...prev,
                                    start: nextValue,
                                  }));
                                }
                              }}
                              fieldHeight="40px"
                              borderRadius="12px"
                              fontSize="var(--text-title-3)"
                            />
                            <DateInputControl
                              value={
                                openFilterKey === "start"
                                  ? startDateRange.end
                                  : endDateRange.end
                              }
                              onChange={(e) => {
                                const nextValue = e.target.value;
                                if (openFilterKey === "start") {
                                  setStartDateRange((prev) => ({
                                    ...prev,
                                    end: nextValue,
                                  }));
                                } else {
                                  setEndDateRange((prev) => ({
                                    ...prev,
                                    end: nextValue,
                                  }));
                                }
                              }}
                              fieldHeight="40px"
                              borderRadius="12px"
                              fontSize="var(--text-title-3)"
                            />
                          </div>
                        ) : null}
                      </div>
                    )}
                  </div>
                </>
              ) : null}
            </div>
          </div>
          <TableSearchField
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search work order number"
            width="360px"
          />
        </div>

        <div
          style={{
            maxHeight: workOrderTableBodyMaxHeight,
            overflow: "auto",
            width: "100%",
          }}
        >
          <div
            style={{
              minWidth: "1050px",
              width: "100%",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                display: "flex",
                background: "var(--neutral-surface-primary)",
                borderBottom: "1px solid var(--neutral-line-separator-1)",
                position: "sticky",
                top: 0,
                zIndex: 20,
              }}
            >
              {tableColumns.map((col, idx) => (
                <div
                  key={idx}
                  style={{
                    flex: col.flex,
                    minWidth: 0,
                    height: "49px",
                    padding: "0 12px",
                    display: "flex",
                    alignItems: "center",
                    fontSize: "var(--text-title-3)",
                    fontWeight: "var(--font-weight-bold)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  <span
                    style={{
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {col.label}
                  </span>
                </div>
              ))}
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                flex: filteredRows.length === 0 ? 1 : "0 0 auto",
              }}
            >
              {visibleRows.map((row, rIdx) => (
                <div
                  key={rIdx}
                  onClick={() => onNavigate("detail", row)}
                  style={{
                    display: "flex",
                    background: "var(--neutral-surface-primary)",
                    borderBottom: "1px solid var(--neutral-line-separator-1)",
                    transition: "background 0.12s ease",
                    cursor: "pointer",
                  }}
                  onMouseEnter={(e) =>
                  (e.currentTarget.style.background =
                    "var(--neutral-surface-grey-lighter)")
                  }
                  onMouseLeave={(e) =>
                  (e.currentTarget.style.background =
                    "var(--neutral-surface-primary)")
                  }
                >
                  <div
                    style={cellStyle({
                      flex: tableColumns[0].flex,
                      color: "var(--feature-brand-primary)",
                    })}
                  >
                    <span
                      style={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {row.wo}
                    </span>
                  </div>
                  <div style={cellStyle({ flex: tableColumns[1].flex })}>
                    <span
                      style={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {row.ord}
                    </span>
                  </div>
                  <div style={cellStyle({ flex: tableColumns[2].flex })}>
                    <span
                      style={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {row.product}
                    </span>
                  </div>
                  <div style={cellStyle({ flex: tableColumns[3].flex })}>
                    {row.qty}
                  </div>
                  <div
                    style={cellStyle({
                      flex: tableColumns[4].flex,
                      color: row.pColor,
                    })}
                  >
                    {row.priority}
                  </div>
                  <div style={cellStyle({ flex: tableColumns[5].flex })}>
                    <span
                      style={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {row.start}
                    </span>
                  </div>
                  <div style={cellStyle({ flex: tableColumns[6].flex })}>
                    <span
                      style={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {row.end}
                    </span>
                  </div>
                  <div style={cellStyle({ flex: tableColumns[7].flex })}>
                    <span
                      style={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {row.createdBy}
                    </span>
                  </div>
                  <div style={cellStyle({ flex: tableColumns[8].flex })}>
                    <StatusBadge variant={row.sBadge}>{row.status}</StatusBadge>
                  </div>
                </div>
              ))}

              {filteredRows.length === 0 ? (
                <div
                  style={{
                    flex: 1,
                    padding: "32px",
                    textAlign: "center",
                    color: "var(--neutral-on-surface-tertiary)",
                    fontSize: "var(--text-title-3)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  No work orders found.
                </div>
              ) : null}
            </div>
          </div>
        </div>

        <TablePaginationFooter
          totalRows={filteredRows.length}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={setRowsPerPage}
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      </div>
    </div>
  );
};

const WorkOrderDetail = ({ onNavigate, isSidebarCollapsed, initialData }) => {
  const scrollToTop = () => {
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "auto" });
    }
  };
  const TOTAL_QTY = initialData?.qty || 100;

  const [displayStartDate, setDisplayStartDate] = useState(
    initialData?.start || ""
  );
  const [displayEndDate, setDisplayEndDate] = useState(initialData?.end || "");
  const WORK_ORDER_END_DATE = displayEndDate || "2026-01-08";
  const resolveVendorProgressStatus = (vendor) => {
    const rawStatus =
      vendor?.status === "Received" ? "Completed" : vendor?.status || "Waiting";
    if (vendor?.name === "Internal") return rawStatus;

    const assignedOutput = parseInt(vendor?.output || 0, 10) || 0;
    const receivedOutput = parseInt(vendor?.receivedOutput || 0, 10) || 0;

    if (assignedOutput > 0 && receivedOutput >= assignedOutput)
      return "Completed";
    if (receivedOutput > 0) return "Partially Received";
    if (
      rawStatus === "Completed" ||
      rawStatus === "Partially Received" ||
      rawStatus === "In Progress"
    )
      return rawStatus;
    if (
      vendor?.isPoApproved ||
      vendor?.poStatus === "Issued" ||
      vendor?.poStatus === "Completed"
    )
      return "In Progress";
    return rawStatus;
  };

  const [outsourceSteps, setOutsourceSteps] = useState(
    initialData?.outsourceSteps || []
  );
  const [isReadyModalOpen, setIsReadyModalOpen] = useState(false);
  const [isConfirmReadyModalOpen, setIsConfirmReadyModalOpen] = useState(false);
  const [isManageStageModalOpen, setIsManageStageModalOpen] = useState(false);
  const [selectedStage, setSelectedStage] = useState(null);

  const [isSingleVendorModalOpen, setIsSingleVendorModalOpen] = useState(false);
  const [isCreatePoModalOpen, setIsCreatePoModalOpen] = useState(false);
  const [openPoPopoverVendorId, setOpenPoPopoverVendorId] = useState(null);
  const [poPopoverPosition, setPoPopoverPosition] = useState({
    top: 0,
    left: 0,
    placement: "bottom",
  });
  const [selectedVendorForPoAction, setSelectedVendorForPoAction] =
    useState(null);
  const [isSelectExistingPoModalOpen, setIsSelectExistingPoModalOpen] =
    useState(false);
  const [selectedExistingPoNumber, setSelectedExistingPoNumber] = useState("");
  const [isConfirmRemoveModalOpen, setIsConfirmRemoveModalOpen] =
    useState(false);
  const [vendorToRemove, setVendorToRemove] = useState(null);

  const [singleVendorForm, setSingleVendorForm] = useState({
    id: null,
    name: "",
    output: "",
    date: "",
    poNumber: "",
  });
  const [assignedOutputError, setAssignedOutputError] = useState("");

  const [createPoForm, setCreatePoForm] = useState({
    poDate: new Date().toISOString().split("T")[0],
    deliveryDate: "",
    currency: "IDR",
    unitPrice: "",
    tax: "",
    fees: "",
    notes: "",
    terms: "",
  });

  const [isViewReceiptHistoryModalOpen, setIsViewReceiptHistoryModalOpen] =
    useState(false);
  const [receiptHistoryVendor, setReceiptHistoryVendor] = useState(null);
  const [isViewAttachmentModalOpen, setIsViewAttachmentModalOpen] =
    useState(false);
  const [attachmentToView, setAttachmentToView] = useState(null);

  const [stageStart, setStageStart] = useState(0);
  const [stageProg, setStageProg] = useState(0);
  const [stageOriginalProg, setStageOriginalProg] = useState(0);
  const [stageComp, setStageComp] = useState(0);
  const [stageCompInput, setStageCompInput] = useState("0");
  const [stageProgError, setStageProgError] = useState("");
  const [stageCompError, setStageCompError] = useState("");
  const [stageOriginalComp, setStageOriginalComp] = useState(0);
  const [expectedDeliveryDate, setExpectedDeliveryDate] = useState(null);
  const [stageTotalPool, setStageTotalPool] = useState(0);
  const [stageMaxCompletable, setStageMaxCompletable] = useState(0);
  const [
    isManageStageVendorSectionExpanded,
    setIsManageStageVendorSectionExpanded,
  ] = useState(true);

  const [openVendorMenuId, setOpenVendorMenuId] = useState(null);
  const [vendorMenuPosition, setVendorMenuPosition] = useState({
    top: 0,
    right: 0,
    placement: "bottom",
  });

  const getVendorMenuPosition = (triggerRect, menuHeight = 176) => {
    const viewportHeight = window.innerHeight;
    const spaceBelow = viewportHeight - triggerRect.bottom;
    const spaceAbove = triggerRect.top;
    const shouldOpenAbove =
      spaceBelow < menuHeight + 12 && spaceAbove > spaceBelow;

    return {
      top: shouldOpenAbove ? triggerRect.top - 8 : triggerRect.bottom + 8,
      right: window.innerWidth - triggerRect.right,
      placement: shouldOpenAbove ? "top" : "bottom",
    };
  };

  const getPoPopoverPosition = (triggerRect, menuHeight = 96) => {
    const viewportHeight = window.innerHeight;
    const spaceBelow = viewportHeight - triggerRect.bottom;
    const spaceAbove = triggerRect.top;
    const shouldOpenAbove =
      spaceBelow < menuHeight + 12 && spaceAbove > spaceBelow;

    return {
      top: shouldOpenAbove ? triggerRect.top - 8 : triggerRect.bottom + 8,
      left: triggerRect.left,
      placement: shouldOpenAbove ? "top" : "bottom",
    };
  };

  const [isUploadProofModalOpen, setIsUploadProofModalOpen] = useState(false);
  const [selectedVendorForProof, setSelectedVendorForProof] = useState(null);
  const [proofDate, setProofDate] = useState("");
  const [proofDocuments, setProofDocuments] = useState([]);
  const [proofUploadError, setProofUploadError] = useState("");
  const [proofDescriptionErrors, setProofDescriptionErrors] = useState({});
  const [proofAmount, setProofAmount] = useState("");
  const [proofNote, setProofNote] = useState("");

  const [woStatus, setWoStatus] = useState(
    initialData?.statusKey || "not_started"
  );
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  const [readyStartDate, setReadyStartDate] = useState("");
  const [readyEndDate, setReadyEndDate] = useState("");

  useEffect(() => {
    if (showSuccessToast) {
      const timer = setTimeout(() => {
        setShowSuccessToast(false);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [showSuccessToast]);

  const [vendors, setVendors] = useState(() => {
    const initList = initialData?.vendors || [];
    return initList.map((v) => ({
      ...v,
      receivedOutput:
        v.status === "Completed" || v.status === "Received"
          ? parseInt(v.output, 10)
          : v.receivedOutput || 0,
      status: resolveVendorProgressStatus(v),
      receipts: (
        v.receipts ||
        (v.attachment
          ? [
            {
              amount: v.receivedOutput || parseInt(v.output, 10),
              date: v.receivedDate,
              attachment: v.attachment,
            },
          ]
          : [])
      ).map((receipt, index) => ({
        ...receipt,
        attachments: normalizeProofDocuments(
          receipt.attachments || receipt.proofDocuments,
          receipt.attachment
        ),
        attachment:
          receipt.attachment ||
          normalizeProofDocuments(
            receipt.attachments || receipt.proofDocuments,
            receipt.attachment
          )[0]?.name ||
          "",
        id: receipt.id || `vendor-receipt-${v.id}-${index}`,
      })),
    }));
  });

  const [routingStages, setRoutingStages] = useState(
    initialData?.routingStages || [
      {
        step: 1,
        route: "Production Stage Firstahnders...",
        op: "Cutting and Ever...",
        prog: 0,
        comp: 0,
      },
      { step: 2, route: "Production", op: "Assemble", prog: 0, comp: 0 },
      { step: 3, route: "Cat", op: "Paint", prog: 0, comp: 0 },
      { step: 4, route: "Cat", op: "Polish", prog: 0, comp: 0 },
      { step: 5, route: "Production", op: "Packing", prog: 0, comp: 0 },
    ]
  );

  useEffect(() => {
    const currentTotalVendorReceived = vendors
      .filter((v) => v.name !== "Internal")
      .reduce((acc, v) => acc + (parseInt(v.receivedOutput, 10) || 0), 0);

    const hasStages = routingStages.length > 0;
    const allStagesCompleted =
      hasStages &&
      routingStages.every((stage) => {
        const isHybridStage = outsourceSteps.includes(stage.step);
        const vendorCompleted = isHybridStage ? currentTotalVendorReceived : 0;
        return (stage.comp || 0) + vendorCompleted >= TOTAL_QTY;
      });

    if (allStagesCompleted && woStatus !== "completed") {
      setWoStatus("completed");
    }
  }, [routingStages, outsourceSteps, vendors, TOTAL_QTY, woStatus]);

  const internalVendor = vendors.find((v) => v.name === "Internal");
  const internalOut = parseInt(internalVendor?.output || 0, 10) || 0;

  const totalVendorOutput = vendors.reduce(
    (sum, v) => sum + (parseInt(v.output, 10) || 0),
    0
  );
  const externalOut = totalVendorOutput - internalOut;

  const isVendorsValid = vendors.every(
    (v) =>
      v.name &&
      v.name.trim() !== "" &&
      v.output !== "" &&
      v.date &&
      v.date.trim() !== ""
  );

  const totalVendorReceived = vendors
    .filter((v) => v.name !== "Internal")
    .reduce((acc, v) => acc + (parseInt(v.receivedOutput, 10) || 0), 0);

  const internalStatusInfo = (() => {
    if (internalOut === 0)
      return { text: "Not Started", variant: "grey-light" };
    const maxStep = outsourceSteps.length > 0 ? Math.max(...outsourceSteps) : 0;
    const lastStage = routingStages.find((r) => r.step === maxStep);
    const internalReceived =
      parseInt(internalVendor?.receivedOutput || 0, 10) || 0;

    if (internalReceived >= internalOut && internalOut > 0)
      return { text: "Completed", variant: "green-light" };

    const hasProgress = outsourceSteps.some((step) => {
      const r = routingStages.find((x) => x.step === step);
      return r && ((r.prog || 0) > 0 || (r.comp || 0) > 0);
    });

    if (hasProgress || internalReceived > 0)
      return { text: "In Progress", variant: "orange-light" };

    return { text: "Not Started", variant: "grey-light" };
  })();

  const externalVendors = vendors.filter((v) => v.name !== "Internal");
  const hasExternal = externalVendors.length > 0;
  const externalStatuses = externalVendors.map((vendor) =>
    resolveVendorProgressStatus(vendor)
  );
  const allCompleted =
    hasExternal && externalStatuses.every((status) => status === "Completed");
  const someReceived =
    hasExternal &&
    externalStatuses.some(
      (status) => status === "Partially Received" || status === "Completed"
    );
  const someInProgress =
    hasExternal && externalStatuses.some((status) => status === "In Progress");
  const vendorStatusVariant = allCompleted
    ? "green-light"
    : someReceived
      ? "blue-light"
      : someInProgress
        ? "orange-light"
        : "yellow-light";
  const vendorStatusText = allCompleted
    ? "Completed"
    : someReceived
      ? "Partially Received"
      : someInProgress
        ? "In Progress"
        : "Waiting";

  const stagesWithTotals = routingStages.map((row) => {
    const isHybrid = outsourceSteps.includes(row.step);
    const vendorComp = isHybrid ? totalVendorReceived : 0;
    return {
      ...row,
      vendorComp,
      totalComp: (row.comp || 0) + vendorComp,
    };
  });

  let firstOutsourceStart = 0;
  let isFirstOutsourceCompleted = false;
  if (outsourceSteps.length > 0) {
    const minStep = Math.min(...outsourceSteps);
    const rowIndex = stagesWithTotals.findIndex((r) => r.step === minStep);
    if (rowIndex !== -1) {
      const row = stagesWithTotals[rowIndex];
      const stepTotalPool =
        row.step === 1
          ? TOTAL_QTY
          : stagesWithTotals[rowIndex - 1]?.totalComp || 0;
      firstOutsourceStart = Math.max(
        0,
        stepTotalPool - (row.prog || 0) - (row.totalComp || 0)
      );

      if ((row.totalComp || 0) >= TOTAL_QTY) {
        isFirstOutsourceCompleted = true;
      }
    }
  }

  const handleOutsourceToggle = (step) => {
    if (outsourceSteps.includes(step)) {
      setOutsourceSteps(outsourceSteps.filter((s) => s !== step));
    } else {
      setOutsourceSteps([...outsourceSteps, step]);
    }
  };

  const handleOpenAddVendor = () => {
    setSingleVendorForm({
      id: null,
      name: "",
      output: "",
      date: "",
      poNumber: "",
    });
    setAssignedOutputError("");
    setIsSingleVendorModalOpen(true);
  };

  const handleEditVendor = (vendor) => {
    setSingleVendorForm({
      ...vendor,
      poNumber: vendor.poNumber || "",
      lockedVendorName: true,
    });
    setAssignedOutputError("");
    setIsSingleVendorModalOpen(true);
  };

  const promptRemoveVendor = (vendor) => {
    setVendorToRemove(vendor);
    setIsConfirmRemoveModalOpen(true);
  };

  const executeRemoveVendor = () => {
    if (vendorToRemove) {
      setVendors(vendors.filter((v) => v.id !== vendorToRemove.id));
      setToastMessage("Vendor successfully removed");
      setShowSuccessToast(true);
    }
    setIsConfirmRemoveModalOpen(false);
    setVendorToRemove(null);
  };

  const handleSaveSingleVendor = () => {
    setAssignedOutputError("");
    if (editingInternalVendor) {
      const proposedOutput = parseInt(singleVendorForm.output, 10) || 0;
      if (proposedOutput < editingInternalMinimumOutput) {
        setAssignedOutputError(internalAssignedOutputErrorMessage);
        return;
      }
    }

    const fallbackVendorDate =
      singleVendorForm.date || expectedDeliveryDate || WORK_ORDER_END_DATE;
    const normalizedForm = { ...singleVendorForm, date: fallbackVendorDate };

    let finalVendors;
    if (normalizedForm.id) {
      finalVendors = vendors.map((v) =>
        v.id === normalizedForm.id
          ? {
            ...v,
            ...normalizedForm,
            status: resolveVendorProgressStatus({ ...v, ...normalizedForm }),
          }
          : v
      );
    } else {
      finalVendors = [
        ...vendors,
        {
          ...normalizedForm,
          id: Date.now() + Math.random(),
          status:
            normalizedForm.name === "Internal" ? "Not Started" : "Waiting",
          receivedOutput: 0,
          isPoApproved: false,
          receipts: [],
        },
      ].map((vendor) =>
        vendor.name === "Internal"
          ? vendor
          : { ...vendor, status: resolveVendorProgressStatus(vendor) }
      );
    }

    setVendors(finalVendors);
    setIsSingleVendorModalOpen(false);
    setToastMessage("Vendor assignment successfully saved");
    setShowSuccessToast(true);
  };

  const handleOpenPoAction = (vendor) => {
    setSelectedVendorForPoAction(vendor);
    setSelectedExistingPoNumber("");
    setOpenVendorMenuId(null);
    setOpenPoPopoverVendorId(
      openPoPopoverVendorId === vendor.id ? null : vendor.id
    );
  };

  const buildOutsourceStageDescription = (steps = []) => {
    const normalizedSteps = Array.from(
      new Set(
        (steps || [])
          .map((step) => Number(step))
          .filter((step) => Number.isFinite(step))
      )
    ).sort((a, b) => a - b);

    if (normalizedSteps.length === 0) return "";
    const stageLabels = normalizedSteps.map((step) => {
      const matchedStage = routingStages.find(
        (stage) => Number(stage.step) === step
      );
      const operationName = matchedStage?.op || matchedStage?.operation;
      return operationName ? `[${operationName}]` : `[routing step ${step}]`;
    });
    return ` including ${stageLabels.join(", ")}`;
  };

  const buildDummyPoDetailData = (poNumber, vendor) => {
    const basePo = MOCK_PO_TABLE_DATA.find(
      (po) => po.poNumber === poNumber
    ) || {
      poNumber,
      vendorName: vendor?.name || "Vendor",
      amount: formatCurrency((parseInt(vendor?.output || 0, 10) || 0) * 250000),
      createdDate: "2026-03-31",
      status: "Draft",
      statusKey: "draft",
      sBadge: "grey-light",
    };

    const vendorDetails = MOCK_VENDORS.find(
      (v) => v.name === (vendor?.name || basePo.vendorName)
    );
    const vendorOutput = parseInt(vendor?.output || 0, 10) || 0;
    const vendorReceivedOutput = Math.min(
      parseInt(vendor?.receivedOutput || 0, 10) || 0,
      vendorOutput || Number.MAX_SAFE_INTEGER
    );
    const isVendorReceiptCompleted =
      vendorOutput > 0 && vendorReceivedOutput >= vendorOutput;
    const resolvedStatus =
      vendor?.poStatus ||
      (isVendorReceiptCompleted
        ? "Completed"
        : vendor?.isPoApproved
          ? "Issued"
          : basePo.status);
    const resolvedBadge =
      vendor?.poBadge ||
      (isVendorReceiptCompleted
        ? "green"
        : vendor?.isPoApproved
          ? "blue"
          : basePo.sBadge);
    const resolvedStatusKey =
      vendor?.poStatusKey ||
      (isVendorReceiptCompleted
        ? "completed"
        : vendor?.isPoApproved
          ? "issued"
          : basePo.statusKey);
    const lineDescription = `Generated from ${initialData?.wo || "work order"
      }${buildOutsourceStageDescription(outsourceSteps)}`;
    const receiptLogs = (vendor?.receipts || []).map((receipt, index) => ({
      id: `receipt-log-${poNumber}-${index}`,
      receiptNumber:
        receipt.receiptNumber || `RCPT-${String(index + 1).padStart(4, "0")}`,
      date: receipt.date || "-",
      time: receipt.time || "10:24",
      receivedBy: receipt.receivedBy || "Natasha Smith",
      proofDocuments: normalizeProofDocuments(
        receipt.attachments || receipt.proofDocuments,
        receipt.attachment
      ),
      notes: receipt.note || "-",
      items: [
        {
          id: `line-${poNumber}`,
          item: initialData?.product || "Cabinet Premium",
          code: initialData?.sku || "CAB-PR-9921",
          receivedNow: Number(receipt.amount) || 0,
        },
      ],
    }));

    return {
      ...basePo,
      status: resolvedStatus,
      sBadge: resolvedBadge,
      statusKey: resolvedStatusKey,
      formData: {
        vendorName: vendor?.name || basePo.vendorName,
        vendorDetails: {
          phone: vendorDetails?.phone || "08123456789",
          email: vendorDetails?.email || "vendor@email.com",
          address: vendorDetails?.address || "Vendor address",
        },
        poDate: basePo.createdDate || "2026-03-31",
        deliveryDate: vendor?.date || "2026-04-10",
        currency: "IDR",
        lines: [
          {
            id: `line-${poNumber}`,
            type: "wo",
            item: initialData?.product || "Cabinet Premium",
            code: initialData?.sku || "CAB-PR-9921",
            desc: lineDescription,
            woRef: initialData?.wo || "-",
            qty: vendorOutput || 1,
            receivedQty: vendorReceivedOutput,
            price: 250000,
            sourceWorkOrderLineId: `generated-work-order-line-${poNumber}`,
          },
        ],
        receiptLogs,
        tax: 11,
        feeLines: [{ id: "fee-1", name: "Delivery Fee", amount: 150000 }],
        notes: "Dummy PO detail generated from outsource detail table click.",
        terms: "Payment within 30 days from invoice date.",
        shipTo: {
          name: MOCK_COMPANY.name,
          phone: MOCK_COMPANY.phone,
          email: MOCK_COMPANY.email,
          address: MOCK_COMPANY.address,
        },
      },
    };
  };

  const handleCreatePoFromVendor = () => {
    if (!selectedVendorForPoAction) return;

    const workOrderReturnData = {
      ...initialData,
      vendors,
      routingStages,
      outsourceSteps,
      statusKey: woStatus,
      status:
        woStatus === "not_started"
          ? "Not Started"
          : woStatus === "ready_to_process"
            ? "Ready to Process"
            : woStatus === "in_progress"
              ? "In Progress"
              : woStatus === "completed"
                ? "Completed"
                : initialData?.status,
      sBadge:
        woStatus === "not_started"
          ? "grey"
          : woStatus === "ready_to_process"
            ? "blue"
            : woStatus === "in_progress"
              ? "yellow"
              : woStatus === "completed"
                ? "green"
                : initialData?.sBadge,
      start: displayStartDate,
      end: displayEndDate,
    };

    setOpenPoPopoverVendorId(null);
    setOpenVendorMenuId(null);
    scrollToTop();
    onNavigate("create", {
      source: "work_order_vendor_assignment",
      vendorData: selectedVendorForPoAction,
      assignedOutput: selectedVendorForPoAction.output,
      workOrder: {
        wo: initialData?.wo,
        product: initialData?.product,
        sku: initialData?.sku,
        image: initialData?.image || "",
      },
      poNumber: selectedVendorForPoAction.poNumber || "",
      returnTo: {
        view: "detail",
        data: workOrderReturnData,
      },
    });
  };

  const handleOpenSelectExistingPo = () => {
    setOpenPoPopoverVendorId(null);
    setSelectedExistingPoNumber("");
    setIsSelectExistingPoModalOpen(true);
  };

  const handleAttachExistingPo = () => {
    if (!selectedVendorForPoAction || !selectedExistingPoNumber) return;
    setVendors((prev) =>
      prev.map((v) => {
        if (v.id !== selectedVendorForPoAction.id) return v;
        const selectedPo = MOCK_PO_TABLE_DATA.find(
          (po) => po.poNumber === selectedExistingPoNumber
        );
        const nextVendor = {
          ...v,
          poNumber: selectedExistingPoNumber,
          isPoApproved:
            selectedPo?.statusKey === "issued" ||
            selectedPo?.statusKey === "completed",
        };
        return {
          ...nextVendor,
          status: resolveVendorProgressStatus(nextVendor),
        };
      })
    );
    setIsSelectExistingPoModalOpen(false);
    setSelectedVendorForPoAction(null);
    setSelectedExistingPoNumber("");
    setToastMessage("Purchase order successfully assigned");
    setShowSuccessToast(true);
  };

  const handleSaveNewPo = () => {
    const generatedPo = `PO-202603-${Math.floor(1000 + Math.random() * 9000)}`;

    const newVendorAssignment = {
      ...singleVendorForm,
      id: Date.now() + Math.random(),
      poNumber: generatedPo,
      status: "Waiting",
      receivedOutput: 0,
      isPoApproved: false,
      receipts: [],
    };

    let updatedVendors = vendors.filter((v) => v.id !== singleVendorForm.id);
    updatedVendors.push(newVendorAssignment);

    const newInternal = updatedVendors.find((v) => v.name === "Internal");
    const newInternalOut = parseInt(newInternal?.output || 0, 10) || 0;
    const maxStep = outsourceSteps.length > 0 ? Math.max(...outsourceSteps) : 0;
    const lastStage = routingStages.find((r) => r.step === maxStep);

    setVendors(
      updatedVendors.map((v) => {
        if (v.name === "Internal") {
          if (
            newInternalOut > 0 &&
            lastStage &&
            (lastStage.comp || 0) >= newInternalOut
          ) {
            return {
              ...v,
              receivedDate:
                v.receivedDate || new Date().toISOString().split("T")[0],
            };
          } else {
            return { ...v, receivedDate: "" };
          }
        }
        return v;
      })
    );

    setIsCreatePoModalOpen(false);
    setToastMessage(
      `Purchase Order ${generatedPo} created and vendor assigned`
    );
    setShowSuccessToast(true);
  };

  const handleVendorProofFilesSelected = (files) => {
    const incomingFiles = Array.from(files || []);
    if (incomingFiles.length === 0) return;

    let nextError = "";
    setProofDocuments((prev) => {
      const nextDocuments = [...prev];
      incomingFiles.forEach((file) => {
        if (nextDocuments.length >= MAX_PROOF_UPLOAD_FILES) {
          nextError = "Max 3 files, 25MB each";
          return;
        }
        const validationMessage = validateUploadFile(file);
        if (validationMessage) {
          nextError = validationMessage;
          return;
        }
        nextDocuments.push(
          createUploadDocumentRecord(file, { description: "" })
        );
      });
      return nextDocuments;
    });
    setProofDescriptionErrors({});
    setProofUploadError(nextError);
  };

  const updateVendorProofDescription = (docId, value) => {
    setProofDocuments((prev) =>
      prev.map((doc) =>
        doc.id === docId ? { ...doc, description: value } : doc
      )
    );
    setProofUploadError("");
    setProofDescriptionErrors((prev) => ({ ...prev, [docId]: "" }));
  };

  const removeVendorProofDocument = (docId) => {
    setProofDocuments((prev) => prev.filter((doc) => doc.id !== docId));
    setProofDescriptionErrors((prev) => {
      const next = { ...prev };
      delete next[docId];
      return next;
    });
    setProofUploadError("");
  };

  const handleReceiveVendor = () => {
    const normalizedProofDocuments = proofDocuments.map((doc) => ({
      ...doc,
      description: (doc.description || "").trim(),
    }));
    const nextDescriptionErrors = {};

    if (!isInternalProof) {
      if (normalizedProofDocuments.length === 0) {
        setProofUploadError("Upload at least one proof document");
        return;
      }

      normalizedProofDocuments.forEach((doc) => {
        if (!doc.description)
          nextDescriptionErrors[doc.id] = "Description is required";
      });

      if (Object.keys(nextDescriptionErrors).length > 0) {
        setProofDescriptionErrors(nextDescriptionErrors);
        setProofUploadError("Add description for each proof document");
        return;
      }
    }

    setVendors(
      vendors.map((v) => {
        if (v.id === selectedVendorForProof) {
          const addedAmount = parseInt(proofAmount, 10) || 0;
          const newReceipt = {
            amount: addedAmount,
            date: proofDate,
            attachment:
              normalizedProofDocuments[0]?.name || "No Document Provided",
            attachments: normalizedProofDocuments,
            note: proofNote || "-",
          };
          const updatedReceipts = [...(v.receipts || []), newReceipt];
          const newTotalReceived = updatedReceipts.reduce(
            (sum, r) => sum + r.amount,
            0
          );
          const targetOutput = parseInt(v.output, 10) || 0;
          const isFullyReceived =
            newTotalReceived >= targetOutput && targetOutput > 0;
          const newStatus = isFullyReceived
            ? "Completed"
            : "Partially Received";

          return {
            ...v,
            receivedOutput: newTotalReceived,
            status: newStatus,
            receipts: updatedReceipts,
            receivedDate: isFullyReceived ? proofDate : "",
          };
        }
        return v;
      })
    );
    setIsUploadProofModalOpen(false);
    setProofDocuments([]);
    setProofUploadError("");
    setProofDescriptionErrors({});
    setProofAmount("");
    setProofDate("");
    setProofNote("");
    setToastMessage("Vendor output successfully received");
    setShowSuccessToast(true);
  };

  useEffect(() => {
    const internal = vendors.find((v) => v.name === "Internal");
    if (!internal || internalOut === 0 || outsourceSteps.length === 0) return;

    const maxStep = Math.max(...outsourceSteps);
    const lastStage = routingStages.find((r) => r.step === maxStep);
    const completedAtLastStage = parseInt(lastStage?.comp || 0, 10) || 0;
    const targetReceived = Math.min(internalOut, completedAtLastStage);
    const currentReceived = parseInt(internal.receivedOutput || 0, 10) || 0;

    if (targetReceived <= currentReceived) return;

    const delta = targetReceived - currentReceived;
    const today = new Date().toISOString().split("T")[0];

    setVendors((prev) =>
      prev.map((v) => {
        if (v.name !== "Internal") return v;
        const assignedOutput = parseInt(v.output, 10) || 0;
        const isFullyReceived =
          targetReceived >= assignedOutput && assignedOutput > 0;
        return {
          ...v,
          receivedOutput: targetReceived,
          receivedDate: isFullyReceived ? today : "",
          status: isFullyReceived ? "Completed" : "Partially Received",
          receipts: [
            ...(v.receipts || []),
            {
              amount: delta,
              date: today,
              attachment: "Internal routing completion",
              note: "Work Order-recorded from internal routing completion.",
            },
          ],
        };
      })
    );
  }, [routingStages, outsourceSteps, internalOut]);

  const renderAllocationBar = (currentTotalOutput, variant = "full") => {
    const percentage = Math.min((currentTotalOutput / TOTAL_QTY) * 100, 100);
    const isExceeded = currentTotalOutput > TOTAL_QTY;
    const isFull = currentTotalOutput === TOTAL_QTY;
    const color = isExceeded
      ? "var(--status-red-primary)"
      : isFull
        ? "var(--status-green-primary)"
        : "var(--feature-brand-primary)";

    if (variant === "mini") {
      return (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "6px",
            width: "260px",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              fontSize: "var(--text-body)",
            }}
          >
            <span
              style={{
                color: isExceeded
                  ? "var(--status-red-primary)"
                  : "var(--neutral-on-surface-secondary)",
              }}
            >
              {isExceeded ? "Exceeds req. qty" : "Total Assigned Output"}
            </span>
            <span
              style={{
                fontWeight: "var(--font-weight-bold)",
                color: isExceeded
                  ? "var(--status-red-primary)"
                  : "var(--neutral-on-surface-primary)",
              }}
            >
              {currentTotalOutput} / {TOTAL_QTY} pcs
            </span>
          </div>
          <div
            style={{
              height: "6px",
              background: "var(--neutral-line-separator-2)",
              borderRadius: "3px",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                height: "100%",
                width: `${percentage}%`,
                background: color,
                transition: "all 0.3s ease",
              }}
            />
          </div>
        </div>
      );
    }
    return null;
  };

  const selectedVendorObj = vendors.find(
    (v) => v.id === selectedVendorForProof
  );
  const isInternalProof = selectedVendorObj?.name === "Internal";
  const selectedVendorDetails =
    MOCK_VENDORS.find((v) => v.name === singleVendorForm.name) || {};
  const editingInternalVendor =
    !!singleVendorForm.id && singleVendorForm.name === "Internal";
  const editingInternalReceivedOutput = editingInternalVendor
    ? vendors.find((v) => v.id === singleVendorForm.id)?.receivedOutput || 0
    : 0;
  const editingInternalProcessedOutput = editingInternalVendor
    ? outsourceSteps.reduce((maxProcessed, step) => {
      const matchedStage = routingStages.find(
        (stage) => Number(stage.step) === Number(step)
      );
      const processedCount =
        (parseInt(matchedStage?.prog || 0, 10) || 0) +
        (parseInt(matchedStage?.comp || 0, 10) || 0);
      return Math.max(maxProcessed, processedCount);
    }, 0)
    : 0;
  const editingInternalMinimumOutput = Math.max(
    editingInternalReceivedOutput,
    editingInternalProcessedOutput
  );
  const internalAssignedOutputErrorMessage = `Assigned output cannot be lower than ${editingInternalMinimumOutput} pcs because internal progress already exists.`;
  const isSelectedStageOutsourced =
    !!selectedStage && outsourceSteps.includes(selectedStage.step);

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "calc(100vh - 64px)",
        position: "relative",
      }}
    >
      {showSuccessToast ? (
        <div
          style={{
            position: "absolute",
            top: "24px",
            right: "24px",
            background: "var(--status-green-primary)",
            color: "var(--status-green-on-primary)",
            padding: "12px 16px",
            borderRadius: "var(--radius-small)",
            display: "flex",
            alignItems: "center",
            gap: "12px",
            boxShadow: "var(--elevation-sm)",
            zIndex: 1000,
            minWidth: "350px",
            justifyContent: "space-between",
          }}
        >
          <span style={{ fontSize: "var(--text-title-3)" }}>
            {toastMessage}
          </span>
          <span
            style={{
              fontWeight: "var(--font-weight-bold)",
              cursor: "pointer",
              fontSize: "var(--text-title-3)",
            }}
            onClick={() => setShowSuccessToast(false)}
          >
            Okay
          </span>
        </div>
      ) : null}

      <div
        style={{
          padding: "24px",
          display: "flex",
          flexDirection: "column",
          gap: "16px",
          paddingBottom: woStatus === "not_started" ? "100px" : "24px",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            marginBottom: "8px",
          }}
        >
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                cursor: "pointer",
                marginLeft: "-4px",
              }}
              onClick={() => onNavigate("list")}
            >
              <ChevronLeftIcon
                size={28}
                color="var(--neutral-on-surface-primary)"
              />
              <h1
                style={{
                  margin: 0,
                  fontSize: "var(--text-large-title)",
                  fontWeight: "var(--font-weight-bold)",
                }}
              >
                Work Order Detail
              </h1>
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                fontSize: "var(--text-title-3)",
              }}
            >
              <span
                style={{
                  color: "var(--neutral-on-surface-secondary)",
                  cursor: "pointer",
                }}
                onClick={() => onNavigate("list")}
              >
                Work Order
              </span>
              <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>
                /
              </span>
              <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>
                Work Order Detail
              </span>
            </div>
          </div>
          <Button variant="outlined">Edit Work Order</Button>
        </div>

        <Card>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span
              style={{
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              {initialData?.wo || "WO-2294824-20251109-00001"}
            </span>
            {woStatus === "not_started" ? (
              <StatusBadge variant="grey">Not Started</StatusBadge>
            ) : null}
            {woStatus === "ready_to_process" ? (
              <StatusBadge variant="blue">Ready to Process</StatusBadge>
            ) : null}
            {woStatus === "in_progress" ? (
              <StatusBadge variant="orange">In Progress</StatusBadge>
            ) : null}
            {woStatus === "completed" ? (
              <StatusBadge variant="green">Completed</StatusBadge>
            ) : null}
          </div>
          <div
            style={{ borderTop: "1px solid var(--neutral-line-separator-1)" }}
          />
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, 1fr)",
              gap: "24px",
            }}
          >
            <LabelValue
              label="Order Number"
              value={initialData?.ord || "ORD-248824-20251109-00001"}
            />
            <LabelValue
              label="Planned Start - End Date"
              value={
                displayStartDate && displayEndDate
                  ? `${displayStartDate} - ${displayEndDate}`
                  : "Not Set"
              }
            />
            <LabelValue
              label="Actual Start - End Date"
              value={
                woStatus === "not_started"
                  ? "-"
                  : `${displayStartDate || "-"} - Not Defined`
              }
            />
            <LabelValue
              label="Priority"
              value={initialData?.priority || "Medium"}
              badge={{
                variant: initialData?.pBadge || "yellow-light",
                text: initialData?.priority || "Medium",
              }}
            />

            <LabelValue label="Created On" value={`2025-12-08; 15:00`} />
            <LabelValue label="Notes" value="-" />
          </div>
        </Card>

        <Card>
          <span
            style={{
              fontSize: "var(--text-title-2)",
              fontWeight: "var(--font-weight-bold)",
            }}
          >
            Target Product
          </span>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
              <div
                style={{
                  width: "48px",
                  height: "48px",
                  borderRadius: "var(--radius-small)",
                  border: "1px solid var(--neutral-line-separator-1)",
                  background: "var(--neutral-surface-grey-lighter)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Box size={24} color="var(--neutral-on-surface-tertiary)" />
              </div>
              <div
                style={{ display: "flex", flexDirection: "column", gap: "4px" }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  {initialData?.product || "Wooden Chair"}
                </span>
                <span
                  style={{
                    fontSize: "var(--text-body)",
                    color: "var(--neutral-on-surface-secondary)",
                  }}
                >
                  SKU: {initialData?.sku || "CH-WD-23948"}
                </span>
              </div>
            </div>
            <span
              style={{
                fontSize: "var(--text-title-1)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              {TOTAL_QTY} pcs
            </span>
          </div>
        </Card>

        <Card>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
            }}
          >
            <div
              style={{ display: "flex", flexDirection: "column", gap: "8px" }}
            >
              <div
                style={{ display: "flex", alignItems: "center", gap: "12px" }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  Bill of Material
                </span>
                <StatusBadge variant="blue-light">Material Request</StatusBadge>
              </div>
              <span
                style={{
                  fontSize: "var(--text-title-3)",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                {initialData?.product || "Wooden Chair"} Classic Model BOM
              </span>
            </div>
            {woStatus !== "not_started" ? (
              <Button variant="outlined" leftIcon={AddIcon}>
                Request Material
              </Button>
            ) : null}
          </div>

          <div style={{ display: "flex", flexDirection: "column" }}>
            <div
              style={{
                display: "flex",
                paddingBottom: "12px",
                borderBottom: "1px solid var(--neutral-line-separator-1)",
                fontWeight: "var(--font-weight-bold)",
                fontSize: "var(--text-title-3)",
              }}
            >
              <div style={{ width: "40px" }}>No</div>
              <div style={{ flex: "1.5" }}>Material</div>
              <div style={{ flex: "1" }}>Required Qty</div>
              <div style={{ flex: "1" }}>Requested Qty</div>
              <div style={{ flex: "1" }}>Received Qty</div>
            </div>
            {[
              {
                id: 1,
                name: "Wooden Plank",
                sku: "WOD-023UDISJJDS",
                req: "50 pcs",
                reqst: "0 pcs",
                rec: "0 pcs",
              },
              {
                id: 2,
                name: "Paint",
                sku: "PAI-WIQIFQJFJSA",
                req: "5 liter",
                reqst: "0 liter",
                rec: "0 liter",
              },
              {
                id: 3,
                name: "Nail",
                sku: "NAI-9AIF0U092F",
                req: "10 box",
                reqst: "0 box",
                rec: "0 box",
              },
            ].map((row, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  alignItems: "center",
                  padding: "16px 0",
                  borderBottom: "1px solid var(--neutral-line-separator-1)",
                  fontSize: "var(--text-title-3)",
                }}
              >
                <div style={{ width: "40px" }}>{row.id}</div>
                <div
                  style={{
                    flex: "1.5",
                    display: "flex",
                    flexDirection: "column",
                    gap: "4px",
                  }}
                >
                  <span>{row.name}</span>
                  <span
                    style={{
                      fontSize: "var(--text-desc)",
                      color: "var(--neutral-on-surface-tertiary)",
                    }}
                  >
                    {row.sku}
                  </span>
                </div>
                <div style={{ flex: "1" }}>{row.req}</div>
                <div style={{ flex: "1" }}>{row.reqst}</div>
                <div style={{ flex: "1" }}>{row.rec}</div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            <span
              style={{
                fontSize: "var(--text-title-2)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Routing Stages
            </span>
            {woStatus === "not_started" ? (
              <div
                style={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "12px",
                  padding: "12px 16px",
                  borderRadius: "var(--radius-small)",
                  background: "var(--feature-brand-container-darker)",
                  border: "1px solid var(--feature-brand-container-darker)",
                }}
              >
                <Info
                  size={16}
                  strokeWidth={2.1}
                  color="var(--feature-brand-primary)"
                  style={{ flexShrink: 0, marginTop: "2px" }}
                />
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "2px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "var(--text-title-3)",
                      fontWeight: "var(--font-weight-bold)",
                      color: "var(--neutral-on-surface-primary)",
                      lineHeight: "20px",
                      letterSpacing: "0.0962px",
                    }}
                  >
                    You can now allow outsourcing for selected stages.
                  </span>
                  <span
                    style={{
                      fontSize: "var(--text-title-3)",
                      fontWeight: "var(--font-weight-regular)",
                      color: "var(--neutral-on-surface-primary)",
                      lineHeight: "20px",
                      letterSpacing: "0.0962px",
                    }}
                  >
                    Each selected stage can be handled by external vendors or
                    together with your internal team.
                  </span>
                </div>
              </div>
            ) : null}
          </div>

          <div
            key={`routing-table-${woStatus}`}
            style={{ display: "flex", flexDirection: "column" }}
          >
            {woStatus === "not_started" ? (
              <div style={{ display: "flex", flexDirection: "column" }}>
                <div
                  style={{
                    display: "flex",
                    paddingBottom: "12px",
                    borderBottom: "1px solid var(--neutral-line-separator-1)",
                    fontWeight: "var(--font-weight-bold)",
                    fontSize: "var(--text-title-3)",
                  }}
                >
                  <div
                    style={{
                      width: "140px",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    Allow Outsourcing
                  </div>
                  <div style={{ width: "60px", paddingLeft: "8px" }}>Step</div>
                  <div style={{ flex: "1.5" }}>Routing</div>
                  <div style={{ flex: "1.5" }}>Operation</div>
                  <div style={{ flex: "1" }}>Yet to Start</div>
                  <div style={{ flex: "1" }}>In Progress</div>
                  <div style={{ flex: "1" }}>Completed</div>
                </div>
                {stagesWithTotals.map((row, i) => {
                  const stepTotalPool = row.step === 1 ? TOTAL_QTY : 0;
                  const start = Math.max(
                    0,
                    stepTotalPool - (row.prog || 0) - (row.totalComp || 0)
                  );
                  const isChecked = outsourceSteps.includes(row.step);
                  let isDisabled = false;

                  if (outsourceSteps.length > 0) {
                    const min = Math.min(...outsourceSteps);
                    const max = Math.max(...outsourceSteps);

                    if (isChecked) {
                      if (row.step !== min && row.step !== max)
                        isDisabled = true;
                    } else {
                      if (row.step !== min - 1 && row.step !== max + 1)
                        isDisabled = true;
                    }
                  }

                  return (
                    <div
                      key={i}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        padding: "16px 0",
                        borderBottom:
                          "1px solid var(--neutral-line-separator-1)",
                        fontSize: "var(--text-title-3)",
                      }}
                    >
                      <div
                        style={{
                          width: "140px",
                          display: "flex",
                          justifyContent: "center",
                        }}
                      >
                        <Checkbox
                          checked={isChecked}
                          disabled={isDisabled}
                          onChange={() => handleOutsourceToggle(row.step)}
                        />
                      </div>
                      <div style={{ width: "60px", paddingLeft: "8px" }}>
                        {row.step}
                      </div>
                      <div style={{ flex: "1.5" }}>{row.route}</div>
                      <div style={{ flex: "1.5" }}>{row.op}</div>
                      <div style={{ flex: "1" }}>{start}</div>
                      <div style={{ flex: "1" }}>{row.prog || 0}</div>
                      <div style={{ flex: "1" }}>{row.totalComp || 0}</div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column" }}>
                <div
                  style={{
                    display: "flex",
                    paddingBottom: "12px",
                    borderBottom: "1px solid var(--neutral-line-separator-1)",
                    fontWeight: "var(--font-weight-bold)",
                    fontSize: "var(--text-title-3)",
                  }}
                >
                  <div style={{ width: "60px" }}>Step</div>
                  <div style={{ flex: "1.5" }}>Routing</div>
                  <div style={{ flex: "1.5" }}>Operation</div>
                  <div style={{ flex: "1" }}>Yet to Start</div>
                  <div style={{ flex: "1" }}>In Progress</div>
                  <div style={{ flex: "1" }}>Completed</div>
                  <div style={{ flex: "2" }}>Progress</div>
                </div>
                {stagesWithTotals.map((row, i) => {
                  const stepTotalPool =
                    row.step === 1
                      ? TOTAL_QTY
                      : stagesWithTotals[i - 1].totalComp;
                  const start = Math.max(
                    0,
                    stepTotalPool - (row.prog || 0) - (row.totalComp || 0)
                  );

                  const isHybrid = outsourceSteps.includes(row.step);
                  const progressTarget = isHybrid ? internalOut : TOTAL_QTY;

                  const internalRemaining = Math.max(
                    0,
                    progressTarget - (row.comp || 0) - (row.prog || 0)
                  );
                  const internalStart = Math.min(internalRemaining, start);

                  const progress =
                    Math.min(
                      100,
                      Math.round(((row.totalComp || 0) / TOTAL_QTY) * 100)
                    ) || 0;

                  const isUnlocked =
                    row.step === 1 ||
                    (i > 0 && (stagesWithTotals[i - 1]?.totalComp || 0) > 0);

                  const canManage = internalStart > 0 || (row.prog || 0) > 0;

                  return (
                    <div
                      key={i}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        padding: "16px 0",
                        borderBottom:
                          "1px solid var(--neutral-line-separator-1)",
                        fontSize: "var(--text-title-3)",
                        color: !isUnlocked
                          ? "var(--neutral-on-surface-tertiary)"
                          : "var(--neutral-on-surface-primary)",
                      }}
                    >
                      <div style={{ width: "60px" }}>{row.step}</div>
                      <div
                        style={{
                          flex: "1.5",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "flex-start",
                          gap: "4px",
                        }}
                      >
                        <span style={{ lineHeight: "1.2" }}>{row.route}</span>
                        {isHybrid && externalOut > 0 ? (
                          <StatusBadge
                            variant={
                              internalOut === 0 ? "orange-light" : "blue-light"
                            }
                          >
                            {internalOut === 0 ? "Outsourced" : "Hybrid"}
                          </StatusBadge>
                        ) : null}
                      </div>
                      <div style={{ flex: "1.5" }}>{row.op}</div>
                      <div style={{ flex: "1" }}>{start}</div>
                      <div style={{ flex: "1" }}>{row.prog || 0}</div>
                      <div style={{ flex: "1" }}>{row.totalComp || 0}</div>
                      <div
                        style={{
                          flex: "2",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          gap: "8px",
                        }}
                      >
                        <ProgressRing
                          percentage={progress}
                          color={
                            !isUnlocked
                              ? "var(--neutral-on-surface-tertiary)"
                              : "inherit"
                          }
                        />
                        {!isUnlocked ? (
                          <span
                            style={{
                              color: "var(--neutral-on-surface-tertiary)",
                              fontSize: "var(--text-body)",
                              textAlign: "right",
                              lineHeight: "1.2",
                            }}
                          >
                            Waiting for items
                          </span>
                        ) : canManage ? (
                          <Button
                            variant="outlined"
                            size="small"
                            leftIcon={EditIcon}
                            style={{ width: "100px", flexShrink: 0 }}
                            onClick={() => {
                              setSelectedStage(row);
                              setStageStart(internalStart);
                              setStageProg(row.prog || 0);
                              setStageOriginalProg(row.prog || 0);
                              setStageComp(row.comp || 0);
                              setStageOriginalComp(row.comp || 0);
                              setExpectedDeliveryDate(
                                row.expectedDeliveryDate || row.date || null
                              );
                              setStageTotalPool(
                                (row.comp || 0) +
                                (row.prog || 0) +
                                internalStart
                              );
                              setStageMaxCompletable(
                                (row.comp || 0) +
                                (row.prog || 0) +
                                internalStart
                              );
                              setStageCompInput(String(row.comp || 0));
                              setStageProgError("");
                              setStageCompError("");
                              setIsManageStageVendorSectionExpanded(true);
                              setIsManageStageModalOpen(true);
                            }}
                          >
                            Manage
                          </Button>
                        ) : (
                          <span
                            style={{
                              color: "var(--neutral-on-surface-tertiary)",
                              fontSize: "var(--text-body)",
                              textAlign: "right",
                              lineHeight: "1.2",
                            }}
                          >
                            {(row.totalComp || 0) >= TOTAL_QTY
                              ? "Completed"
                              : "Waiting for items"}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </Card>

        {outsourceSteps.length > 0 && woStatus !== "not_started" ? (
          <Card>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div
                style={{ display: "flex", alignItems: "center", gap: "12px" }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  Outsource Detail
                </span>
                <StatusBadge
                  variant={
                    woStatus === "not_started"
                      ? "blue-light"
                      : vendors.length === 0
                        ? "grey-light"
                        : !hasExternal
                          ? "grey-light"
                          : vendorStatusVariant
                  }
                >
                  {woStatus === "not_started"
                    ? "Needs Assignment"
                    : vendors.length === 0
                      ? "Needs Assignment"
                      : !hasExternal
                        ? "Assigned"
                        : vendorStatusText}
                </StatusBadge>
              </div>
              <Button
                variant="outlined"
                size="small"
                leftIcon={AddIcon}
                onClick={handleOpenAddVendor}
                disabled={isFirstOutsourceCompleted}
              >
                Assign Vendor
              </Button>
            </div>

            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginTop: "-4px",
              }}
            >
              <div
                style={{ display: "flex", flexDirection: "column", gap: "4px" }}
              >
                <span
                  style={{
                    fontSize: "var(--text-body)",
                    color: "var(--neutral-on-surface-secondary)",
                  }}
                >
                  Outsourced Stages
                </span>
                <span
                  style={{
                    fontSize: "var(--text-title-3)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  {outsourceSteps.length > 1
                    ? `Step ${Math.min(...outsourceSteps)} to ${Math.max(
                      ...outsourceSteps
                    )}`
                    : `Step ${outsourceSteps[0]}`}
                </span>
              </div>

              {renderAllocationBar(totalVendorOutput, "mini")}
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                marginTop: "8px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  paddingBottom: "12px",
                  borderBottom: "1px solid var(--neutral-line-separator-1)",
                  fontWeight: "var(--font-weight-bold)",
                  fontSize: "var(--text-title-3)",
                }}
              >
                <div style={{ flex: "1.35" }}>Vendor Name</div>
                <div style={{ flex: "1.55" }}>Purchase Order</div>
                <div style={{ flex: "1" }}>Assigned Output</div>
                <div style={{ flex: "1" }}>Received Output</div>
                <div style={{ flex: "1.1" }}>Status</div>
                <div style={{ width: "40px" }}></div>
              </div>
              {vendors.length === 0 ? (
                <div
                  style={{
                    padding: "40px 24px",
                    textAlign: "center",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: "8px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "var(--text-title-3)",
                      fontWeight: "var(--font-weight-bold)",
                      color: "var(--neutral-on-surface-primary)",
                    }}
                  >
                    No vendor assigned yet
                  </span>
                  <span
                    style={{
                      color: "var(--neutral-on-surface-secondary)",
                      fontSize: "var(--text-body)",
                      width: "80vw",
                      maxWidth: "1600px",
                      lineHeight: "1.5",
                    }}
                  >
                    Add a vendor to assign outsourced output. You can also add
                    Internal from the Add Vendor modal.
                  </span>
                </div>
              ) : (
                vendors.map((vendor, i) => {
                  const isInternal = vendor.name === "Internal";
                  const resolvedVendorStatus = isInternal
                    ? internalStatusInfo.text
                    : resolveVendorProgressStatus(vendor);
                  const isCompleted = resolvedVendorStatus === "Completed";
                  const isPoApproved = vendor.isPoApproved;
                  const isVendorActionDisabled =
                    resolvedVendorStatus === "In Progress";

                  return (
                    <div
                      key={vendor.id}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        padding: "16px 0",
                        borderBottom:
                          i === vendors.length - 1
                            ? "none"
                            : "1px solid var(--neutral-line-separator-1)",
                        fontSize: "var(--text-title-3)",
                      }}
                    >
                      <div style={{ flex: "1.35" }}>
                        {vendor.name || "Internal"}
                      </div>

                      <div
                        style={{
                          flex: "1.55",
                          display: "flex",
                          alignItems: "center",
                          gap: "6px",
                          position: "relative",
                        }}
                      >
                        {!isInternal ? (
                          vendor.poNumber ? (
                            <>
                              <span
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenVendorMenuId(null);
                                  setOpenPoPopoverVendorId(null);
                                  setSelectedVendorForPoAction(vendor);
                                  scrollToTop();
                                  onNavigate("po_detail", {
                                    ...buildDummyPoDetailData(
                                      vendor.poNumber,
                                      vendor
                                    ),
                                    from: "work_order_detail",
                                    returnTo: {
                                      view: "detail",
                                      data: {
                                        ...initialData,
                                        vendors,
                                        routingStages,
                                        outsourceSteps,
                                        statusKey: woStatus,
                                        start: displayStartDate,
                                        end: displayEndDate,
                                      },
                                    },
                                  });
                                }}
                                style={{
                                  color: "var(--feature-brand-primary)",
                                  cursor: "pointer",
                                  textDecoration: "underline",
                                }}
                              >
                                {vendor.poNumber}
                              </span>
                              {isPoApproved ? (
                                <Tooltip content="PO Approved">
                                  <div
                                    style={{
                                      width: "16px",
                                      height: "16px",
                                      borderRadius: "50%",
                                      background: "var(--status-green-primary)",
                                      display: "flex",
                                      alignItems: "center",
                                      justifyContent: "center",
                                    }}
                                  >
                                    <CheckIcon size={10} color="white" />
                                  </div>
                                </Tooltip>
                              ) : null}
                            </>
                          ) : (
                            <>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setPoPopoverPosition(
                                    getPoPopoverPosition(
                                      e.currentTarget.getBoundingClientRect()
                                    )
                                  );
                                  handleOpenPoAction(vendor);
                                }}
                                style={{
                                  background: "var(--neutral-surface-primary)",
                                  border:
                                    "1px solid var(--neutral-line-separator-1)",
                                  padding: 0,
                                  margin: 0,
                                  fontSize: "var(--text-body)",
                                  color: "var(--feature-brand-primary)",
                                  cursor: "pointer",
                                }}
                              >
                                Add Purchase Order
                              </button>

                              {openPoPopoverVendorId === vendor.id &&
                                selectedVendorForPoAction?.id === vendor.id ? (
                                <>
                                  <div
                                    style={{
                                      position: "fixed",
                                      inset: 0,
                                      zIndex: 90,
                                    }}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenPoPopoverVendorId(null);
                                    }}
                                  />
                                  <div
                                    style={{
                                      position: "fixed",
                                      top: `${poPopoverPosition.top}px`,
                                      left: `${poPopoverPosition.left}px`,
                                      transform:
                                        poPopoverPosition.placement === "top"
                                          ? "translateY(-100%)"
                                          : "none",
                                      background:
                                        "var(--neutral-surface-primary)",
                                      borderRadius: "var(--radius-small)",
                                      boxShadow: "var(--elevation-sm)",
                                      border:
                                        "1px solid var(--neutral-line-separator-1)",
                                      zIndex: 101,
                                      display: "flex",
                                      flexDirection: "column",
                                      minWidth: "180px",
                                      padding: "4px 0",
                                    }}
                                  >
                                    <div
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleCreatePoFromVendor();
                                      }}
                                      onMouseEnter={(e) =>
                                      (e.currentTarget.style.background =
                                        "var(--neutral-surface-grey-lighter)")
                                      }
                                      onMouseLeave={(e) =>
                                      (e.currentTarget.style.background =
                                        "transparent")
                                      }
                                      style={{
                                        padding: "12px 16px",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "8px",
                                        cursor: "pointer",
                                        fontSize: "var(--text-title-3)",
                                        color:
                                          "var(--neutral-on-surface-primary)",
                                      }}
                                    >
                                      <AddIcon size={16} /> Create New PO
                                    </div>
                                    <div
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleOpenSelectExistingPo();
                                      }}
                                      onMouseEnter={(e) =>
                                      (e.currentTarget.style.background =
                                        "var(--neutral-surface-grey-lighter)")
                                      }
                                      onMouseLeave={(e) =>
                                      (e.currentTarget.style.background =
                                        "transparent")
                                      }
                                      style={{
                                        padding: "12px 16px",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "8px",
                                        cursor: "pointer",
                                        fontSize: "var(--text-title-3)",
                                        color:
                                          "var(--neutral-on-surface-primary)",
                                        borderTop:
                                          "1px solid var(--neutral-line-separator-1)",
                                      }}
                                    >
                                      <DocumentIcon size={16} /> Select Existing
                                      PO
                                    </div>
                                  </div>
                                </>
                              ) : null}
                            </>
                          )
                        ) : (
                          "-"
                        )}
                      </div>

                      <div style={{ flex: "1" }}>{vendor.output} pcs</div>
                      <div style={{ flex: "1" }}>
                        {vendor.receivedOutput || 0} pcs
                      </div>
                      <div style={{ flex: "1.1" }}>
                        {isInternal ? (
                          <StatusBadge variant={internalStatusInfo.variant}>
                            {internalStatusInfo.text}
                          </StatusBadge>
                        ) : (
                          <StatusBadge
                            variant={
                              resolvedVendorStatus === "Completed"
                                ? "green-light"
                                : resolvedVendorStatus === "Partially Received"
                                  ? "blue-light"
                                  : resolvedVendorStatus === "In Progress"
                                    ? "orange-light"
                                    : "yellow-light"
                            }
                          >
                            {resolvedVendorStatus}
                          </StatusBadge>
                        )}
                      </div>

                      <div
                        style={{
                          width: "40px",
                          display: "flex",
                          justifyContent: "flex-end",
                          alignItems: "center",
                          position: "relative",
                        }}
                      >
                        <IconButton
                          icon={MoreVerticalIcon}
                          size="medium"
                          color="var(--neutral-on-surface-secondary)"
                          title={
                            isVendorActionDisabled
                              ? "No actions available"
                              : "More actions"
                          }
                          disabled={isVendorActionDisabled}
                          onClick={(e) => {
                            e.stopPropagation();
                            const nextOpen =
                              openVendorMenuId === vendor.id ? null : vendor.id;
                            if (nextOpen) {
                              setVendorMenuPosition(
                                getVendorMenuPosition(
                                  e.currentTarget.getBoundingClientRect()
                                )
                              );
                            }
                            setOpenPoPopoverVendorId(null);
                            setOpenVendorMenuId(nextOpen);
                          }}
                        />

                        {openVendorMenuId === vendor.id ? (
                          <>
                            <div
                              style={{
                                position: "fixed",
                                inset: 0,
                                zIndex: 90,
                              }}
                              onClick={(e) => {
                                e.stopPropagation();
                                setOpenVendorMenuId(null);
                              }}
                            />
                            <div
                              style={{
                                position: "fixed",
                                top:
                                  vendorMenuPosition.placement === "top"
                                    ? `${vendorMenuPosition.top}px`
                                    : `${vendorMenuPosition.top}px`,
                                right: `${vendorMenuPosition.right}px`,
                                transform:
                                  vendorMenuPosition.placement === "top"
                                    ? "translateY(-100%)"
                                    : "none",
                                background: "var(--neutral-surface-primary)",
                                borderRadius: "var(--radius-small)",
                                boxShadow: "var(--elevation-sm)",
                                border:
                                  "1px solid var(--neutral-line-separator-1)",
                                zIndex: 100,
                                display: "flex",
                                flexDirection: "column",
                                minWidth: "180px",
                                padding: "4px 0",
                              }}
                            >
                              {!isPoApproved || isInternal ? (
                                <div
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleEditVendor(vendor);
                                    setOpenVendorMenuId(null);
                                  }}
                                  onMouseEnter={(e) =>
                                  (e.currentTarget.style.background =
                                    "var(--neutral-surface-grey-lighter)")
                                  }
                                  onMouseLeave={(e) =>
                                  (e.currentTarget.style.background =
                                    "transparent")
                                  }
                                  style={{
                                    padding: "12px 16px",
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "8px",
                                    cursor: "pointer",
                                    fontSize: "var(--text-title-3)",
                                    color: "var(--neutral-on-surface-primary)",
                                  }}
                                >
                                  <EditIcon size={16} /> Edit Details
                                </div>
                              ) : null}

                              {!(
                                isInternal &&
                                internalStatusInfo.text === "In Progress"
                              ) &&
                                !isCompleted &&
                                ((vendor.receivedOutput || 0) === 0 ||
                                  isInternal) &&
                                (isInternal || !isPoApproved) ? (
                                <div
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    promptRemoveVendor(vendor);
                                    setOpenVendorMenuId(null);
                                  }}
                                  onMouseEnter={(e) =>
                                  (e.currentTarget.style.background =
                                    "#FAE6E8")
                                  }
                                  onMouseLeave={(e) =>
                                  (e.currentTarget.style.background =
                                    "transparent")
                                  }
                                  style={{
                                    padding: "12px 16px",
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "8px",
                                    cursor: "pointer",
                                    fontSize: "var(--text-title-3)",
                                    color: "var(--status-red-primary)",
                                    background: "transparent",
                                  }}
                                >
                                  <DeleteIcon
                                    size={16}
                                    color="var(--status-red-primary)"
                                  />{" "}
                                  Remove Assignment
                                </div>
                              ) : null}

                              {vendor.receipts && vendor.receipts.length > 0 ? (
                                <div
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setReceiptHistoryVendor(vendor);
                                    setIsViewReceiptHistoryModalOpen(true);
                                    setOpenVendorMenuId(null);
                                  }}
                                  onMouseEnter={(e) =>
                                  (e.currentTarget.style.background =
                                    "var(--feature-brand-container-lighter)")
                                  }
                                  onMouseLeave={(e) =>
                                  (e.currentTarget.style.background =
                                    "transparent")
                                  }
                                  style={{
                                    padding: "12px 16px",
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "8px",
                                    cursor: "pointer",
                                    fontSize: "var(--text-title-3)",
                                    color: "var(--feature-brand-primary)",
                                    borderTop:
                                      "1px solid var(--neutral-line-separator-1)",
                                  }}
                                >
                                  <DocumentIcon size={16} /> Receipt History
                                </div>
                              ) : null}
                            </div>
                          </>
                        ) : null}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </Card>
        ) : null}
      </div>

      {woStatus === "not_started" ? (
        <div
          style={{
            position: "fixed",
            bottom: 0,
            left: isSidebarCollapsed ? "82px" : "286px",
            transition: "left 0.2s ease",
            right: 0,
            background: "var(--neutral-surface-primary)",
            borderTop: "1px solid var(--neutral-line-separator-1)",
            padding: "12px 24px",
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "center",
            zIndex: 100,
          }}
        >
          <Button
            variant="filled"
            size="medium"
            onClick={() => {
              setReadyStartDate(displayStartDate || "");
              setReadyEndDate(displayEndDate || "");
              setIsReadyModalOpen(true);
            }}
          >
            Ready to Process
          </Button>
        </div>
      ) : null}

      {isConfirmRemoveModalOpen && vendorToRemove ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "400px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "16px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setIsConfirmRemoveModalOpen(false)}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />
            <h2
              style={{
                margin: "0",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
                textAlign: "center",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              Remove Assignment
            </h2>
            <p
              style={{
                margin: "0 0 8px 0",
                fontSize: "var(--text-body)",
                color: "var(--neutral-on-surface-secondary)",
                textAlign: "center",
                lineHeight: "1.5",
              }}
            >
              Are you sure you want to remove this assignment?
            </p>
            <div
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <Button
                variant="filled"
                size="large"
                style={{ width: "100%" }}
                onClick={executeRemoveVendor}
              >
                Yes, Remove
              </Button>
              <Button
                variant="outlined"
                size="large"
                style={{ width: "100%" }}
                onClick={() => setIsConfirmRemoveModalOpen(false)}
              >
                Back
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {isReadyModalOpen ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "400px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "24px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setIsReadyModalOpen(false)}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />

            <h2
              style={{
                margin: "8px 0 0 0",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
                textAlign: "center",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              Set Planned Date
            </h2>

            <div
              style={{ display: "flex", flexDirection: "column", gap: "16px" }}
            >
              <div
                style={{ display: "flex", flexDirection: "column", gap: "8px" }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "2px",
                    fontSize: "var(--text-body)",
                    fontWeight: "var(--font-weight-regular)",
                  }}
                >
                  <span style={{ color: "var(--status-red-primary)" }}>*</span>
                  <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                    Planned Start Date
                  </span>
                </div>
                <DateInputControl
                  value={readyStartDate}
                  onChange={(e) => setReadyStartDate(e.target.value)}
                />
              </div>

              <div
                style={{ display: "flex", flexDirection: "column", gap: "8px" }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "2px",
                    fontSize: "var(--text-body)",
                    fontWeight: "var(--font-weight-regular)",
                  }}
                >
                  <span style={{ color: "var(--status-red-primary)" }}>*</span>
                  <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                    Planned End Date
                  </span>
                </div>
                <DateInputControl
                  value={readyEndDate}
                  onChange={(e) => setReadyEndDate(e.target.value)}
                />
              </div>
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "12px",
                marginTop: "8px",
              }}
            >
                <Button
                  variant="filled"
                  size="large"
                  disabled={!readyStartDate || !readyEndDate}
                  style={{ width: "100%" }}
                onClick={() => {
                  setDisplayStartDate(readyStartDate);
                  setDisplayEndDate(readyEndDate);
                  setIsReadyModalOpen(false);
                  setIsConfirmReadyModalOpen(true);
                }}
              >
                Continue
              </Button>
              <Button
                variant="outlined"
                size="large"
                style={{ width: "100%" }}
                onClick={() => setIsReadyModalOpen(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {isConfirmReadyModalOpen ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "400px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "16px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setIsConfirmReadyModalOpen(false)}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />

            <h2
              style={{
                margin: "0",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
                textAlign: "center",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              Confirm Action
            </h2>

            <p
              style={{
                margin: "0 0 8px 0",
                fontSize: "var(--text-body)",
                color: "var(--neutral-on-surface-secondary)",
                textAlign: "center",
                lineHeight: "1.5",
              }}
            >
              Are you sure you want to proceed?{" "}
              <strong>You cannot change the outsourced steps later</strong>{" "}
              after the work order is marked as ready to process.
            </p>

            <div
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <Button
                variant="filled"
                size="large"
                style={{ width: "100%" }}
                onClick={() => {
                  setIsConfirmReadyModalOpen(false);
                  setWoStatus("ready_to_process");
                  setVendors((prev) => prev);
                  setToastMessage("Marked as ready to process");
                  setShowSuccessToast(true);
                }}
              >
                Yes, Proceed
              </Button>
              <Button
                variant="outlined"
                size="large"
                style={{ width: "100%" }}
                onClick={() => setIsConfirmReadyModalOpen(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {isManageStageModalOpen && selectedStage ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "640px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "24px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setIsManageStageModalOpen(false)}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "4px",
                marginTop: "8px",
              }}
            >
              <h2
                style={{
                  margin: "0",
                  fontSize: "var(--text-headline)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--neutral-on-surface-primary)",
                }}
              >
                Manage Stage
              </h2>
              <span
                style={{
                  fontSize: "var(--text-body)",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                Stage: {selectedStage.op}
              </span>
            </div>

            <div
              style={{
                background: "var(--feature-brand-container-lighter)",
                borderRadius: "var(--radius-small)",
                padding: "12px",
                display: "flex",
                alignItems: "flex-start",
                gap: "8px",
                color: "var(--feature-brand-primary)",
              }}
            >
              <Info size={16} style={{ flexShrink: 0, marginTop: "2px" }} />
              <p
                style={{
                  margin: 0,
                  fontSize: "var(--text-body)",
                  lineHeight: "1.5",
                }}
              >
                Item must be completed in the previous stage to become available
                in the next one. Once Completed, items are locked and cannot be
                reverted.
              </p>
            </div>

            <div
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <span
                style={{
                  fontSize: "var(--text-title-2)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--neutral-on-surface-primary)",
                }}
              >
                Internal Progress
              </span>

              <div
                style={{
                  border: "1px solid var(--neutral-line-separator-1)",
                  borderRadius: "var(--radius-small)",
                  padding: "12px 16px",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "4px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "var(--text-title-3)",
                      color: "var(--neutral-on-surface-primary)",
                    }}
                  >
                    Yet to Start
                  </span>
                  <span
                    style={{
                      fontSize: "var(--text-desc)",
                      color: "var(--neutral-on-surface-tertiary)",
                    }}
                  >
                    Available Pool: {stageStart}
                  </span>
                </div>
                <span
                  style={{
                    fontSize: "20px",
                    fontWeight: "var(--font-weight-bold)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  {stageStart}
                </span>
              </div>

              <div
                style={{
                  border: "1px solid var(--neutral-line-separator-1)",
                  borderRadius: "var(--radius-small)",
                  padding: "12px 16px",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-3)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  In Progress
                </span>
                <div
                  style={{ display: "flex", alignItems: "center", gap: "8px" }}
                >
                  <button
                    disabled={stageProg <= stageOriginalProg}
                    onClick={() => {
                      if (stageProgError) setStageProgError("");
                      setStageProg((prev) => {
                        const next = Math.max(stageOriginalProg, prev - 1);
                        setStageMaxCompletable(stageOriginalComp + next);
                        return next;
                      });
                      setStageStart((prev) => prev + 1);
                    }}
                    style={{
                      width: "32px",
                      height: "32px",
                      borderRadius: "var(--radius-small)",
                      background:
                        stageProg <= stageOriginalProg
                          ? "var(--neutral-surface-grey-lighter)"
                          : "transparent",
                      border:
                        stageProg <= stageOriginalProg
                          ? "1px solid transparent"
                          : "1px solid var(--feature-brand-primary)",
                      cursor:
                        stageProg <= stageOriginalProg
                          ? "not-allowed"
                          : "pointer",
                      opacity: 1,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      transition: "all 0.15s ease",
                    }}
                  >
                    <Minus
                      size={16}
                      color={
                        stageProg <= stageOriginalProg
                          ? "var(--neutral-on-surface-tertiary)"
                          : "var(--feature-brand-primary)"
                      }
                    />
                  </button>
                  <input
                    type="text"
                    value={stageProg === 0 ? "" : stageProg}
                    placeholder="0"
                    onChange={(e) => {
                      let raw = e.target.value.replace(/\D/g, "");
                      if (raw.length > 1) {
                        raw = raw.replace(/^0+/, "");
                        if (raw === "") raw = "0";
                      }

                      const nextProg = raw === "" ? 0 : parseInt(raw, 10);
                      if (Number.isNaN(nextProg)) return;

                      if (stageProgError) setStageProgError("");
                      const maxProg = Math.max(0, stageTotalPool - stageComp);
                      const clampedProg = Math.max(
                        0,
                        Math.min(nextProg, maxProg)
                      );
                      const nextStart = Math.max(
                        0,
                        stageTotalPool - stageComp - clampedProg
                      );
                      setStageProg(clampedProg);
                      setStageStart(nextStart);
                      setStageMaxCompletable(
                        stageOriginalComp + clampedProg + nextStart
                      );
                    }}
                    style={{
                      width: "56px",
                      height: "32px",
                      textAlign: "center",
                      fontSize: "var(--text-subtitle-1)",
                      fontWeight: "var(--font-weight-bold)",
                      color:
                        stageProg === 0
                          ? "var(--neutral-on-surface-tertiary)"
                          : "var(--neutral-on-surface-primary)",
                      border: stageProgError
                        ? "1px solid var(--status-red-primary)"
                        : "1px solid var(--neutral-line-separator-1)",
                      borderRadius: "var(--radius-small)",
                      outline: "none",
                      background: "var(--neutral-surface-primary)",
                      transition: "border-color 0.2s",
                    }}
                    onFocus={(e) =>
                    (e.target.style.borderColor = stageProgError
                      ? "var(--status-red-primary)"
                      : "var(--feature-brand-primary)")
                    }
                    onBlur={(e) =>
                    (e.target.style.borderColor = stageProgError
                      ? "var(--status-red-primary)"
                      : "var(--neutral-line-separator-1)")
                    }
                  />
                  <button
                    disabled={stageStart === 0}
                    onClick={() => {
                      if (stageProgError) setStageProgError("");
                      const nextProg = stageProg + 1;
                      const nextStart = Math.max(0, stageStart - 1);
                      setStageProg(nextProg);
                      setStageStart(nextStart);
                      setStageMaxCompletable(
                        stageOriginalComp + nextProg + nextStart
                      );
                    }}
                    style={{
                      width: "32px",
                      height: "32px",
                      borderRadius: "var(--radius-small)",
                      background:
                        stageStart === 0
                          ? "var(--neutral-surface-grey-lighter)"
                          : "var(--feature-brand-primary)",
                      border: "1px solid var(--neutral-line-separator-1)",
                      cursor: stageStart === 0 ? "not-allowed" : "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      transition: "all 0.15s ease",
                    }}
                  >
                    <AddIcon
                      size={16}
                      color={
                        stageProg === 0
                          ? "var(--neutral-on-surface-tertiary)"
                          : "var(--neutral-surface-primary)"
                      }
                    />
                  </button>
                </div>
              </div>
              {stageProgError ? (
                <span
                  style={{
                    marginTop: "-4px",
                    fontSize: "var(--text-body)",
                    color: "var(--status-red-primary)",
                  }}
                >
                  {stageProgError}
                </span>
              ) : null}
            </div>
            <div
              style={{
                border: "1px solid var(--neutral-line-separator-1)",
                borderRadius: "var(--radius-small)",
                padding: "12px 16px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <span
                style={{
                  fontSize: "var(--text-title-3)",
                  color: "var(--neutral-on-surface-primary)",
                }}
              >
                Completed
              </span>
              <div
                style={{ display: "flex", alignItems: "center", gap: "8px" }}
              >
                <button
                  disabled={stageComp <= stageOriginalComp}
                  onClick={() => {
                    const nextComp = stageComp - 1;
                    const nextStart = stageStart + 1;
                    setStageComp(nextComp);
                    setStageStart(nextStart);
                    setStageCompInput(String(nextComp));
                    setStageMaxCompletable(
                      stageOriginalComp + nextStart + stageProg
                    );
                    setStageCompError("");
                  }}
                  style={{
                    width: "32px",
                    height: "32px",
                    borderRadius: "var(--radius-small)",
                    background:
                      stageComp <= stageOriginalComp
                        ? "var(--neutral-surface-grey-lighter)"
                        : "transparent",
                    border:
                      stageComp <= stageOriginalComp
                        ? "1px solid transparent"
                        : "1px solid var(--feature-brand-primary)",
                    cursor:
                      stageComp <= stageOriginalComp
                        ? "not-allowed"
                        : "pointer",
                    opacity: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all 0.15s ease",
                  }}
                >
                  <Minus
                    size={16}
                    color={
                      stageComp <= stageOriginalComp
                        ? "var(--neutral-on-surface-tertiary)"
                        : "var(--feature-brand-primary)"
                    }
                  />
                </button>
                <input
                  type="text"
                  value={stageCompInput === "0" ? "" : stageCompInput}
                  placeholder="0"
                  onChange={(e) => {
                    let raw = e.target.value.replace(/\D/g, "");
                    if (raw.length > 1) {
                      raw = raw.replace(/^0+/, "");
                      if (raw === "") raw = "0";
                    }

                    setStageCompInput(raw);
                    if (stageCompError) setStageCompError("");

                    const nextComp = raw === "" ? 0 : parseInt(raw, 10);
                    if (!Number.isNaN(nextComp)) {
                      const totalAvailablePool = stageTotalPool;
                      const clampedComp = Math.max(
                        stageOriginalComp,
                        Math.min(nextComp, totalAvailablePool)
                      );
                      setStageComp(clampedComp);
                      const remainder = Math.max(
                        0,
                        totalAvailablePool - clampedComp
                      );
                      const nextProg = Math.min(stageProg, remainder);
                      const nextStart = Math.max(0, remainder - nextProg);
                      setStageProg(nextProg);
                      setStageStart(nextStart);
                    }
                  }}
                  style={{
                    width: "56px",
                    height: "32px",
                    textAlign: "center",
                    fontSize: "var(--text-subtitle-1)",
                    fontWeight: "var(--font-weight-bold)",
                    color:
                      stageCompInput === "" || stageCompInput === "0"
                        ? "var(--neutral-on-surface-tertiary)"
                        : "var(--neutral-on-surface-primary)",
                    border: stageCompError
                      ? "1px solid var(--status-red-primary)"
                      : "1px solid var(--neutral-line-separator-1)",
                    borderRadius: "var(--radius-small)",
                    outline: "none",
                    background: "var(--neutral-surface-primary)",
                    transition: "border-color 0.2s",
                  }}
                  onFocus={(e) =>
                  (e.target.style.borderColor = stageCompError
                    ? "var(--status-red-primary)"
                    : "var(--feature-brand-primary)")
                  }
                  onBlur={(e) =>
                  (e.target.style.borderColor = stageCompError
                    ? "var(--status-red-primary)"
                    : "var(--neutral-line-separator-1)")
                  }
                />
                <button
                  disabled={stageStart === 0 && stageProg === 0}
                  onClick={() => {
                    const nextComp = stageComp + 1;
                    const shouldUseYetToStart = stageStart > 0;
                    const nextStart = shouldUseYetToStart
                      ? stageStart - 1
                      : stageStart;
                    const nextProg = shouldUseYetToStart
                      ? stageProg
                      : Math.max(0, stageProg - 1);
                    setStageComp(nextComp);
                    setStageStart(nextStart);
                    setStageProg(nextProg);
                    setStageCompInput(String(nextComp));
                    setStageMaxCompletable(
                      stageOriginalComp + nextStart + nextProg
                    );
                    setStageCompError("");
                  }}
                  style={{
                    width: "32px",
                    height: "32px",
                    borderRadius: "var(--radius-small)",
                    background:
                      stageStart === 0 && stageProg === 0
                        ? "var(--neutral-surface-grey-lighter)"
                        : "var(--feature-brand-primary)",
                    border: "1px solid var(--neutral-line-separator-1)",
                    cursor:
                      stageStart === 0 && stageProg === 0
                        ? "not-allowed"
                        : "pointer",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all 0.15s ease",
                  }}
                >
                  <AddIcon
                    size={16}
                    color={
                      stageStart === 0 && stageProg === 0
                        ? "var(--neutral-on-surface-tertiary)"
                        : "var(--neutral-surface-primary)"
                    }
                  />
                </button>
              </div>
            </div>

            {stageCompError ? (
              <span
                style={{
                  marginTop: "-4px",
                  fontSize: "var(--text-body)",
                  color: "var(--status-red-primary)",
                }}
              >
                {stageCompError}
              </span>
            ) : null}

            {isSelectedStageOutsourced ? (
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "12px",
                }}
              >
                <button
                  type="button"
                  onClick={() =>
                    setIsManageStageVendorSectionExpanded((prev) => !prev)
                  }
                  style={{
                    background: "none",
                    border: "none",
                    padding: 0,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    cursor: "pointer",
                    width: "100%",
                    gap: "12px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "var(--text-title-2)",
                      fontWeight: "var(--font-weight-bold)",
                      color: "var(--neutral-on-surface-primary)",
                      whiteSpace: "nowrap",
                    }}
                  >
                    Assigned Vendors
                  </span>
                  <div
                    style={{
                      flex: 1,
                      height: "1px",
                      background: "var(--neutral-line-separator-1)",
                    }}
                  />
                  <ChevronDownIcon
                    size={18}
                    color="var(--neutral-on-surface-secondary)"
                    style={{
                      transform: isManageStageVendorSectionExpanded
                        ? "rotate(180deg)"
                        : "rotate(0deg)",
                      transition: "transform 0.2s ease",
                    }}
                  />
                </button>
                {isManageStageVendorSectionExpanded ? (
                  <div style={poReferenceTableFrameStyle}>
                    <div
                      style={{
                        ...poReferenceTableScrollerStyle,
                        maxHeight: "220px",
                        overflowY: "auto",
                      }}
                    >
                      <div style={poReferenceTableInnerStyle("640px")}>
                        <div
                          style={{
                            ...poReferenceTableHeaderRowStyle(
                              "1.4fr 1fr 1fr 1.1fr"
                            ),
                            position: "sticky",
                            top: 0,
                            zIndex: 2,
                          }}
                        >
                          <div style={poReferenceTableHeaderCellStyle()}>
                            Vendor Name
                          </div>
                          <div style={poReferenceTableHeaderCellStyle()}>
                            Assigned Output
                          </div>
                          <div style={poReferenceTableHeaderCellStyle()}>
                            Received Output
                          </div>
                          <div style={poReferenceTableHeaderCellStyle()}>
                            Status
                          </div>
                        </div>
                        {(vendors.length > 0 ? vendors : []).map(
                          (vendor, idx) => {
                            const isInternal = vendor.name === "Internal";
                            const resolvedVendorStatus = isInternal
                              ? internalStatusInfo.text
                              : resolveVendorProgressStatus(vendor);
                            const badgeVariant = isInternal
                              ? internalStatusInfo.variant
                              : resolvedVendorStatus === "Completed"
                                ? "green-light"
                                : resolvedVendorStatus === "Partially Received"
                                  ? "blue-light"
                                  : resolvedVendorStatus === "In Progress"
                                    ? "orange-light"
                                    : resolvedVendorStatus === "Not Started"
                                      ? "grey-light"
                                      : "yellow-light";
                            const badgeText = resolvedVendorStatus;
                            return (
                              <div
                                key={vendor.id}
                                style={poReferenceTableRowStyle(
                                  "1.4fr 1fr 1fr 1.1fr",
                                  idx === vendors.length - 1
                                )}
                              >
                                <div
                                  style={poReferenceTableCellStyle({
                                    minWidth: 0,
                                  })}
                                >
                                  <span
                                    style={{
                                      display: "block",
                                      whiteSpace: "nowrap",
                                      overflow: "hidden",
                                      textOverflow: "ellipsis",
                                    }}
                                  >
                                    {vendor.name}
                                  </span>
                                </div>
                                <div style={poReferenceTableCellStyle()}>
                                  {vendor.output || 0} pcs
                                </div>
                                <div style={poReferenceTableCellStyle()}>
                                  {vendor.receivedOutput || 0} pcs
                                </div>
                                <div style={poReferenceTableCellStyle()}>
                                  <StatusBadge variant={badgeVariant}>
                                    {badgeText}
                                  </StatusBadge>
                                </div>
                              </div>
                            );
                          }
                        )}
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            ) : null}

            <div style={{ marginTop: "8px" }}>
              <Button
                variant="filled"
                size="large"
                style={{ width: "100%" }}
                onClick={() => {
                  const minComp = stageOriginalComp;
                  const sanitizedCompInput =
                    stageCompInput === "" ? 0 : parseInt(stageCompInput, 10);
                  const maxComp = stageTotalPool;

                  if (Number.isNaN(sanitizedCompInput)) {
                    setStageCompError(
                      "Completed value must be a valid number."
                    );
                    return;
                  }

                  if (sanitizedCompInput < minComp) {
                    setStageCompError(
                      `Completed value cannot be lower than ${minComp}.`
                    );
                    return;
                  }

                  if (sanitizedCompInput > maxComp) {
                    setStageCompError(
                      `Completed value cannot be higher than ${maxComp}.`
                    );
                    return;
                  }

                  if (stageProg < stageOriginalProg) {
                    setStageCompError("");
                    setStageProgError(
                      `In progress value cannot be lower than ${stageOriginalProg}.`
                    );
                    return;
                  }

                  const finalStageComp = sanitizedCompInput;
                  const finalStageProg = Math.max(
                    0,
                    Math.min(stageProg, stageTotalPool - finalStageComp)
                  );

                  setRoutingStages((prev) =>
                    prev.map((r) =>
                      r.step === selectedStage.step
                        ? { ...r, prog: finalStageProg, comp: finalStageComp }
                        : r
                    )
                  );
                  setStageComp(finalStageComp);
                  setStageProg(finalStageProg);
                  setStageCompInput(String(finalStageComp));
                  setStageProgError("");
                  setStageCompError("");
                  setIsManageStageModalOpen(false);
                  if (woStatus === "ready_to_process") {
                    setWoStatus("in_progress");
                  }

                  setToastMessage("Routing stage successfully updated");
                  setShowSuccessToast(true);
                }}
              >
                Update
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {isSelectExistingPoModalOpen && selectedVendorForPoAction ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: selectedExistingPoNumber ? "900px" : "450px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              display: "flex",
              flexDirection: selectedExistingPoNumber ? "row" : "column",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
              overflow: "hidden",
              maxHeight: "90vh",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setIsSelectExistingPoModalOpen(false)}
              style={{
                position: "absolute",
                top: "16px",
                right: "16px",
                zIndex: 10,
              }}
              color="var(--neutral-on-surface-tertiary)"
            />

            <div
              style={{
                flex: selectedExistingPoNumber ? "1.5" : "1",
                padding: "32px",
                display: "flex",
                flexDirection: "column",
                gap: "24px",
                overflowY: "auto",
              }}
            >
              <div
                style={{ display: "flex", flexDirection: "column", gap: "4px" }}
              >
                <h2
                  style={{
                    margin: "0",
                    fontSize: "var(--text-headline)",
                    fontWeight: "var(--font-weight-bold)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  Select Existing Purchase Order
                </h2>
                <span
                  style={{
                    fontSize: "var(--text-body)",
                    color: "var(--neutral-on-surface-secondary)",
                  }}
                >
                  {selectedVendorForPoAction.name}
                </span>
              </div>

              <div
                style={{ display: "flex", flexDirection: "column", gap: "8px" }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "2px",
                    fontSize: "var(--text-body)",
                    fontWeight: "var(--font-weight-regular)",
                  }}
                >
                  <span style={{ color: "var(--status-red-primary)" }}>*</span>
                  <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                    Purchase Order
                  </span>
                </div>
                <div style={{ position: "relative", width: "100%" }}>
                  <DropdownSelect
                    value={selectedExistingPoNumber}
                    onChange={(nextValue) =>
                      setSelectedExistingPoNumber(nextValue)
                    }
                    disabled={!!singleVendorForm.lockedVendorName}
                    placeholder="Select purchase order"
                    options={MOCK_PO_TABLE_DATA.filter(
                      (po) =>
                        po.vendorName === selectedVendorForPoAction.name &&
                        !["issued", "completed"].includes(po.statusKey)
                    ).map((po) => ({
                      value: po.poNumber,
                      label: `${po.poNumber} (${po.status})`,
                    }))}
                  />
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  gap: "12px",
                  marginTop: "auto",
                  paddingTop: "12px",
                }}
              >
                <Button
                  variant="outlined"
                  size="large"
                  style={{ flex: 1 }}
                  onClick={() => setIsSelectExistingPoModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="filled"
                  size="large"
                  style={{ flex: 1 }}
                  disabled={!selectedExistingPoNumber}
                  onClick={handleAttachExistingPo}
                >
                  Assign PO
                </Button>
              </div>
            </div>

            {selectedExistingPoNumber
              ? (() => {
                const selectedPo = MOCK_PO_TABLE_DATA.find(
                  (p) => p.poNumber === selectedExistingPoNumber
                );
                const shipToInfo = {
                  name: "Labamu Manufacturing",
                  phone: "+62 21 555 1234",
                  email: "procurement@labamu.com",
                  address:
                    "Jl. Industri Utama Kav 9, South Tangerang, Banten, Indonesia 15320",
                };
                const vDeets =
                  MOCK_VENDORS.find(
                    (v) => v.name === selectedPo?.vendorName
                  ) || {};

                return (
                  <div
                    style={{
                      flex: "1",
                      background: "var(--neutral-surface-grey-lighter)",
                      padding: "32px",
                      display: "flex",
                      flexDirection: "column",
                      gap: "20px",
                      overflowY: "auto",
                      borderLeft: "1px solid var(--neutral-line-separator-1)",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                      }}
                    >
                      <span
                        style={{
                          fontSize: "var(--text-title-1)",
                          fontWeight: "var(--font-weight-bold)",
                        }}
                      >
                        {selectedPo?.poNumber}
                      </span>
                      <StatusBadge variant={selectedPo?.sBadge}>
                        {selectedPo?.status}
                      </StatusBadge>
                    </div>

                    <Card
                      style={{
                        padding: "16px",
                        gap: "16px",
                        boxShadow: "none",
                        background: "var(--neutral-surface-primary)",
                      }}
                    >
                      <div
                        style={{
                          display: "grid",
                          gridTemplateColumns: "1fr 1fr",
                          gap: "16px",
                        }}
                      >
                        <LabelValue
                          label="PO Date"
                          value={selectedPo?.createdDate || "-"}
                        />
                        <LabelValue
                          label="Expected Delivery Date"
                          value={expectedDeliveryDate ?? null}
                        />
                        <LabelValue
                          label="Currency"
                          value="IDR - Indonesian Rupiah"
                        />
                        <LabelValue label="Created By" value="Joko" />
                      </div>
                    </Card>

                    <Card
                      style={{
                        padding: "16px",
                        gap: "16px",
                        boxShadow: "none",
                        background: "var(--neutral-surface-primary)",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          borderBottom:
                            "1px solid var(--neutral-line-separator-1)",
                          paddingBottom: "12px",
                        }}
                      >
                        <Building2
                          size={16}
                          color="var(--neutral-on-surface-tertiary)"
                        />
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            fontWeight: "var(--font-weight-bold)",
                          }}
                        >
                          Vendor Information
                        </span>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "12px",
                        }}
                      >
                        <LabelValue
                          label="Vendor Name"
                          value={selectedPo?.vendorName || "-"}
                        />
                        <LabelValue
                          label="Phone Number"
                          value={vDeets.phone || "-"}
                        />
                        <LabelValue
                          label="Email"
                          value={vDeets.email || "-"}
                        />
                        <LabelValue
                          label="Address"
                          value={vDeets.address || "-"}
                        />
                      </div>
                    </Card>

                    <Card
                      style={{
                        padding: "16px",
                        gap: "16px",
                        boxShadow: "none",
                        background: "var(--neutral-surface-primary)",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          borderBottom:
                            "1px solid var(--neutral-line-separator-1)",
                          paddingBottom: "12px",
                        }}
                      >
                        <Building2
                          size={16}
                          color="var(--neutral-on-surface-tertiary)"
                        />
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            fontWeight: "var(--font-weight-bold)",
                          }}
                        >
                          Ship To
                        </span>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "12px",
                        }}
                      >
                        <LabelValue
                          label="Recipient Name"
                          value={shipToInfo.name}
                        />
                        <LabelValue
                          label="Phone Number"
                          value={shipToInfo.phone}
                        />
                        <LabelValue label="Email" value={shipToInfo.email} />
                        <LabelValue
                          label="Address"
                          value={shipToInfo.address}
                        />
                      </div>
                    </Card>

                    <Card
                      style={{
                        padding: "16px",
                        gap: "16px",
                        boxShadow: "none",
                        background: "var(--neutral-surface-primary)",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          borderBottom:
                            "1px solid var(--neutral-line-separator-1)",
                          paddingBottom: "12px",
                        }}
                      >
                        <DocumentIcon
                          size={16}
                          color="var(--neutral-on-surface-tertiary)"
                        />
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            fontWeight: "var(--font-weight-bold)",
                          }}
                        >
                          Notes & Terms
                        </span>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "12px",
                        }}
                      >
                        <LabelValue
                          label="Notes"
                          value="Please ensure all items are packaged securely to prevent damage during transit. Deliveries are only accepted between 08:00 AM and 04:00 PM on weekdays."
                        />
                        <LabelValue
                          label="Terms"
                          value="Payment within 30 days of receipt."
                        />
                      </div>
                    </Card>
                  </div>
                );
              })()
              : null}
          </div>
        </div>
      ) : null}

      {isSingleVendorModalOpen ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: singleVendorForm.poNumber ? "900px" : "450px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              display: "flex",
              flexDirection: singleVendorForm.poNumber ? "row" : "column",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
              transition: "width 0.3s ease",
              overflow: "hidden",
              maxHeight: "90vh",
            }}
          >
            <div
              style={{
                flex: singleVendorForm.poNumber ? "1.5" : "1",
                padding: "32px",
                display: "flex",
                flexDirection: "column",
                gap: "24px",
                overflowY: "auto",
              }}
            >
              <div
                style={{
                  position: "relative",
                  minHeight: "40px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <h2
                  style={{
                    margin: 0,
                    fontSize: "var(--text-headline)",
                    fontWeight: "var(--font-weight-bold)",
                    textAlign: "center",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  {singleVendorForm.id
                    ? "Edit Assigned Vendor"
                    : "Add Assigned Vendor"}
                </h2>
                <IconButton
                  icon={CloseIcon}
                  size="large"
                  onClick={() => setIsSingleVendorModalOpen(false)}
                  style={{ position: "absolute", top: "-4px", right: 0 }}
                  color="var(--neutral-on-surface-tertiary)"
                />
              </div>

              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "16px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "2px",
                      fontSize: "var(--text-body)",
                      fontWeight: "var(--font-weight-regular)",
                    }}
                  >
                    <span style={{ color: "var(--status-red-primary)" }}>
                      *
                    </span>
                    <span
                      style={{ color: "var(--neutral-on-surface-primary)" }}
                    >
                      Vendor Name
                    </span>
                  </div>
                  <div style={{ position: "relative", width: "100%" }}>
                    <DropdownSelect
                      value={singleVendorForm.name}
                      disabled={!!singleVendorForm.lockedVendorName}
                      onChange={(nextValue) =>
                        setSingleVendorForm({
                          ...singleVendorForm,
                          name: nextValue,
                          poNumber: "",
                        })
                      }
                      placeholder="Select Vendor"
                      options={[
                        ...(!vendors.some(
                          (v) =>
                            v.name === "Internal" && v.id !== singleVendorForm.id
                        )
                          ? [{ value: "Internal", label: "Internal" }]
                          : []),
                        ...["PT Mitra Sejahtera", "CV Kayu Makmur", "Bintang Sejahtera"]
                          .filter(
                            (vName) =>
                              !vendors.some(
                                (v) =>
                                  v.name === vName &&
                                  v.id !== singleVendorForm.id &&
                                  !v.isPoApproved
                              )
                          )
                          .map((vName) => ({ value: vName, label: vName })),
                      ]}
                    />
                  </div>
                </div>

                {singleVendorForm.name &&
                  singleVendorForm.name !== "Internal" ? (
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "8px",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "2px",
                        fontSize: "var(--text-body)",
                        fontWeight: "var(--font-weight-regular)",
                      }}
                    >
                      <span
                        style={{ color: "var(--neutral-on-surface-primary)" }}
                      >
                        Purchase Order
                      </span>
                    </div>
                    <div style={{ position: "relative", width: "100%" }}>
                      <DropdownSelect
                        value={singleVendorForm.poNumber}
                        onChange={(nextValue) =>
                          setSingleVendorForm({
                            ...singleVendorForm,
                            poNumber: nextValue,
                          })
                        }
                        placeholder="Select purchase order (optional)"
                        options={MOCK_PO_TABLE_DATA.filter(
                          (po) =>
                            po.vendorName === singleVendorForm.name &&
                            !["issued", "completed"].includes(po.statusKey)
                        ).map((po) => ({
                          value: po.poNumber,
                          label: `${po.poNumber} (${po.status})`,
                        }))}
                      />
                    </div>
                  </div>
                ) : null}

                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "2px",
                        fontSize: "var(--text-body)",
                        fontWeight: "var(--font-weight-regular)",
                      }}
                    >
                      <span style={{ color: "var(--status-red-primary)" }}>
                        *
                      </span>
                      <span
                        style={{ color: "var(--neutral-on-surface-primary)" }}
                      >
                        Assigned Output
                      </span>
                    </div>
                    <span
                      style={{
                        fontSize: "var(--text-desc)",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      {editingInternalVendor && editingInternalMinimumOutput > 0
                        ? `Minimum assigned output: ${editingInternalMinimumOutput} pcs`
                        : `Available: ${Math.max(
                          0,
                          TOTAL_QTY -
                          vendors
                            .filter((v) => v.id !== singleVendorForm.id)
                            .reduce(
                              (sum, v) =>
                                sum + (parseInt(v.output, 10) || 0),
                              0
                            )
                        )} pcs`}
                    </span>
                  </div>
                  <InputGroup
                    type="number"
                    value={singleVendorForm.output}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === "") {
                        if (assignedOutputError) setAssignedOutputError("");
                        setSingleVendorForm({
                          ...singleVendorForm,
                          output: "",
                        });
                      } else {
                        const numValue = parseInt(val, 10);
                        if (!isNaN(numValue) && numValue >= 0) {
                          if (
                            editingInternalVendor &&
                            numValue < editingInternalMinimumOutput
                          ) {
                            setAssignedOutputError(
                              internalAssignedOutputErrorMessage
                            );
                          } else if (assignedOutputError) {
                            setAssignedOutputError("");
                          }
                          setSingleVendorForm({
                            ...singleVendorForm,
                            output: numValue.toString(),
                          });
                        }
                      }
                    }}
                    placeholder="0"
                    suffix="pcs"
                    hasError={!!assignedOutputError}
                  />
                  {assignedOutputError ? (
                    <span
                      style={{
                        fontSize: "var(--text-body)",
                        color: "var(--status-red-primary)",
                      }}
                    >
                      {assignedOutputError}
                    </span>
                  ) : null}
                </div>
              </div>

              {(() => {
                const currentOtherTotal = vendors
                  .filter((v) => v.id !== singleVendorForm.id)
                  .reduce((sum, v) => sum + (parseInt(v.output, 10) || 0), 0);
                const proposedTotal =
                  currentOtherTotal +
                  (parseInt(singleVendorForm.output, 10) || 0);
                if (proposedTotal > TOTAL_QTY) {
                  return (
                    <span
                      style={{
                        color: "var(--status-red-primary)",
                        fontSize: "var(--text-body)",
                        marginTop: "-8px",
                      }}
                    >
                      Error: Total assigned output ({proposedTotal}) cannot
                      exceed work order quantity ({TOTAL_QTY}).
                    </span>
                  );
                }
                return null;
              })()}

              <div
                style={{
                  display: "flex",
                  gap: "12px",
                  marginTop: "auto",
                  paddingTop: "12px",
                }}
              >
                <Button
                  variant="outlined"
                  size="large"
                  style={{ flex: 1 }}
                  onClick={() => {
                    setAssignedOutputError("");
                    setIsSingleVendorModalOpen(false);
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="filled"
                  size="large"
                  disabled={(() => {
                    const currentOtherTotal = vendors
                      .filter((v) => v.id !== singleVendorForm.id)
                      .reduce(
                        (sum, v) => sum + (parseInt(v.output, 10) || 0),
                        0
                      );
                    const proposedTotal =
                      currentOtherTotal +
                      (parseInt(singleVendorForm.output, 10) || 0);
                    return (
                      !singleVendorForm.name ||
                      !singleVendorForm.output ||
                      proposedTotal > TOTAL_QTY ||
                      !!assignedOutputError
                    );
                  })()}
                  style={{ flex: 1 }}
                  onClick={handleSaveSingleVendor}
                >
                  Save
                </Button>
              </div>
            </div>

            {singleVendorForm.poNumber
              ? (() => {
                const selectedPo = MOCK_PO_TABLE_DATA.find(
                  (p) => p.poNumber === singleVendorForm.poNumber
                );
                const shipToInfo = {
                  name: "Labamu Manufacturing",
                  phone: "+62 21 555 1234",
                  email: "procurement@labamu.com",
                  address:
                    "Jl. Industri Utama Kav 9, South Tangerang, Banten, Indonesia 15320",
                };
                const vDeets =
                  MOCK_VENDORS.find(
                    (v) => v.name === selectedPo?.vendorName
                  ) || {};

                return (
                  <div
                    style={{
                      flex: "1",
                      background: "var(--neutral-surface-grey-lighter)",
                      padding: "32px",
                      display: "flex",
                      flexDirection: "column",
                      gap: "20px",
                      overflowY: "auto",
                      borderLeft: "1px solid var(--neutral-line-separator-1)",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                      }}
                    >
                      <span
                        style={{
                          fontSize: "var(--text-title-1)",
                          fontWeight: "var(--font-weight-bold)",
                        }}
                      >
                        {selectedPo?.poNumber}
                      </span>
                      <StatusBadge variant={selectedPo?.sBadge}>
                        {selectedPo?.status}
                      </StatusBadge>
                    </div>

                    <Card
                      style={{
                        padding: "16px",
                        gap: "16px",
                        boxShadow: "none",
                        background: "var(--neutral-surface-primary)",
                      }}
                    >
                      <div
                        style={{
                          display: "grid",
                          gridTemplateColumns: "1fr 1fr",
                          gap: "16px",
                        }}
                      >
                        <LabelValue
                          label="PO Date"
                          value={selectedPo?.createdDate || "-"}
                        />
                        <LabelValue
                          label="Expected Delivery Date"
                          value={expectedDeliveryDate ?? null}
                        />
                        <LabelValue
                          label="Currency"
                          value="IDR - Indonesian Rupiah"
                        />
                        <LabelValue label="Created By" value="Joko" />
                      </div>
                    </Card>

                    <Card
                      style={{
                        padding: "16px",
                        gap: "16px",
                        boxShadow: "none",
                        background: "var(--neutral-surface-primary)",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          borderBottom:
                            "1px solid var(--neutral-line-separator-1)",
                          paddingBottom: "12px",
                        }}
                      >
                        <Building2
                          size={16}
                          color="var(--neutral-on-surface-tertiary)"
                        />
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            fontWeight: "var(--font-weight-bold)",
                          }}
                        >
                          Ship To
                        </span>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "12px",
                        }}
                      >
                        <LabelValue
                          label="Recipient Name"
                          value={shipToInfo.name}
                        />
                        <LabelValue
                          label="Phone Number"
                          value={shipToInfo.phone}
                        />
                        <LabelValue label="Email" value={shipToInfo.email} />
                        <LabelValue
                          label="Address"
                          value={shipToInfo.address}
                        />
                      </div>
                    </Card>

                    <Card
                      style={{
                        padding: "16px",
                        gap: "16px",
                        boxShadow: "none",
                        background: "var(--neutral-surface-primary)",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          borderBottom:
                            "1px solid var(--neutral-line-separator-1)",
                          paddingBottom: "12px",
                        }}
                      >
                        <DocumentIcon
                          size={16}
                          color="var(--neutral-on-surface-tertiary)"
                        />
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            fontWeight: "var(--font-weight-bold)",
                          }}
                        >
                          Notes & Terms
                        </span>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "12px",
                        }}
                      >
                        <LabelValue
                          label="Notes"
                          value="Please ensure all items are packaged securely to prevent damage during transit. Deliveries are only accepted between 08:00 AM and 04:00 PM on weekdays."
                        />
                        <LabelValue
                          label="Terms"
                          value="Payment within 30 days of receipt."
                        />
                      </div>
                    </Card>
                  </div>
                );
              })()
              : null}
          </div>
        </div>
      ) : null}

      {isCreatePoModalOpen ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "900px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              display: "flex",
              overflow: "hidden",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
              maxHeight: "90vh",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setIsCreatePoModalOpen(false)}
              style={{
                position: "absolute",
                top: "16px",
                right: "16px",
                zIndex: 10,
              }}
              color="var(--neutral-on-surface-tertiary)"
            />

            <div
              style={{
                flex: "1.5",
                padding: "32px",
                display: "flex",
                flexDirection: "column",
                overflowY: "auto",
              }}
            >
              <h2
                style={{
                  margin: "0 0 8px 0",
                  fontSize: "var(--text-headline)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--neutral-on-surface-primary)",
                }}
              >
                Create Purchase Order
              </h2>
              <span
                style={{
                  fontSize: "var(--text-body)",
                  color: "var(--neutral-on-surface-secondary)",
                  marginBottom: "24px",
                }}
              >
                Fill in the details to generate a PO for the outsourced item.
              </span>

              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "16px",
                  flex: 1,
                }}
              >
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: "16px",
                  }}
                >
                  <InputField
                    label="PO Date"
                    type="date"
                    value={createPoForm.poDate}
                    onChange={(e) =>
                      setCreatePoForm({
                        ...createPoForm,
                        poDate: e.target.value,
                      })
                    }
                    required
                  />
                  <InputField
                    label="Expected Delivery Date"
                    type="date"
                    value={createPoForm.deliveryDate}
                    onChange={(e) =>
                      setCreatePoForm({
                        ...createPoForm,
                        deliveryDate: e.target.value,
                      })
                    }
                    required
                  />
                </div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: "16px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "8px",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "2px",
                        fontSize: "var(--text-body)",
                        fontWeight: "var(--font-weight-regular)",
                      }}
                    >
                      <span style={{ color: "var(--status-red-primary)" }}>
                        *
                      </span>
                      <span
                        style={{ color: "var(--neutral-on-surface-primary)" }}
                      >
                        Currency
                      </span>
                    </div>
                    <div style={{ position: "relative", width: "100%" }}>
                      <DropdownSelect
                        value={createPoForm.currency}
                        onChange={(nextValue) =>
                          setCreatePoForm({
                            ...createPoForm,
                            currency: nextValue,
                          })
                        }
                        options={[
                          { value: "IDR", label: "IDR - Indonesian Rupiah" },
                          { value: "USD", label: "USD - US Dollar" },
                        ]}
                      />
                    </div>
                  </div>
                  <InputField
                    label="Unit Price"
                    type="number"
                    placeholder="0"
                    value={createPoForm.unitPrice}
                    onChange={(e) =>
                      setCreatePoForm({
                        ...createPoForm,
                        unitPrice: e.target.value,
                      })
                    }
                    required
                  />
                </div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: "16px",
                  }}
                >
                  <InputField
                    label="Tax (%)"
                    type="number"
                    placeholder="0"
                    value={createPoForm.tax}
                    onChange={(e) =>
                      setCreatePoForm({ ...createPoForm, tax: e.target.value })
                    }
                  />
                  <InputField
                    label="Additional Fees"
                    type="number"
                    placeholder="0"
                    value={createPoForm.fees}
                    onChange={(e) =>
                      setCreatePoForm({ ...createPoForm, fees: e.target.value })
                    }
                  />
                </div>
                <InputField
                  label="Notes"
                  multiline
                  placeholder="Delivery notes..."
                  value={createPoForm.notes}
                  onChange={(e) =>
                    setCreatePoForm({ ...createPoForm, notes: e.target.value })
                  }
                />
                <InputField
                  label="Terms"
                  multiline
                  placeholder="Payment terms..."
                  value={createPoForm.terms}
                  onChange={(e) =>
                    setCreatePoForm({ ...createPoForm, terms: e.target.value })
                  }
                />
              </div>

              <div
                style={{
                  display: "flex",
                  gap: "12px",
                  marginTop: "24px",
                  paddingTop: "24px",
                  borderTop: "1px solid var(--neutral-line-separator-1)",
                }}
              >
                <Button
                  variant="outlined"
                  size="large"
                  style={{ flex: 1 }}
                  onClick={() => setIsCreatePoModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="filled"
                  size="large"
                  style={{ flex: 1 }}
                  onClick={handleSaveNewPo}
                  disabled={
                    !createPoForm.poDate ||
                    !createPoForm.deliveryDate ||
                    !createPoForm.unitPrice
                  }
                >
                  Save Purchase Order
                </Button>
              </div>
            </div>

            <div
              style={{
                flex: "1",
                background: "var(--neutral-surface-grey-lighter)",
                padding: "32px",
                display: "flex",
                flexDirection: "column",
                gap: "20px",
                overflowY: "auto",
                borderLeft: "1px solid var(--neutral-line-separator-1)",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  marginBottom: "8px",
                }}
              >
                <DocumentIcon
                  size={20}
                  color="var(--neutral-on-surface-primary)"
                />
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  {initialData?.wo || "WO-2294824-20251109-00001"}
                </span>
              </div>

              <Card style={{ padding: "16px", gap: "12px", boxShadow: "none" }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    borderBottom: "1px solid var(--neutral-line-separator-1)",
                    paddingBottom: "12px",
                  }}
                >
                  <Building2
                    size={16}
                    color="var(--neutral-on-surface-tertiary)"
                  />
                  <span
                    style={{
                      fontSize: "var(--text-title-3)",
                      fontWeight: "var(--font-weight-bold)",
                    }}
                  >
                    Vendor Information
                  </span>
                </div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "4px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "var(--text-title-2)",
                      fontWeight: "var(--font-weight-bold)",
                      color: "var(--feature-brand-primary)",
                    }}
                  >
                    {singleVendorForm.name}
                  </span>
                  <span
                    style={{
                      fontSize: "var(--text-body)",
                      color: "var(--neutral-on-surface-secondary)",
                    }}
                  >
                    {selectedVendorDetails.email || "-"} •{" "}
                    {selectedVendorDetails.phone || "-"}
                  </span>
                </div>
                <div
                  style={{
                    fontSize: "var(--text-body)",
                    color: "var(--neutral-on-surface-primary)",
                    background: "var(--neutral-surface-grey-lighter)",
                    padding: "8px",
                    borderRadius: "4px",
                  }}
                >
                  {selectedVendorDetails.address || "-"}
                </div>
              </Card>

              <Card style={{ padding: "16px", gap: "12px", boxShadow: "none" }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    borderBottom: "1px solid var(--neutral-line-separator-1)",
                    paddingBottom: "12px",
                  }}
                >
                  <Info size={16} color="var(--neutral-on-surface-tertiary)" />
                  <span
                    style={{
                      fontSize: "var(--text-title-3)",
                      fontWeight: "var(--font-weight-bold)",
                    }}
                  >
                    Order Information
                  </span>
                </div>

                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "16px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "4px",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "var(--text-body)",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      Est. Received Date
                    </span>
                    <span
                      style={{
                        fontSize: "var(--text-title-3)",
                        fontWeight: "var(--font-weight-bold)",
                      }}
                    >
                      {singleVendorForm.date || "No Date Set"}
                    </span>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "4px",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "var(--text-body)",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      Product
                    </span>
                    <span
                      style={{
                        fontSize: "var(--text-title-3)",
                        fontWeight: "var(--font-weight-bold)",
                      }}
                    >
                      {initialData?.product || "Wooden Chair"}
                    </span>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "4px",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "var(--text-body)",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      Assigned Output
                    </span>
                    <span
                      style={{
                        fontSize: "var(--text-title-3)",
                        fontWeight: "var(--font-weight-bold)",
                        color: "var(--feature-brand-primary)",
                      }}
                    >
                      {singleVendorForm.output} pcs
                    </span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      ) : null}

      {isUploadProofModalOpen ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "400px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "24px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => {
                setIsUploadProofModalOpen(false);
                setProofDocuments([]);
                setProofUploadError("");
                setProofDescriptionErrors({});
                setProofAmount("");
                setProofDate("");
                setProofNote("");
              }}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />

            <h2
              style={{
                margin: "0",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              Receive Vendor Output
            </h2>

            <div
              style={{ display: "flex", flexDirection: "column", gap: "16px" }}
            >
              <div
                style={{ display: "flex", flexDirection: "column", gap: "8px" }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "2px",
                    fontSize: "var(--text-body)",
                    fontWeight: "var(--font-weight-regular)",
                  }}
                >
                  <span style={{ color: "var(--status-red-primary)" }}>*</span>
                  <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                    Received Quantity
                  </span>
                </div>
                <InputGroup
                  type="number"
                  value={proofAmount}
                  onChange={(e) => setProofAmount(e.target.value)}
                  placeholder="0"
                  max={
                    (selectedVendorObj?.output || 0) -
                    (selectedVendorObj?.receivedOutput || 0)
                  }
                  suffix="pcs"
                />
                <span
                  style={{
                    fontSize: "var(--text-desc)",
                    color: "var(--neutral-on-surface-secondary)",
                  }}
                >
                  Remaining to receive:{" "}
                  {(selectedVendorObj?.output || 0) -
                    (selectedVendorObj?.receivedOutput || 0)}{" "}
                  pcs
                </span>
              </div>

              <div
                style={{ display: "flex", flexDirection: "column", gap: "8px" }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "2px",
                    fontSize: "var(--text-body)",
                    fontWeight: "var(--font-weight-regular)",
                  }}
                >
                  <span style={{ color: "var(--status-red-primary)" }}>*</span>
                  <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                    Received Date
                  </span>
                </div>
                <DateInputControl
                  value={proofDate}
                  onChange={(e) => setProofDate(e.target.value)}
                />
              </div>

              <div
                style={{ display: "flex", flexDirection: "column", gap: "8px" }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "2px",
                    fontSize: "var(--text-body)",
                    fontWeight: "var(--font-weight-regular)",
                  }}
                >
                  <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                    Notes
                  </span>
                </div>
                <textarea
                  value={proofNote}
                  onChange={(e) => setProofNote(e.target.value)}
                  placeholder="Add note for this receipt"
                  style={{
                    minHeight: "88px",
                    padding: "12px 16px",
                    width: "100%",
                    resize: "vertical",
                    ...inputFrameStyle(false, false),
                    ...inputControlStyle(false, !!proofNote),
                  }}
                  onFocus={(e) => focusInputFrame(e.currentTarget)}
                  onBlur={(e) => blurInputFrame(e.currentTarget, false, false)}
                />
              </div>

              {!isInternalProof ? (
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "2px",
                      fontSize: "var(--text-body)",
                      fontWeight: "var(--font-weight-regular)",
                    }}
                  >
                    <span style={{ color: "var(--status-red-primary)" }}>
                      *
                    </span>
                    <span
                      style={{ color: "var(--neutral-on-surface-primary)" }}
                    >
                      Upload Proof Document
                    </span>
                  </div>
                  <UploadDropzone
                    maxFiles={MAX_PROOF_UPLOAD_FILES}
                    multiple
                    error={proofUploadError}
                    onFilesSelected={handleVendorProofFilesSelected}
                  />
                  {proofDocuments.length > 0 ? (
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "16px",
                      }}
                    >
                      {proofDocuments.map((doc) => (
                        <UploadDescriptionCard
                          key={doc.id}
                          file={doc}
                          descriptionRequired
                          descriptionError={proofDescriptionErrors[doc.id]}
                          onDescriptionChange={(value) =>
                            updateVendorProofDescription(doc.id, value)
                          }
                          onRemove={() => removeVendorProofDocument(doc.id)}
                        />
                      ))}
                    </div>
                  ) : null}
                  {proofUploadError ? (
                    <span
                      style={{
                        fontSize: "var(--text-body)",
                        color: "var(--status-red-primary)",
                      }}
                    >
                      {proofUploadError}
                    </span>
                  ) : null}
                </div>
              ) : null}
            </div>

            <div style={{ display: "flex", gap: "12px", marginTop: "8px" }}>
              <Button
                variant="outlined"
                size="large"
                style={{ flex: 1 }}
                onClick={() => {
                  setIsUploadProofModalOpen(false);
                  setProofDocuments([]);
                  setProofUploadError("");
                  setProofDescriptionErrors({});
                  setProofAmount("");
                  setProofDate("");
                  setProofNote("");
                }}
              >
                Cancel
              </Button>
              <Button
                variant="filled"
                size="large"
                onClick={handleReceiveVendor}
                disabled={
                  isInternalProof
                    ? !proofDate
                    : !proofDate ||
                    proofDocuments.length === 0 ||
                    proofDocuments.some(
                      (doc) => !(doc.description || "").trim()
                    ) ||
                    !proofAmount ||
                    parseInt(proofAmount, 10) <= 0 ||
                    parseInt(proofAmount, 10) >
                    (selectedVendorObj?.output || 0) -
                    (selectedVendorObj?.receivedOutput || 0)
                }
                style={{ flex: 1 }}
              >
                Update
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {isViewReceiptHistoryModalOpen && receiptHistoryVendor ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width:
                receiptHistoryVendor.name === "Internal" ? "520px" : "760px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "24px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <div
              style={{
                position: "relative",
                minHeight: "52px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: "4px",
              }}
            >
              <IconButton
                icon={CloseIcon}
                size="large"
                onClick={() => setIsViewReceiptHistoryModalOpen(false)}
                style={{ position: "absolute", top: "-8px", right: 0 }}
                color="var(--neutral-on-surface-tertiary)"
              />
              <h2
                style={{
                  margin: "0",
                  fontSize: "var(--text-headline)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--neutral-on-surface-primary)",
                  textAlign: "center",
                }}
              >
                Receipt History
              </h2>
              <span
                style={{
                  fontSize: "var(--text-body)",
                  color: "var(--neutral-on-surface-secondary)",
                  textAlign: "center",
                }}
              >
                {receiptHistoryVendor.name}
              </span>
            </div>

            <div style={poReferenceTableFrameStyle}>
              <div
                style={{
                  ...poReferenceTableScrollerStyle,
                  maxHeight: "300px",
                  overflowY: "auto",
                }}
              >
                <div
                  style={poReferenceTableInnerStyle(
                    receiptHistoryVendor.name &&
                      receiptHistoryVendor.name !== "Internal"
                      ? "720px"
                      : "360px"
                  )}
                >
                  <div
                    style={poReferenceTableHeaderRowStyle(
                      receiptHistoryVendor.name &&
                        receiptHistoryVendor.name !== "Internal"
                        ? "1fr 1fr 1.3fr 1.5fr"
                        : "1fr 1fr"
                    )}
                  >
                    <div style={poReferenceTableHeaderCellStyle()}>Date</div>
                    <div style={poReferenceTableHeaderCellStyle()}>
                      Quantity
                    </div>
                    {!receiptHistoryVendor.name ||
                      receiptHistoryVendor.name !== "Internal" ? (
                      <div style={poReferenceTableHeaderCellStyle()}>Note</div>
                    ) : null}
                    {!receiptHistoryVendor.name ||
                      receiptHistoryVendor.name !== "Internal" ? (
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Document
                      </div>
                    ) : null}
                  </div>
                  {receiptHistoryVendor.receipts?.map((r, i) => (
                    <div
                      key={i}
                      style={poReferenceTableRowStyle(
                        receiptHistoryVendor.name &&
                          receiptHistoryVendor.name !== "Internal"
                          ? "1fr 1fr 1.3fr 1.5fr"
                          : "1fr 1fr",
                        i === receiptHistoryVendor.receipts.length - 1
                      )}
                    >
                      <div style={poReferenceTableCellStyle()}>{r.date}</div>
                      <div
                        style={poReferenceTableCellStyle({
                          fontWeight: "var(--font-weight-bold)",
                        })}
                      >
                        {r.amount} pcs
                      </div>
                      {!receiptHistoryVendor.name ||
                        receiptHistoryVendor.name !== "Internal" ? (
                        <div style={poReferenceTableCellStyle()}>
                          {r.note || "-"}
                        </div>
                      ) : null}
                      {!receiptHistoryVendor.name ||
                        receiptHistoryVendor.name !== "Internal" ? (
                        <div
                          style={poReferenceTableCellStyle({
                            alignItems: "flex-start",
                            padding: "12px 0",
                          })}
                        >
                          <ProofDocumentList
                            documents={
                              r.attachments ||
                              r.proofDocuments ||
                              normalizeProofDocuments([], r.attachment)
                            }
                            onDocumentClick={(doc) => {
                              setToastMessage(
                                `${doc?.name || "Document"} opened`
                              );
                              setShowSuccessToast(true);
                            }}
                          />
                        </div>
                      ) : null}
                    </div>
                  ))}
                  {!receiptHistoryVendor.receipts ||
                    receiptHistoryVendor.receipts.length === 0 ? (
                    <div style={poReferenceTableEmptyStateStyle}>
                      No receipts found.
                    </div>
                  ) : null}
                </div>
              </div>
            </div>

            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                marginTop: "8px",
              }}
            >
              <Button
                variant="filled"
                size="medium"
                onClick={() => setIsViewReceiptHistoryModalOpen(false)}
                style={{ width: "100%" }}
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

const PurchaseOrderList = ({ onNavigate, t }) => {
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [sortBy, setSortBy] = useState("createdDate");
  const [sortDirection, setSortDirection] = useState("desc");
  const [openFilterKey, setOpenFilterKey] = useState(null);
  const [filterStatuses, setFilterStatuses] = useState([]);
  const [dateFilterType, setDateFilterType] = useState("all");
  const [customDateRange, setCustomDateRange] = useState({
    start: "",
    end: "",
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [currentPage, setCurrentPage] = useState(1);
  const [viewportHeight, setViewportHeight] = useState(() =>
    typeof window !== "undefined" ? window.innerHeight : 900
  );

  const tableColumns = [
    { label: "PO Number", key: "poNumber", flex: "1.5", sortable: true },
    { label: "Vendor Name", key: "vendorName", flex: "2", sortable: true },
    { label: "Total Amount", key: "amount", flex: "1.5", sortable: false },
    { label: "Created Date", key: "createdDate", flex: "1.2", sortable: true },
    { label: "Status", key: "status", flex: "1.2", sortable: false },
  ];

  const statusCards = [
    { key: "Draft", label: "Draft", activeColor: "grey-light" },
    {
      key: "Waiting for Approval",
      label: "Waiting for Approval",
      activeColor: "orange-light",
    },
    { key: "Issued", label: "Issued", activeColor: "blue-light" },
    { key: "Completed", label: "Completed", activeColor: "green-light" },
    {
      key: "Need Revision",
      label: "Need Revision",
      activeColor: "yellow-light",
    },
    { key: "Canceled", label: "Canceled", activeColor: "red-light" },
  ];

  const statusCounts = statusCards.reduce((acc, card) => {
    acc[card.key] = MOCK_PO_TABLE_DATA.filter(
      (row) => row.status === card.key
    ).length;
    return acc;
  }, {});

  const toggleSort = (key) => {
    if (sortBy === key) {
      setSortDirection((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortBy(key);
      setSortDirection(key === "createdDate" ? "desc" : "asc");
    }
  };

  const toggleFilterStatus = (status) => {
    setFilterStatuses((prev) =>
      prev.includes(status)
        ? prev.filter((s) => s !== status)
        : [...prev, status]
    );
  };

  const parsedDate = (value) => {
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  };

  const now = new Date("2026-03-31");
  const filteredRows = MOCK_PO_TABLE_DATA.filter((row) => {
    const matchesStatusCard =
      selectedStatus === "all" || row.status === selectedStatus;
    const matchesStatusFilter =
      filterStatuses.length === 0 || filterStatuses.includes(row.status);
    const matchesSearch =
      !searchQuery ||
      `${row.poNumber} ${row.vendorName}`
        .toLowerCase()
        .includes(searchQuery.toLowerCase());

    let matchesDate = true;
    const rowDate = parsedDate(row.createdDate);

    if (dateFilterType === "last7" && rowDate) {
      const start = new Date(now);
      start.setDate(now.getDate() - 7);
      matchesDate = rowDate >= start && rowDate <= now;
    } else if (dateFilterType === "last30" && rowDate) {
      const start = new Date(now);
      start.setDate(now.getDate() - 30);
      matchesDate = rowDate >= start && rowDate <= now;
    } else if (
      dateFilterType === "custom" &&
      rowDate &&
      customDateRange.start &&
      customDateRange.end
    ) {
      const start = parsedDate(customDateRange.start);
      const end = parsedDate(customDateRange.end);
      if (start && end) matchesDate = rowDate >= start && rowDate <= end;
    }

    return (
      matchesStatusCard && matchesStatusFilter && matchesSearch && matchesDate
    );
  }).sort((a, b) => {
    const direction = sortDirection === "asc" ? 1 : -1;
    if (sortBy === "createdDate") {
      return (new Date(a.createdDate) - new Date(b.createdDate)) * direction;
    }
    return a[sortBy].localeCompare(b[sortBy]) * direction;
  });

  const totalPages = Math.max(1, Math.ceil(filteredRows.length / rowsPerPage));
  const visibleRows = filteredRows.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );
  const purchaseOrderTableBodyMaxHeight = "calc(100vh - 412px)";
  const purchaseOrderAvailableBodyHeight = Math.max(
    220,
    viewportHeight - 412
  );
  const purchaseOrderVisibleBodyHeight =
    filteredRows.length === 0 ? 160 : visibleRows.length * 56;
  const purchaseOrderShouldScroll =
    purchaseOrderVisibleBodyHeight > purchaseOrderAvailableBodyHeight;

  useEffect(() => {
    setCurrentPage(1);
  }, [
    selectedStatus,
    filterStatuses.join("|"),
    dateFilterType,
    customDateRange.start,
    customDateRange.end,
    searchQuery,
    rowsPerPage,
  ]);

  useEffect(() => {
    setCurrentPage((prev) => Math.min(prev, totalPages));
  }, [totalPages]);

  useEffect(() => {
    if (typeof window === "undefined") return undefined;
    const handleResize = () => setViewportHeight(window.innerHeight);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div
      style={{
        height: "calc(100vh - 64px)",
        padding: "24px",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        gap: "24px",
        overflow: "hidden",
        minHeight: 0,
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <h1
          style={{
            margin: "0",
            fontSize: "var(--text-big-title)",
            fontWeight: "var(--font-weight-bold)",
          }}
        >
          {t("purchase_order.title")}
        </h1>
        <div style={{ display: "flex", gap: "12px" }}>
          <Button
            variant="outlined"
            leftIcon={Settings}
            onClick={() => onNavigate("settings")}
          >
            {t("purchase_order.settings")}
          </Button>
          <Button
            variant="filled"
            leftIcon={AddIcon}
            onClick={() => onNavigate("create")}
          >
            {t("purchase_order.new")}
          </Button>
        </div>
      </div>

      <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
        {statusCards.map((card) => (
          <ListStatusCounterCard
            key={card.key}
            label={card.label}
            count={statusCounts[card.key] || 0}
            badgeVariant={card.activeColor}
            active={selectedStatus === card.key}
            onClick={() =>
              setSelectedStatus((prev) =>
                prev === card.key ? "all" : card.key
              )
            }
          />
        ))}
      </div>

      <div
        style={{
          background: "var(--neutral-surface-primary)",
          borderRadius: "var(--radius-card)",
          border: "1px solid var(--neutral-line-separator-1)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          minHeight: 0,
        }}
      >
        <div
          style={{
            padding: "16px 20px",
            borderBottom: "1px solid var(--neutral-line-separator-2)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "12px",
            flexShrink: 0,
          }}
        >
          <div
            style={{
              display: "flex",
              gap: "12px",
              flexWrap: "wrap",
              position: "relative",
            }}
          >
            <div
              onClick={() =>
                setOpenFilterKey((prev) =>
                  prev === "status" ? null : "status"
                )
              }
            >
              <FilterPill
                label="Status"
                active={filterStatuses.length > 0}
                isOpen={openFilterKey === "status"}
                count={filterStatuses.length}
              />
            </div>
            <div
              onClick={() =>
                setOpenFilterKey((prev) =>
                  prev === "createdDate" ? null : "createdDate"
                )
              }
            >
              <FilterPill
                label="Created Date"
                active={dateFilterType !== "all"}
                isOpen={openFilterKey === "createdDate"}
                count={dateFilterType !== "all" ? 1 : 0}
              />
            </div>

            {openFilterKey ? (
              <>
                <div
                  style={{ position: "fixed", inset: 0, zIndex: 80 }}
                  onClick={() => setOpenFilterKey(null)}
                />
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 8px)",
                    left: openFilterKey === "status" ? 0 : "104px",
                    width: "360px",
                    background: "var(--neutral-surface-primary)",
                    border: "1px solid var(--neutral-line-separator-1)",
                    borderRadius: "var(--radius-card)",
                    boxShadow: "var(--elevation-sm)",
                    padding: "16px",
                    display: "flex",
                    flexDirection: "column",
                    gap: "16px",
                    zIndex: 81,
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "var(--text-title-2)",
                        fontWeight: "var(--font-weight-bold)",
                      }}
                    >
                      {openFilterKey === "status" ? "Status" : "Created Date"}
                    </span>
                    <button
                      onClick={() => {
                        if (openFilterKey === "status") setFilterStatuses([]);
                        if (openFilterKey === "createdDate") {
                          setDateFilterType("all");
                          setCustomDateRange({ start: "", end: "" });
                        }
                      }}
                      style={{
                        background: "none",
                        border: "none",
                        padding: 0,
                        color: "var(--status-red-primary)",
                        cursor: "pointer",
                        fontSize: "var(--text-body)",
                        fontWeight: "var(--font-weight-bold)",
                      }}
                    >
                      Remove Filter
                    </button>
                  </div>

                  {openFilterKey === "status" ? (
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "12px",
                      }}
                    >
                      {statusCards.map((status) => (
                        <label
                          key={status.key}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "12px",
                            cursor: "pointer",
                            fontSize: "var(--text-title-3)",
                          }}
                        >
                          <Checkbox
                            checked={filterStatuses.includes(status.key)}
                            onChange={() => toggleFilterStatus(status.key)}
                          />
                          <span>{status.label}</span>
                        </label>
                      ))}
                    </div>
                  ) : (
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "12px",
                      }}
                    >
                      {[
                        { key: "all", label: "All" },
                        { key: "last7", label: "Last 7 days" },
                        { key: "last30", label: "Last 30 days" },
                        { key: "custom", label: "Custom date" },
                      ].map((opt) => (
                        <label
                          key={opt.key}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "12px",
                            cursor: "pointer",
                            fontSize: "var(--text-title-3)",
                          }}
                        >
                          <input
                            type="radio"
                            checked={dateFilterType === opt.key}
                            onChange={() => setDateFilterType(opt.key)}
                          />
                          <span>{opt.label}</span>
                        </label>
                      ))}

                      {dateFilterType === "custom" ? (
                        <div
                          style={{
                            display: "grid",
                            gridTemplateColumns: "1fr 1fr",
                            gap: "8px",
                          }}
                        >
                          <DateInputControl
                            value={customDateRange.start}
                            onChange={(e) =>
                              setCustomDateRange((prev) => ({
                                ...prev,
                                start: e.target.value,
                              }))
                            }
                            fieldHeight="40px"
                            borderRadius="12px"
                            fontSize="var(--text-title-3)"
                          />
                          <DateInputControl
                            value={customDateRange.end}
                            onChange={(e) =>
                              setCustomDateRange((prev) => ({
                                ...prev,
                                end: e.target.value,
                              }))
                            }
                            fieldHeight="40px"
                            borderRadius="12px"
                            fontSize="var(--text-title-3)"
                          />
                        </div>
                      ) : null}
                    </div>
                  )}
                </div>
              </>
            ) : null}
          </div>

          <TableSearchField
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search PO number, vendor"
            width="360px"
          />
        </div>

        <div
          style={{
            height: purchaseOrderShouldScroll
              ? `${purchaseOrderAvailableBodyHeight}px`
              : "auto",
            maxHeight: purchaseOrderTableBodyMaxHeight,
            overflowX: "auto",
            overflowY: purchaseOrderShouldScroll ? "auto" : "visible",
            width: "100%",
          }}
        >
          <div
            style={{
              minWidth: "1000px",
              width: "100%",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                display: "flex",
                background: "var(--neutral-surface-primary)",
                borderBottom: "1px solid var(--neutral-line-separator-1)",
                position: "sticky",
                top: 0,
                zIndex: 20,
              }}
            >
              {tableColumns.map((col, idx) => (
                <div
                  key={idx}
                  onClick={() =>
                    col.sortable ? toggleSort(col.key) : undefined
                  }
                  style={{
                    flex: col.flex,
                    minWidth: 0,
                    height: "49px",
                    padding: "0 12px",
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                    fontSize: "var(--text-title-3)",
                    fontWeight: "var(--font-weight-bold)",
                    color: "var(--neutral-on-surface-primary)",
                    cursor: col.sortable ? "pointer" : "default",
                  }}
                >
                  <span
                    style={{
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {col.label}
                  </span>
                  {col.sortable ? (
                    <ChevronDownIcon
                      size={14}
                      color={
                        sortBy === col.key
                          ? "var(--feature-brand-primary)"
                          : "var(--neutral-on-surface-tertiary)"
                      }
                      style={{
                        transform:
                          sortBy === col.key && sortDirection === "asc"
                            ? "rotate(180deg)"
                            : "rotate(0deg)",
                        transition: "transform 0.2s",
                      }}
                    />
                  ) : null}
                </div>
              ))}
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                flex: filteredRows.length === 0 ? 1 : "0 0 auto",
              }}
            >
              {visibleRows.map((row, rIdx) => (
                <div
                  key={rIdx}
                  onClick={() => onNavigate("detail", row)}
                  style={{
                    display: "flex",
                    background: "var(--neutral-surface-primary)",
                    borderBottom: "1px solid var(--neutral-line-separator-1)",
                    transition: "background 0.12s ease",
                    cursor: "pointer",
                  }}
                  onMouseEnter={(e) =>
                  (e.currentTarget.style.background =
                    "var(--neutral-surface-grey-lighter)")
                  }
                  onMouseLeave={(e) =>
                  (e.currentTarget.style.background =
                    "var(--neutral-surface-primary)")
                  }
                >
                  <div
                    style={cellStyle({
                      flex: tableColumns[0].flex,
                      color: "var(--feature-brand-primary)",
                    })}
                  >
                    <span
                      style={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {row.poNumber}
                    </span>
                  </div>
                  <div style={cellStyle({ flex: tableColumns[1].flex })}>
                    <span
                      style={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {row.vendorName}
                    </span>
                  </div>
                  <div style={cellStyle({ flex: tableColumns[2].flex })}>
                    {row.amount}
                  </div>
                  <div style={cellStyle({ flex: tableColumns[3].flex })}>
                    <span
                      style={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {row.createdDate}
                    </span>
                  </div>
                  <div style={cellStyle({ flex: tableColumns[4].flex })}>
                    <StatusBadge variant={row.sBadge}>{row.status}</StatusBadge>
                  </div>
                </div>
              ))}

              {filteredRows.length === 0 ? (
                <div
                  style={{
                    flex: 1,
                    padding: "32px",
                    textAlign: "center",
                    color: "var(--neutral-on-surface-tertiary)",
                    fontSize: "var(--text-title-3)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  No purchase orders found.
                </div>
              ) : null}
            </div>
          </div>
        </div>

        <TablePaginationFooter
          totalRows={filteredRows.length}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={setRowsPerPage}
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      </div>
    </div>
  );
};

const PurchaseOrderSettings = ({
  onNavigate,
  isSidebarCollapsed,
  poApprovalSettings,
  onSaveSettings,
}) => {
  const handleBackNavigation = () => {
    onNavigate("list");
  };
  const [isApprovalActive, setIsApprovalActive] = useState(
    poApprovalSettings?.isApprovalActive || false
  );
  const [requireComment, setRequireComment] = useState(
    poApprovalSettings?.requireComment || false
  );
  const [approvers, setApprovers] = useState(
    poApprovalSettings?.approvers || []
  );
  const [approverSearch, setApproverSearch] = useState("");
  const [isApproverDropdownOpen, setIsApproverDropdownOpen] = useState(false);
  const [approverDropdownPos, setApproverDropdownPos] = useState({
    top: 0,
    left: 0,
    width: 320,
  });
  const [showToast, setShowToast] = useState(false);

  const userOptions = [
    {
      id: "u1",
      name: "John Doe",
      email: "john.doe@company.com",
      position: "Product Manager",
    },
    {
      id: "u2",
      name: "Natasha Smith",
      email: "natasha.smith@company.com",
      position: "Owner",
    },
    {
      id: "u3",
      name: "Joko",
      email: "joko@company.com",
      position: "Procurement Lead",
    },
    {
      id: "u4",
      name: "Naomi",
      email: "naomi@company.com",
      position: "Finance Manager",
    },
  ];

  const filteredUsers = userOptions.filter((user) => {
    const q = approverSearch.toLowerCase();
    return (
      !approvers.some((a) => a.id === user.id) &&
      (user.name.toLowerCase().includes(q) ||
        user.email.toLowerCase().includes(q) ||
        user.position.toLowerCase().includes(q))
    );
  });

  const updateApproverDropdownPosition = (el) => {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    setApproverDropdownPos({
      top: rect.bottom + 8,
      left: rect.left,
      width: rect.width,
    });
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "calc(100vh - 64px)",
        position: "relative",
      }}
    >
      {showToast ? (
        <div
          style={{
            position: "absolute",
            top: "24px",
            right: "24px",
            background: "var(--status-green-primary)",
            color: "var(--status-green-on-primary)",
            padding: "12px 16px",
            borderRadius: "var(--radius-small)",
            display: "flex",
            alignItems: "center",
            gap: "12px",
            boxShadow: "var(--elevation-sm)",
            zIndex: 1000,
            minWidth: "320px",
            justifyContent: "space-between",
          }}
        >
          <span style={{ fontSize: "var(--text-title-3)" }}>
            Settings saved successfully
          </span>
          <span
            style={{
              fontWeight: "var(--font-weight-bold)",
              cursor: "pointer",
              fontSize: "var(--text-title-3)",
            }}
            onClick={() => setShowToast(false)}
          >
            Okay
          </span>
        </div>
      ) : null}

      <div
        style={{
          padding: "24px",
          display: "flex",
          flexDirection: "column",
          gap: "24px",
          paddingBottom: "100px",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              cursor: "pointer",
              marginLeft: "-4px",
            }}
            onClick={handleBackNavigation}
          >
            <ChevronLeftIcon
              size={28}
              color="var(--neutral-on-surface-primary)"
            />
            <h1
              style={{
                margin: 0,
                fontSize: "var(--text-large-title)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Settings
            </h1>
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "var(--text-title-3)",
            }}
          >
            <span
              style={{
                color: "var(--neutral-on-surface-secondary)",
                cursor: "pointer",
              }}
              onClick={handleBackNavigation}
            >
              Purchase Order
            </span>
            <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>
              /
            </span>
            <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>
              Settings
            </span>
          </div>
        </div>

        <div
          style={{
            background: "var(--neutral-surface-primary)",
            borderRadius: "16px",
            border: "1px solid var(--neutral-line-separator-1)",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              padding: "16px 0",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <div
                style={{
                  width: "4px",
                  height: "24px",
                  borderRadius: "0 4px 4px 0",
                  background: "var(--feature-brand-primary)",
                }}
              />
              <span
                style={{
                  fontSize: "var(--text-title-1)",
                  fontWeight: "var(--font-weight-bold)",
                }}
              >
                Approval Settings
              </span>
            </div>
            <div style={{ paddingRight: "16px" }}>
              <ChevronDownIcon
                size={20}
                color="var(--neutral-on-surface-secondary)"
              />
            </div>
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "24px",
              padding: "20px 24px 24px 24px",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
                gap: "24px",
              }}
            >
              <div
                style={{ display: "flex", flexDirection: "column", gap: "6px" }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  Activate Approval Setting
                </span>
                <span
                  style={{
                    fontSize: "var(--text-title-3)",
                    color: "var(--neutral-on-surface-secondary)",
                  }}
                >
                  Enable approval workflow for Purchase Order
                </span>
              </div>
              <ToggleSwitch
                checked={isApprovalActive}
                onChange={(next) => {
                  setIsApprovalActive(next);
                  if (!next) {
                    setRequireComment(false);
                    setApprovers([]);
                    setApproverSearch("");
                    setIsApproverDropdownOpen(false);
                  }
                }}
              />
            </div>

            {isApprovalActive ? (
              <>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                    gap: "24px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "6px",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "var(--text-title-2)",
                        color: "var(--neutral-on-surface-primary)",
                      }}
                    >
                      Require Comment for Approval
                    </span>
                    <span
                      style={{
                        fontSize: "var(--text-title-3)",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      Approvers must provide a comment when approving or
                      rejecting
                    </span>
                  </div>
                  <ToggleSwitch
                    checked={requireComment}
                    onChange={(next) => setRequireComment(next)}
                  />
                </div>

                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "12px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "6px",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                      }}
                    >
                      <span
                        style={{
                          color: "var(--status-red-primary)",
                          fontSize: "var(--text-body)",
                        }}
                      >
                        *
                      </span>
                      <span
                        style={{
                          fontSize: "var(--text-title-2)",
                          color: "var(--neutral-on-surface-primary)",
                        }}
                      >
                        Approvers
                      </span>
                    </div>
                    <span
                      style={{
                        fontSize: "var(--text-title-3)",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      Select users who can approve Purchase Orders
                    </span>
                  </div>

                  <div
                    style={{
                      ...poReferenceTableFrameStyle,
                      overflow: "visible",
                    }}
                  >
                    <div style={poReferenceTableScrollerStyle}>
                      <div style={poReferenceTableInnerStyle("760px")}>
                        <div
                          style={poReferenceTableHeaderRowStyle(
                            "1.2fr 1.4fr 1fr 80px"
                          )}
                        >
                          <div style={poReferenceTableHeaderCellStyle()}>
                            Name
                          </div>
                          <div style={poReferenceTableHeaderCellStyle()}>
                            Email
                          </div>
                          <div style={poReferenceTableHeaderCellStyle()}>
                            Position
                          </div>
                          <div
                            style={poReferenceTableHeaderCellStyle({
                              justifyContent: "center",
                            })}
                          >
                            Action
                          </div>
                        </div>

                        {approvers.length > 0
                          ? approvers.map((user, idx) => (
                            <div
                              key={user.id}
                              style={poReferenceTableRowStyle(
                                "1.2fr 1.4fr 1fr 80px",
                                idx === approvers.length - 1
                              )}
                            >
                              <div style={poReferenceTableCellStyle()}>
                                {user.name}
                              </div>
                              <div style={poReferenceTableCellStyle()}>
                                {user.email}
                              </div>
                              <div style={poReferenceTableCellStyle()}>
                                {user.position}
                              </div>
                              <div
                                style={poReferenceTableCellStyle({
                                  justifyContent: "center",
                                })}
                              >
                                <button
                                  onClick={() =>
                                    setApprovers((prev) =>
                                      prev.filter((a) => a.id !== user.id)
                                    )
                                  }
                                  style={{
                                    width: "32px",
                                    height: "32px",
                                    borderRadius: "8px",
                                    background:
                                      "var(--neutral-surface-primary)",
                                    border:
                                      "1px solid var(--neutral-line-separator-1)",
                                    cursor: "pointer",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                  }}
                                >
                                  <DeleteIcon
                                    size={16}
                                    color="var(--status-red-primary)"
                                  />
                                </button>
                              </div>
                            </div>
                          ))
                          : null}
                      </div>
                    </div>

                    <div
                      style={{
                        padding: "16px",
                        borderTop: "1px solid var(--neutral-line-separator-1)",
                        position: "relative",
                      }}
                    >
                      <div style={{ width: "calc((100% - 80px) * 1.2 / 3.6)" }}>
                        <UnifiedInputShell
                          style={{ position: "relative", paddingLeft: "40px" }}
                        >
                          <SearchIcon
                            size={18}
                            color="var(--neutral-on-surface-tertiary)"
                            style={{
                              position: "absolute",
                              left: "14px",
                              top: "50%",
                              transform: "translateY(-50%)",
                            }}
                          />
                          <input
                            value={approverSearch}
                            onFocus={(e) => {
                              updateApproverDropdownPosition(e.currentTarget);
                              setIsApproverDropdownOpen(true);
                            }}
                            onChange={(e) => {
                              setApproverSearch(e.target.value);
                              updateApproverDropdownPosition(e.currentTarget);
                              setIsApproverDropdownOpen(true);
                            }}
                            placeholder="Search by name or position..."
                            style={{
                              flex: 1,
                              height: "100%",
                              width: "100%",
                              border: "none",
                              outline: "none",
                              padding: 0,
                              fontSize: "var(--text-subtitle-1)",
                              color: "var(--neutral-on-surface-primary)",
                              background: "transparent",
                              boxSizing: "border-box",
                            }}
                          />
                        </UnifiedInputShell>
                      </div>

                      {isApproverDropdownOpen ? (
                        <>
                          <div
                            style={{
                              position: "fixed",
                              inset: 0,
                              zIndex: 9998,
                            }}
                            onClick={() => setIsApproverDropdownOpen(false)}
                          />
                          <div
                            style={{
                              position: "fixed",
                              top: `${approverDropdownPos.top}px`,
                              left: `${approverDropdownPos.left}px`,
                              width: `${approverDropdownPos.width}px`,
                              background: "var(--neutral-surface-primary)",
                              border:
                                "1px solid var(--neutral-line-separator-1)",
                              borderRadius: "12px",
                              boxShadow: "var(--elevation-sm)",
                              overflow: "hidden",
                              zIndex: 9999,
                              maxHeight: "260px",
                              overflowY: "auto",
                            }}
                          >
                            {filteredUsers.length > 0 ? (
                              filteredUsers.map((user) => (
                                <div
                                  key={user.id}
                                  onClick={() => {
                                    setApprovers((prev) => [...prev, user]);
                                    setApproverSearch("");
                                    setIsApproverDropdownOpen(false);
                                  }}
                                  onMouseEnter={(e) =>
                                  (e.currentTarget.style.background =
                                    "var(--neutral-surface-grey-lighter)")
                                  }
                                  onMouseLeave={(e) =>
                                  (e.currentTarget.style.background =
                                    "var(--neutral-surface-primary)")
                                  }
                                  style={{
                                    padding: "16px 18px",
                                    cursor: "pointer",
                                    display: "flex",
                                    alignItems: "flex-start",
                                  }}
                                >
                                  <div
                                    style={{
                                      display: "flex",
                                      flexDirection: "column",
                                      gap: "4px",
                                    }}
                                  >
                                    <span
                                      style={{
                                        fontSize: "var(--text-title-3)",
                                        fontWeight: "var(--font-weight-bold)",
                                        color:
                                          "var(--neutral-on-surface-primary)",
                                      }}
                                    >
                                      {user.name}
                                    </span>
                                    <span
                                      style={{
                                        fontSize: "var(--text-body)",
                                        color:
                                          "var(--neutral-on-surface-secondary)",
                                      }}
                                    >
                                      {user.position}
                                    </span>
                                  </div>
                                </div>
                              ))
                            ) : (
                              <div
                                style={{
                                  padding: "12px 14px",
                                  fontSize: "var(--text-title-3)",
                                  color: "var(--neutral-on-surface-tertiary)",
                                }}
                              >
                                No user found.
                              </div>
                            )}
                          </div>
                        </>
                      ) : null}
                    </div>
                  </div>
                </div>
              </>
            ) : null}
          </div>
        </div>
      </div>

      <div
        style={{
          position: "fixed",
          bottom: 0,
          left: isSidebarCollapsed ? "82px" : "286px",
          right: 0,
          transition: "left 0.2s ease",
          background: "var(--neutral-surface-primary)",
          borderTop: "1px solid var(--neutral-line-separator-1)",
          padding: "12px 24px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          zIndex: 100,
        }}
      >
        <Button
          size="medium"
          variant="ghost"
          onClick={handleBackNavigation}
          style={{ color: "var(--status-red-primary)" }}
        >
          Cancel
        </Button>
        <Button
          size="medium"
          variant="filled"
          disabled={isApprovalActive && approvers.length === 0}
          onClick={() => {
            onSaveSettings?.({ isApprovalActive, requireComment, approvers });
            setShowToast(true);
          }}
        >
          Save
        </Button>
      </div>
    </div>
  );
};

const administrationTabRowStyle = (isActive) => ({
  height: "46px",
  padding: "0 20px",
  border: "none",
  borderBottom: isActive
    ? "2px solid var(--feature-brand-primary)"
    : "2px solid var(--neutral-line-separator-2)",
  background: "transparent",
  color: isActive
    ? "var(--feature-brand-primary)"
    : "var(--neutral-on-surface-secondary)",
  fontSize: "var(--text-title-2)",
  fontWeight: isActive
    ? "var(--font-weight-bold)"
    : "var(--font-weight-regular)",
  cursor: "pointer",
});

const ADMIN_PERMISSION_ACCESS_OPTIONS = [
  { value: "no_access", label: "No Access" },
  { value: "view_only", label: "View Only" },
  { value: "edit", label: "Edit (Create + Edit)" },
  {
    value: "full_access",
    label: "Full Access (Create + Update + Delete)",
  },
];

const ADMIN_PERMISSION_ACCESS_LABELS = {
  no_access: "No Access",
  view_only: "View Only",
  edit: "Edit",
  full_access: "Full Access",
};

const ADMIN_PERMISSION_TREE = [
  { key: "dashboard", label: "Dashboard" },
  {
    key: "products",
    label: "Products",
    children: [
      { key: "product_catalog", label: "Product Catalog" },
      { key: "product_category", label: "Product Category" },
      {
        key: "custom_product_request",
        label: "Custom Product Request",
        approvable: true,
      },
    ],
  },
  {
    key: "sales",
    label: "Sales",
    children: [
      {
        key: "request_for_quotes",
        label: "Request for Quotes",
        approvable: true,
      },
      { key: "quotes", label: "Quotes" },
      { key: "orders", label: "Orders" },
      { key: "invoices", label: "Invoices" },
      { key: "customers", label: "Customers" },
      { key: "shipment", label: "Shipment" },
      { key: "approval_setting", label: "Approval Setting" },
    ],
  },
  {
    key: "inventory",
    label: "Inventory",
    children: [
      { key: "materials", label: "Materials" },
      { key: "material_category", label: "Material Category" },
      { key: "material_uom", label: "Material UOM" },
      { key: "batches", label: "Batches" },
      { key: "stock_transaction", label: "Stock Transaction" },
      { key: "vendors", label: "Vendors" },
      { key: "material_preparation", label: "Material Preparation" },
      { key: "material_receipt", label: "Material Receipt" },
    ],
  },
  {
    key: "manufacturing",
    label: "Manufacturing",
    children: [
      { key: "bill_of_materials", label: "Bill of Materials" },
      { key: "routings", label: "Routings" },
      { key: "work_orders", label: "Work Orders", approvable: true },
      { key: "material_requests", label: "Material Requests" },
      { key: "purchase_order", label: "Purchase Order", approvable: true },
    ],
  },
  {
    key: "analytics_reports",
    label: "Analytics & Reports",
    children: [
      { key: "sales_report", label: "Sales Report" },
      { key: "finance_report", label: "Finance Report" },
      { key: "order_report", label: "Order Report" },
      { key: "inventory_report", label: "Inventory Report" },
      { key: "work_order_monitoring", label: "Work Order Monitoring" },
    ],
  },
  {
    key: "administration",
    label: "Administration",
    children: [
      { key: "user_management", label: "User Management" },
      { key: "fx_management", label: "FX Management" },
      { key: "company_settings", label: "Company Settings" },
      { key: "notification_settings", label: "Notification Settings" },
    ],
  },
  {
    key: "help",
    label: "Help",
    children: [{ key: "user_guide", label: "User Guide" }],
  },
];

function flattenAdminPermissionNodes(nodes, parentKey = null) {
  return nodes.flatMap((node) => [
    { ...node, parentKey },
    ...(node.children
      ? flattenAdminPermissionNodes(node.children, node.key)
      : []),
  ]);
}

const ADMIN_PERMISSION_NODES = flattenAdminPermissionNodes(ADMIN_PERMISSION_TREE);
const ADMIN_PERMISSION_NODE_MAP = ADMIN_PERMISSION_NODES.reduce(
  (accumulator, node) => {
    accumulator[node.key] = node;
    return accumulator;
  },
  {}
);
const ADMIN_PERMISSION_LEAF_NODES = ADMIN_PERMISSION_NODES.filter(
  (node) => !node.children?.length
);
const ADMIN_PERMISSION_EXPANDABLE_KEYS = ADMIN_PERMISSION_TREE.filter(
  (node) => node.children?.length
).map((node) => node.key);
const ADMIN_PERMISSION_DESCENDANT_KEYS = ADMIN_PERMISSION_TREE.reduce(
  (accumulator, node) => {
    accumulator[node.key] = node.children
      ? flattenAdminPermissionNodes(node.children).map((child) => child.key)
      : [];
    return accumulator;
  },
  {}
);

const createAdminPermissionState = (defaultLevel = "no_access") =>
  ADMIN_PERMISSION_NODES.reduce((accumulator, node) => {
    accumulator[node.key] = {
      level: defaultLevel,
      canApprove: false,
    };
    return accumulator;
  }, {});

const cloneAdminPermissionState = (permissions = {}) => {
  const nextState = createAdminPermissionState();

  ADMIN_PERMISSION_NODES.forEach((node) => {
    const nextLevel = permissions?.[node.key]?.level || "no_access";
    nextState[node.key] = {
      level: nextLevel,
      canApprove:
        !!node.approvable &&
        nextLevel !== "no_access" &&
        Boolean(permissions?.[node.key]?.canApprove),
    };
  });

  return nextState;
};

const assignAdminPermissionLevel = (state, keys, level, canApprove = false) => {
  keys.forEach((key) => {
    if (!state[key]) return;
    state[key].level = level;
    if (ADMIN_PERMISSION_NODE_MAP[key]?.approvable) {
      state[key].canApprove = level !== "no_access" && canApprove;
    }
  });
};

const ADMIN_PERMISSION_GROUP_KEYS = {
  products: ["products", "product_catalog", "product_category", "custom_product_request"],
  sales: [
    "sales",
    "request_for_quotes",
    "quotes",
    "orders",
    "invoices",
    "customers",
    "shipment",
    "approval_setting",
  ],
  inventory: [
    "inventory",
    "materials",
    "material_category",
    "material_uom",
    "batches",
    "stock_transaction",
    "vendors",
    "material_preparation",
    "material_receipt",
  ],
  manufacturing: [
    "manufacturing",
    "bill_of_materials",
    "routings",
    "work_orders",
    "material_requests",
    "purchase_order",
  ],
  analytics_reports: [
    "analytics_reports",
    "sales_report",
    "finance_report",
    "order_report",
    "inventory_report",
    "work_order_monitoring",
  ],
  administration: [
    "administration",
    "user_management",
    "fx_management",
    "company_settings",
    "notification_settings",
  ],
  help: ["help", "user_guide"],
};

const buildAdminRolePermissions = (role) => {
  const permissions = createAdminPermissionState();
  const roleName = role?.name;

  if (role?.permissions) {
    return cloneAdminPermissionState(role.permissions);
  }

  if (roleName === "Owner" || role?.scope === "Full Access") {
    assignAdminPermissionLevel(
      permissions,
      ADMIN_PERMISSION_NODES.map((node) => node.key),
      "full_access",
      true
    );
    return permissions;
  }

  if (roleName === "Procurement Admin") {
    assignAdminPermissionLevel(permissions, ["dashboard"], "view_only");
    assignAdminPermissionLevel(
      permissions,
      ADMIN_PERMISSION_GROUP_KEYS.inventory,
      "edit"
    );
    assignAdminPermissionLevel(
      permissions,
      ADMIN_PERMISSION_GROUP_KEYS.manufacturing,
      "edit"
    );
    assignAdminPermissionLevel(permissions, ["work_orders"], "view_only", false);
    assignAdminPermissionLevel(permissions, ["purchase_order"], "full_access");
    assignAdminPermissionLevel(permissions, ["material_requests"], "edit");
    assignAdminPermissionLevel(permissions, ["vendors"], "edit");
    assignAdminPermissionLevel(permissions, ["material_receipt"], "edit");
    assignAdminPermissionLevel(permissions, ADMIN_PERMISSION_GROUP_KEYS.help, "view_only");
    return permissions;
  }

  if (roleName === "Finance Manager") {
    assignAdminPermissionLevel(permissions, ["dashboard"], "view_only");
    assignAdminPermissionLevel(
      permissions,
      ["purchase_order", "finance_report", "order_report", "company_settings"],
      "full_access",
      true
    );
    assignAdminPermissionLevel(
      permissions,
      ["manufacturing", "analytics_reports", "administration", "notification_settings"],
      "view_only"
    );
    assignAdminPermissionLevel(
      permissions,
      ["sales_report", "inventory_report", "work_order_monitoring"],
      "view_only"
    );
    assignAdminPermissionLevel(permissions, ADMIN_PERMISSION_GROUP_KEYS.help, "view_only");
    return permissions;
  }

  if (roleName === "Production Planner") {
    assignAdminPermissionLevel(permissions, ["dashboard"], "view_only");
    assignAdminPermissionLevel(
      permissions,
      ADMIN_PERMISSION_GROUP_KEYS.manufacturing,
      "full_access"
    );
    assignAdminPermissionLevel(permissions, ["work_orders"], "full_access", true);
    assignAdminPermissionLevel(
      permissions,
      ["inventory", "materials", "material_preparation", "material_receipt", "vendors"],
      "view_only"
    );
    assignAdminPermissionLevel(
      permissions,
      ["analytics_reports", "work_order_monitoring", "inventory_report"],
      "view_only"
    );
    assignAdminPermissionLevel(permissions, ADMIN_PERMISSION_GROUP_KEYS.help, "view_only");
    return permissions;
  }

  if (roleName === "Sales Coordinator") {
    assignAdminPermissionLevel(permissions, ["dashboard"], "view_only");
    assignAdminPermissionLevel(
      permissions,
      ADMIN_PERMISSION_GROUP_KEYS.products,
      "view_only"
    );
    assignAdminPermissionLevel(
      permissions,
      ADMIN_PERMISSION_GROUP_KEYS.sales,
      "edit"
    );
    assignAdminPermissionLevel(
      permissions,
      ["request_for_quotes", "quotes", "orders", "customers", "shipment"],
      "full_access",
      true
    );
    assignAdminPermissionLevel(permissions, ["invoices", "approval_setting"], "view_only");
    assignAdminPermissionLevel(permissions, ["sales_report"], "view_only");
    assignAdminPermissionLevel(permissions, ADMIN_PERMISSION_GROUP_KEYS.help, "view_only");
    return permissions;
  }

  return permissions;
};

const seedAdminRoles = (roles = []) =>
  roles.map((role) => ({
    ...role,
    permissions: buildAdminRolePermissions(role),
  }));

const adminManagementTableHeaderRowStyle = (gridTemplateColumns) => ({
  display: "grid",
  gridTemplateColumns,
  columnGap: "16px",
  padding: "12px 20px",
  minHeight: "unset",
  alignItems: "center",
  background: "var(--neutral-surface-primary)",
  borderBottom: "1px solid var(--neutral-line-separator-1)",
  fontSize: "var(--text-title-3)",
  fontWeight: "var(--font-weight-bold)",
  color: "var(--neutral-on-surface-primary)",
  boxSizing: "border-box",
});

const adminManagementTableRowStyle = (
  gridTemplateColumns,
  isLast = false,
  overrides = {}
) => ({
  display: "grid",
  gridTemplateColumns,
  columnGap: "16px",
  padding: "12px 20px",
  minHeight: "unset",
  alignItems: "center",
  background: "var(--neutral-surface-primary)",
  borderBottom: isLast ? "none" : "1px solid var(--neutral-line-separator-1)",
  boxSizing: "border-box",
  ...overrides,
});

const adminManagementTableCellStyle = (overrides = {}) => ({
  minWidth: 0,
  display: "flex",
  alignItems: "center",
  fontSize: "var(--text-title-3)",
  color: "var(--neutral-on-surface-primary)",
  ...overrides,
});

const resolveAdminRoleAccess = (roleName, roles = []) => {
  const matchedRole = roles.find((role) => role.name === roleName);
  if (!matchedRole?.permissions) return [];

  return ADMIN_PERMISSION_LEAF_NODES.reduce((entries, node) => {
    const permission = matchedRole.permissions[node.key];
    if (!permission || permission.level === "no_access") return entries;
    entries.push(
      `${node.label} -> ${ADMIN_PERMISSION_ACCESS_LABELS[permission.level]}${
        node.approvable && permission.canApprove ? " (Can Approve)" : ""
      }`
    );
    return entries;
  }, []);
};

const buildRolePermissionDiff = (currentRole, nextRole, roles = []) => {
  const currentAccess = resolveAdminRoleAccess(currentRole, roles);
  const nextAccess = resolveAdminRoleAccess(nextRole, roles);

  return {
    losing: currentAccess.filter((item) => !nextAccess.includes(item)),
    gaining: nextAccess.filter((item) => !currentAccess.includes(item)),
  };
};

const AdministrationUserManagement = ({ isSidebarCollapsed }) => {
  const [activeTab, setActiveTab] = useState("users");
  const [users, setUsers] = useState(MOCK_ADMIN_USERS);
  const [roles, setRoles] = useState(() => seedAdminRoles(MOCK_ADMIN_ROLES));
  const [groups, setGroups] = useState(MOCK_ADMIN_GROUPS);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [currentPageByTab, setCurrentPageByTab] = useState({
    users: 1,
    roles: 1,
    groups: 1,
  });
  const [tableSearchByTab, setTableSearchByTab] = useState({
    users: "",
    roles: "",
    groups: "",
  });
  const [tableFiltersByTab, setTableFiltersByTab] = useState({
    users: {
      role: "all",
      group: "all",
      status: "all",
    },
    roles: {
      status: "all",
    },
    groups: {
      role: "all",
    },
  });
  const [pendingUserEdits, setPendingUserEdits] = useState({});
  const [userChangesModal, setUserChangesModal] = useState(null);
  const [roleChangesExpanded, setRoleChangesExpanded] = useState(false);
  const [teamChangesExpanded, setTeamChangesExpanded] = useState(false);
  const [roleDrawerState, setRoleDrawerState] = useState({
    open: false,
    mode: "create",
    id: null,
    originalName: "",
    name: "",
    description: "",
    permissions: createAdminPermissionState(),
  });
  const [roleDrawerErrors, setRoleDrawerErrors] = useState({});
  const [expandedRolePermissionKeys, setExpandedRolePermissionKeys] = useState(
    ADMIN_PERMISSION_EXPANDABLE_KEYS
  );
  const [deleteConfirmation, setDeleteConfirmation] = useState({ open: false, type: null, data: null });
  const [adminSnackbar, setAdminSnackbar] = useState({ open: false, message: "" });
  const [hoveredRoleMenuItem, setHoveredRoleMenuItem] = useState(null);
  const [hoveredGroupMenuItem, setHoveredGroupMenuItem] = useState(null);
  const [isHoveredConfirmDelete, setIsHoveredConfirmDelete] = useState(false);

  const [openRoleActionMenuId, setOpenRoleActionMenuId] = useState(null);
  const [roleActionMenuPosition, setRoleActionMenuPosition] = useState({
    top: 0,
    left: 0,
  });
  const [groupModalState, setGroupModalState] = useState({
    open: false,
    mode: "create",
    id: null,
    name: "",
    description: "",
    members: [],
    allowedRoles: [],
  });
  const [groupModalErrors, setGroupModalErrors] = useState({});
  const [openGroupActionMenuId, setOpenGroupActionMenuId] = useState(null);
  const [groupActionMenuPosition, setGroupActionMenuPosition] = useState({
    top: 0,
    left: 0,
  });

  const showAdminSnackbar = (message) => {
    setAdminSnackbar({ open: true, message });
    setTimeout(() => setAdminSnackbar({ open: false, message: "" }), 3000);
  };

  const rolePermissionTableColumns = "minmax(0, 1.2fr) 248px 132px";

  const displayedUsers = users.map((user) => {
    const combined = { ...user, ...(pendingUserEdits[user.id] || {}) };
    const roleExists = roles.some((r) => r.name === combined.role);
    const groupExists = groups.some((g) => g.name === combined.group);
    
    return {
      ...combined,
      role: roleExists ? combined.role : "Unassigned",
      group: groupExists ? combined.group : "Unassigned",
    };
  });
  const roleOptions = roles.map((role) => ({ value: role.name, label: role.name }));
  const assignableRoleOptions = [
    { value: "Unassigned", label: "Unassigned" },
    ...roleOptions,
  ];
  const groupOptions = [
    { value: "Unassigned", label: "Unassigned" },
    ...groups.map((group) => ({ value: group.name, label: group.name })),
  ];
  const userOptions = users.map((user) => ({ 
    value: user.name, 
    label: user.name,
    email: user.email 
  }));

  const syncUsersFromGroups = (nextGroups, baseUsers) =>
    baseUsers.map((user) => {
      const matchedGroup = nextGroups.find((group) =>
        group.members.includes(user.name)
      );
      return {
        ...user,
        group: matchedGroup ? matchedGroup.name : "Unassigned",
      };
    });

  const applyRowsPerPage = (nextRowsPerPage) => {
    setRowsPerPage(nextRowsPerPage);
    setCurrentPageByTab({
      users: 1,
      roles: 1,
      groups: 1,
    });
  };

  const updateTabPage = (tabId, nextPage) => {
    setCurrentPageByTab((prev) => ({ ...prev, [tabId]: nextPage }));
  };

  const paginateRows = (rows, tabId) => {
    const totalRows = rows.length;
    const totalPages = Math.max(1, Math.ceil(totalRows / rowsPerPage));
    const currentPage = Math.min(currentPageByTab[tabId] || 1, totalPages);
    const startIndex = (currentPage - 1) * rowsPerPage;

    return {
      rows: rows.slice(startIndex, startIndex + rowsPerPage),
      totalRows,
      totalPages,
      currentPage,
    };
  };



  const showRoleToast = (message) => {
    showAdminSnackbar(message);
  };

  const updateTableSearch = (tabId, nextValue) => {
    setTableSearchByTab((prev) => ({ ...prev, [tabId]: nextValue }));
  };

  const updateTableFilter = (tabId, filterKey, nextValue) => {
    setTableFiltersByTab((prev) => ({
      ...prev,
      [tabId]: {
        ...prev[tabId],
        [filterKey]: nextValue,
      },
    }));
    setCurrentPageByTab((prev) => ({ ...prev, [tabId]: 1 }));
  };

  const createEmptyRoleDrawerState = () => ({
    open: false,
    mode: "create",
    id: null,
    originalName: "",
    name: "",
    description: "",
    permissions: createAdminPermissionState(),
  });

  const closeRoleDrawer = () => {
    setRoleDrawerErrors({});
    setOpenRoleActionMenuId(null);
    setRoleDrawerState(createEmptyRoleDrawerState());
  };

  const openCreateRoleDrawer = () => {
    setRoleDrawerErrors({});
    setRoleDrawerState({
      open: true,
      mode: "create",
      id: null,
      originalName: "",
      name: "",
      description: "",
      permissions: createAdminPermissionState(),
    });
    setExpandedRolePermissionKeys(ADMIN_PERMISSION_EXPANDABLE_KEYS);
  };

  const openEditRoleDrawer = (role) => {
    setRoleDrawerErrors({});
    setOpenRoleActionMenuId(null);
    setRoleDrawerState({
      open: true,
      mode: "edit",
      id: role.id,
      originalName: role.name,
      name: role.name,
      description: role.description,
      permissions: cloneAdminPermissionState(role.permissions),
    });
    setExpandedRolePermissionKeys(ADMIN_PERMISSION_EXPANDABLE_KEYS);
  };

  const updateRolePermissionLevel = (key, nextLevel) => {
    setRoleDrawerState((prev) => {
      const nextPermissions = cloneAdminPermissionState(prev.permissions);
      const targetKeys = [key, ...(ADMIN_PERMISSION_DESCENDANT_KEYS[key] || [])];

      targetKeys.forEach((targetKey) => {
        nextPermissions[targetKey].level = nextLevel;
        if (
          ADMIN_PERMISSION_NODE_MAP[targetKey]?.approvable &&
          nextLevel === "no_access"
        ) {
          nextPermissions[targetKey].canApprove = false;
        }
      });

      let ancestorKey = ADMIN_PERMISSION_NODE_MAP[key]?.parentKey;
      while (ancestorKey) {
        const directChildLevels = (
          ADMIN_PERMISSION_NODE_MAP[ancestorKey]?.children || []
        ).map((childNode) => nextPermissions[childNode.key]?.level || "no_access");
        const hasUniformLevel = directChildLevels.every(
          (level) => level === directChildLevels[0]
        );
        const sortedLevels = ["no_access", "view_only", "edit", "full_access"];
        const aggregateLevel = hasUniformLevel
          ? directChildLevels[0]
          : [...directChildLevels].sort(
              (left, right) =>
                sortedLevels.indexOf(right) - sortedLevels.indexOf(left)
            )[0];

        nextPermissions[ancestorKey].level = aggregateLevel;
        ancestorKey = ADMIN_PERMISSION_NODE_MAP[ancestorKey]?.parentKey;
      }

      return {
        ...prev,
        permissions: nextPermissions,
      };
    });
  };

  const updateRolePermissionApprove = (key, checked) => {
    setRoleDrawerState((prev) => ({
      ...prev,
      permissions: {
        ...prev.permissions,
        [key]: {
          ...prev.permissions[key],
          canApprove:
            prev.permissions[key]?.level !== "no_access" && Boolean(checked),
        },
      },
    }));
  };

  const toggleRolePermissionGroup = (key) => {
    setExpandedRolePermissionKeys((prev) =>
      prev.includes(key)
        ? prev.filter((item) => item !== key)
        : [...prev, key]
    );
  };

  const getRolePermissionSummary = (permissions) => {
    const counts = ADMIN_PERMISSION_LEAF_NODES.reduce(
      (accumulator, node) => {
        const level = permissions?.[node.key]?.level || "no_access";
        accumulator[level] += 1;
        return accumulator;
      },
      {
        full_access: 0,
        edit: 0,
        view_only: 0,
        no_access: 0,
      }
    );

    if (counts.full_access === ADMIN_PERMISSION_LEAF_NODES.length) {
      return [{ key: "all-full", text: "All Features (Full Access)" }];
    }

    if (counts.view_only === ADMIN_PERMISSION_LEAF_NODES.length) {
      return [{ key: "all-view", text: "All Features (View Only)" }];
    }

    return ["full_access", "edit", "view_only", "no_access"]
      .filter((level) => counts[level] > 0)
      .map((level) => ({
        key: level,
        text: `${counts[level]} Features (${ADMIN_PERMISSION_ACCESS_LABELS[level]})`,
      }));
  };

  const saveRoleDrawer = () => {
    const trimmedName = roleDrawerState.name.trim();
    const trimmedDescription = roleDrawerState.description.trim();
    const nextErrors = {};

    if (!trimmedName) nextErrors.name = "Role name is required";
    if (
      roles.some(
        (role) =>
          role.id !== roleDrawerState.id &&
          role.name.toLowerCase() === trimmedName.toLowerCase()
      )
    ) {
      nextErrors.name = "Role name already exists";
    }

    if (Object.keys(nextErrors).length > 0) {
      setRoleDrawerErrors(nextErrors);
      return;
    }

    if (roleDrawerState.mode === "edit") {
      setRoles((prev) =>
        prev.map((role) =>
          role.id === roleDrawerState.id
            ? {
                ...role,
                name: trimmedName,
                description:
                  trimmedDescription || "Updated role for access configuration.",
                permissions: cloneAdminPermissionState(roleDrawerState.permissions),
              }
            : role
        )
      );

      if (trimmedName !== roleDrawerState.originalName) {
        setUsers((prev) =>
          prev.map((user) =>
            user.role === roleDrawerState.originalName
              ? { ...user, role: trimmedName }
              : user
          )
        );
        setGroups((prev) =>
          prev.map((group) => ({
            ...group,
            allowedRoles: group.allowedRoles.map((roleName) =>
              roleName === roleDrawerState.originalName ? trimmedName : roleName
            ),
          }))
        );
      }
    } else {
      setRoles((prev) => [
        ...prev,
        {
          id: `role-${Date.now()}`,
          name: trimmedName,
          description:
            trimmedDescription || "New role for access configuration.",
          status: "Active",
          permissions: cloneAdminPermissionState(roleDrawerState.permissions),
        },
      ]);
    }

    showRoleToast(
      roleDrawerState.mode === "edit"
        ? "Role updated successfully"
        : "Role created successfully"
    );
    closeRoleDrawer();
  };

  const updatePendingUserEdit = (userId, patch) => {
    const baseUser = users.find((user) => user.id === userId);
    if (!baseUser) return;

    setPendingUserEdits((prev) => {
      const currentDraft = prev[userId] || {
        role: baseUser.role,
        group: baseUser.group,
      };
      const nextDraft = { ...currentDraft, ...patch };

      if (
        nextDraft.role === baseUser.role &&
        nextDraft.group === baseUser.group
      ) {
        const { [userId]: _removed, ...rest } = prev;
        return rest;
      }

      return {
        ...prev,
        [userId]: nextDraft,
      };
    });
  };

  const buildGroupsFromUsers = (nextUsers, baseGroups) =>
    baseGroups.map((group) => ({
      ...group,
      members: nextUsers
        .filter((user) => user.group === group.name)
        .map((user) => user.name),
    }));

  const openUserChangesModal = () => {
    const changes = users
      .filter((user) => pendingUserEdits[user.id])
      .map((user) => {
        const draft = pendingUserEdits[user.id];
        const nextRole = draft.role !== undefined ? draft.role : user.role;
        const nextGroup = draft.group !== undefined ? draft.group : user.group;
        const roleChanged = nextRole !== user.role;
        const groupChanged = nextGroup !== user.group;
        const roleDiff =
          roleChanged
            ? buildRolePermissionDiff(user.role, nextRole, roles)
            : { losing: [], gaining: [] };

        // Determine risk note: flag when gaining critical permissions (new role is not unassigned/dash)
        let riskNote = null;
        if (roleChanged && nextRole && nextRole !== "-") {
          if (roleDiff.gaining.length > 0) {
            riskNote = `Grants ${roleDiff.gaining.slice(0, 2).join(", ")}${roleDiff.gaining.length > 2 ? " and more" : ""} access`;
          } else if (roleDiff.losing.length > 0) {
            riskNote = `Removes ${roleDiff.losing.slice(0, 2).join(", ")}${roleDiff.losing.length > 2 ? " and more" : ""} permissions`;
          }
        }

        return {
          userId: user.id,
          userName: user.name,
          currentRole: user.role,
          nextRole,
          currentGroup: user.group,
          nextGroup,
          roleChanged,
          groupChanged,
          losing: roleDiff.losing,
          gaining: roleDiff.gaining,
          riskNote,
        };
      });

    if (changes.length === 0) return;
    setRoleChangesExpanded(false);
    setTeamChangesExpanded(false);
    setUserChangesModal({ changes });
  };

  const confirmUserChanges = () => {
    if (!userChangesModal) return;

    const nextUsers = users.map((user) =>
      pendingUserEdits[user.id]
        ? { ...user, ...pendingUserEdits[user.id] }
        : user
    );
    const nextGroups = buildGroupsFromUsers(nextUsers, groups);

    setUsers(nextUsers);
    setGroups(nextGroups);
    setPendingUserEdits({});
    setUserChangesModal(null);
    showRoleToast("User access updated successfully");
  };



  const confirmDeleteRole = (role) => {
    setRoles((prev) => prev.filter((item) => item.id !== role.id));
    setUsers((prev) =>
      prev.map((user) =>
        user.role === role.name ? { ...user, role: "-" } : user
      )
    );
    setGroups((prev) =>
      prev.map((group) => ({
        ...group,
        allowedRoles: group.allowedRoles.filter(
          (roleName) => roleName !== role.name
        ),
      }))
    );
    setDeleteConfirmation({ open: false, type: null, data: null });
    showAdminSnackbar(`${role.name} role successfully deleted`);
  };

  const handleDeleteRole = (role) => {
    setDeleteConfirmation({ open: true, type: "role", data: role });
  };

  const openCreateGroupModal = () => {
    setGroupModalErrors({});
    setGroupModalState({
      open: true,
      mode: "create",
      id: null,
      name: "",
      description: "",
      members: [],
      allowedRoles: [],
    });
  };

  const openEditGroupModal = (group) => {
    setGroupModalErrors({});
    setGroupModalState({
      open: true,
      mode: "edit",
      id: group.id,
      name: group.name,
      description: group.description,
      members: [...group.members],
      allowedRoles: [...group.allowedRoles],
    });
  };

  const closeGroupModal = () => {
    setGroupModalErrors({});
    setGroupModalState({
      open: false,
      mode: "create",
      id: null,
      name: "",
      description: "",
      members: [],
      allowedRoles: [],
    });
  };

  const saveGroupModal = () => {
    const trimmedName = groupModalState.name.trim();
    const trimmedDescription = groupModalState.description.trim();
    const nextErrors = {};

    if (!trimmedName) nextErrors.name = "Group name is required";
    if (
      groups.some(
        (group) =>
          group.id !== groupModalState.id &&
          group.name.toLowerCase() === trimmedName.toLowerCase()
      )
    ) {
      nextErrors.name = "Group name already exists";
    }

    if (Object.keys(nextErrors).length > 0) {
      setGroupModalErrors(nextErrors);
      return;
    }

    let nextGroups;
    if (groupModalState.mode === "edit") {
      nextGroups = groups.map((group) =>
        group.id === groupModalState.id
          ? {
              ...group,
              name: trimmedName,
              description:
                trimmedDescription ||
                "Updated group for shared role assignment.",
              members: [...groupModalState.members],
              allowedRoles: [...groupModalState.allowedRoles],
            }
          : group
      );
    } else {
      nextGroups = [
        ...groups,
        {
          id: `group-${Date.now()}`,
          name: trimmedName,
          description:
            trimmedDescription || "New group for shared role assignment.",
          members: [...groupModalState.members],
          allowedRoles: [...groupModalState.allowedRoles],
        },
      ];
    }

    setGroups(nextGroups);
    setUsers(syncUsersFromGroups(nextGroups, users));
    closeGroupModal();
  };

  const confirmDeleteGroup = (group) => {
    const nextGroups = groups.filter((item) => item.id !== group.id);
    setGroups(nextGroups);
    setUsers(syncUsersFromGroups(nextGroups, users));
    setDeleteConfirmation({ open: false, type: null, data: null });
    showAdminSnackbar(`${group.name} team successfully deleted`);
  };

  const handleDeleteGroup = (group) => {
    setDeleteConfirmation({ open: true, type: "team", data: group });
    setOpenGroupActionMenuId(null);
  };

  const hasPendingUserChanges = Object.keys(pendingUserEdits).length > 0;
  const userSearch = tableSearchByTab.users.trim().toLowerCase();
  const roleSearch = tableSearchByTab.roles.trim().toLowerCase();
  const groupSearch = tableSearchByTab.groups.trim().toLowerCase();

  const filteredUsers = displayedUsers.filter((user) => {
    const matchesSearch =
      !userSearch ||
      `${user.name} ${user.email} ${user.role} ${user.group} ${user.status}`
        .toLowerCase()
        .includes(userSearch);
    const matchesRole =
      tableFiltersByTab.users.role === "all" ||
      user.role === tableFiltersByTab.users.role;
    const matchesGroup =
      tableFiltersByTab.users.group === "all" ||
      user.group === tableFiltersByTab.users.group;
    const matchesStatus =
      tableFiltersByTab.users.status === "all" ||
      user.status === tableFiltersByTab.users.status;

    return matchesSearch && matchesRole && matchesGroup && matchesStatus;
  });

  const filteredRoles = roles.filter((role) => {
    const matchesSearch =
      !roleSearch ||
      `${role.name} ${role.description} ${role.status}`
        .toLowerCase()
        .includes(roleSearch);
    const matchesStatus =
      tableFiltersByTab.roles.status === "all" ||
      role.status === tableFiltersByTab.roles.status;
    return matchesSearch && matchesStatus;
  });

  const filteredGroups = groups.filter((group) => {
    const matchesSearch =
      !groupSearch ||
      `${group.name} ${group.description} ${group.members.join(" ")} ${group.allowedRoles.join(" ")}`
        .toLowerCase()
        .includes(groupSearch);
    const matchesRole =
      tableFiltersByTab.groups.role === "all" ||
      group.allowedRoles.includes(tableFiltersByTab.groups.role);
    return matchesSearch && matchesRole;
  });

  const usersPagination = paginateRows(filteredUsers, "users");
  const rolesPagination = paginateRows(filteredRoles, "roles");
  const groupsPagination = paginateRows(filteredGroups, "groups");

  const currentPagination =
    activeTab === "users"
      ? usersPagination
      : activeTab === "roles"
        ? rolesPagination
        : groupsPagination;

  const activeHeaderAction = (
    <div style={{ display: "flex", gap: "12px" }}>
      <Button
        size="small"
        variant="outlined"
        leftIcon={AddIcon}
        onClick={openCreateRoleDrawer}
      >
        New Role
      </Button>
      <Button
        size="small"
        variant="outlined"
        leftIcon={AddIcon}
        onClick={openCreateGroupModal}
      >
        New Team
      </Button>
    </div>
  );
  const renderTableToolbar = () => {
    const filterSelectStyle = {
      width: "fit-content",
      maxWidth: "100%",
    };

    if (activeTab === "users") {
      return (
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div
            style={{
              padding: "12px 20px",
              borderBottom: "1px solid var(--neutral-line-separator-1)",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: "16px",
              flexWrap: "wrap",
              flexShrink: 0,
              background: "var(--neutral-surface-primary)",
            }}
          >
            <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
              <div style={filterSelectStyle}>
                <DropdownSelect
                  value={tableFiltersByTab.users.role}
                  onChange={(nextValue) =>
                    updateTableFilter("users", "role", nextValue)
                  }
                  options={[
                    { value: "all", label: "All Roles" },
                    ...roleOptions,
                  ]}
                  variant="filter"
                  placeholder="Role"
                  fontSize="var(--text-title-3)"
                  optionFontSize="var(--text-title-3)"
                />
            </div>
            <div style={filterSelectStyle}>
              <DropdownSelect
                value={tableFiltersByTab.users.group}
                onChange={(nextValue) =>
                  updateTableFilter("users", "group", nextValue)
                }
                options={[
                  { value: "all", label: "All Teams" },
                  ...groupOptions.filter((option) => option.value !== "-"),
                ]}
                variant="filter"
                placeholder="Team"
                fontSize="var(--text-title-3)"
                optionFontSize="var(--text-title-3)"
              />
            </div>
            <div style={{ ...filterSelectStyle, width: "fit-content" }}>
              <DropdownSelect
                value={tableFiltersByTab.users.status}
                onChange={(nextValue) =>
                  updateTableFilter("users", "status", nextValue)
                }
                options={[
                  { value: "all", label: "All Status" },
                  { value: "Active", label: "Active" },
                  { value: "Inactive", label: "Inactive" },
                ]}
                variant="filter"
                placeholder="Status"
                fontSize="var(--text-title-3)"
                optionFontSize="var(--text-title-3)"
              />
            </div>
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              marginLeft: "auto",
              flexWrap: "wrap",
            }}
          >
            <TableSearchField
              value={tableSearchByTab.users}
              onChange={(event) => updateTableSearch("users", event.target.value)}
              placeholder="Search user, email, role"
              width="320px"
            />
          </div>
        </div>
        {hasPendingUserChanges ? (
          <div
            style={{
              padding: "12px 20px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              borderBottom: "1px solid var(--neutral-line-separator-1)",
              gap: "12px",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: "10px",
                padding: "10px 14px",
                borderRadius: "var(--radius-small)",
                background: "var(--feature-brand-container-darker)",
                border: "1px solid var(--feature-brand-container-darker)",
              }}
            >
              <Info
                size={16}
                strokeWidth={2.1}
                color="var(--feature-brand-primary)"
                style={{ flexShrink: 0, marginTop: "2px" }}
              />
              <span
                style={{
                  fontSize: "var(--text-title-3)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--neutral-on-surface-primary)",
                  lineHeight: "20px",
                  letterSpacing: "0.0962px",
                }}
              >
                You have unsaved changes ({Object.keys(pendingUserEdits).length} user{Object.keys(pendingUserEdits).length > 1 ? "s" : ""})
              </span>
            </div>
            <div style={{ display: "flex", gap: "12px", flexShrink: 0 }}>
              <Button
                size="small"
                variant="outlined"
                onClick={() => setPendingUserEdits({})}
              >
                Discard
              </Button>
              <Button
                size="small"
                variant="filled"
                onClick={openUserChangesModal}
              >
                Save Changes
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    );
    }

    if (activeTab === "roles") {
      return (
        <div
          style={{
            padding: "12px 20px",
            borderBottom: "1px solid var(--neutral-line-separator-1)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: "16px",
            flexWrap: "wrap",
            flexShrink: 0,
            background: "var(--neutral-surface-primary)",
          }}
        >
          <div style={filterSelectStyle}>
            <DropdownSelect
              value={tableFiltersByTab.roles.status}
              onChange={(nextValue) =>
                updateTableFilter("roles", "status", nextValue)
              }
              options={[
                { value: "all", label: "All Status" },
                { value: "Active", label: "Active" },
                { value: "Inactive", label: "Inactive" },
              ]}
              variant="filter"
              placeholder="Status"
              fontSize="var(--text-title-3)"
              optionFontSize="var(--text-title-3)"
            />
          </div>
          <TableSearchField
            value={tableSearchByTab.roles}
            onChange={(event) => updateTableSearch("roles", event.target.value)}
            placeholder="Search role, description"
            width="320px"
          />
        </div>
      );
    }

    return (
      <div
        style={{
          padding: "12px 20px",
          borderBottom: "1px solid var(--neutral-line-separator-1)",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "16px",
          flexWrap: "wrap",
          flexShrink: 0,
          background: "var(--neutral-surface-primary)",
        }}
      >
        <div style={filterSelectStyle}>
          <DropdownSelect
            value={tableFiltersByTab.groups.role}
            onChange={(nextValue) =>
              updateTableFilter("groups", "role", nextValue)
            }
            options={[
              { value: "all", label: "All Roles" },
              ...roleOptions,
            ]}
            variant="filter"
            placeholder="Role"
            fontSize="var(--text-title-3)"
            optionFontSize="var(--text-title-3)"
          />
        </div>
        <TableSearchField
          value={tableSearchByTab.groups}
          onChange={(event) => updateTableSearch("groups", event.target.value)}
          placeholder="Search team, member, role"
          width="320px"
        />
      </div>
    );
  };

  const renderUsersTab = () => (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <div
        style={adminManagementTableHeaderRowStyle(
          "1.1fr 1.3fr 1.1fr 1.4fr 0.9fr 0.8fr"
        )}
      >
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          User
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Email
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Assign Role
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Permissions
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Team
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Status
        </div>
      </div>
      {usersPagination.rows.map((user, index) => {
        const baseUser = users.find((item) => item.id === user.id) || user;
        const roleChanged = user.role !== baseUser.role;
        const groupChanged = user.group !== baseUser.group;
        return (
          <div
            key={user.id}
            style={adminManagementTableRowStyle(
              "1.1fr 1.3fr 1.1fr 1.4fr 0.9fr 0.8fr",
              index === usersPagination.rows.length - 1,
              roleChanged || groupChanged
                ? {
                    minHeight: "82px",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                    alignItems: "stretch",
                  }
                : {}
            )}
          >
            <div
              style={adminManagementTableCellStyle({
                fontWeight: "var(--font-weight-regular)",
              })}
            >
              {user.name}
            </div>
            <div style={adminManagementTableCellStyle()}>{user.email}</div>
            <div
              style={adminManagementTableCellStyle({
                alignItems: "stretch",
              })}
            >
              <div
                style={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  gap: "6px",
                  justifyContent: "center",
                }}
              >
                <DropdownSelect
                  value={user.role || "Unassigned"}
                  onChange={(nextValue) =>
                    updatePendingUserEdit(user.id, { role: nextValue })
                  }
                  options={assignableRoleOptions}
                  fieldHeight="40px"
                  placeholder="Select Role"
                  borderRadius="8px"
                  fontSize="var(--text-title-3)"
                  optionFontSize="var(--text-title-3)"
                />
                {roleChanged ? (
                  <span
                    style={{
                      fontSize: "12px",
                      lineHeight: "16px",
                      color: "var(--status-orange-primary)",
                    }}
                  >
                    ⚠ This change will update access permissions
                  </span>
                ) : null}
              </div>
            </div>
            <div
              style={adminManagementTableCellStyle({
                flexWrap: "wrap",
                gap: "6px",
                alignContent: "center",
              })}
            >
              {(() => {
                const userRoleName = user.role || "Unassigned";
                const userRole = roles.find((r) => r.name === userRoleName);
                if (!userRole) {
                  return <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>-</span>;
                }
                const summary = getRolePermissionSummary(userRole.permissions);
                if (summary.length === 0) {
                   return <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>No access</span>;
                }
                return summary.slice(0, 3).map((summaryChip) => (
                  <span
                    key={summaryChip.key}
                    style={{
                      height: "28px",
                      padding: "0 10px",
                      borderRadius: "8px",
                      background: "var(--feature-brand-container-lighter)",
                      display: "inline-flex",
                      alignItems: "center",
                      fontSize: "12px",
                      color: "var(--neutral-on-surface-primary)",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {summaryChip.text}
                  </span>
                ));
              })()}
            </div>
            <div
              style={adminManagementTableCellStyle({
                alignItems: "stretch",
              })}
            >
              <div
                style={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                }}
              >
                <DropdownSelect
                  value={user.group || "Unassigned"}
                  onChange={(nextValue) =>
                    updatePendingUserEdit(user.id, { group: nextValue })
                  }
                  options={groupOptions}
                  fieldHeight="40px"
                  placeholder="Select Team"
                  borderRadius="8px"
                  fontSize="var(--text-title-3)"
                  optionFontSize="var(--text-title-3)"
                />
              </div>
            </div>
            <div style={adminManagementTableCellStyle()}>
              <StatusBadge
                variant={user.status === "Active" ? "green-light" : "grey-light"}
              >
                {user.status}
              </StatusBadge>
            </div>
          </div>
        );
      })}
      {usersPagination.totalRows === 0 ? (
        <div style={poReferenceTableEmptyStateStyle}>No users found.</div>
      ) : null}
    </div>
  );

  const renderRolesTab = () => (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <div
        style={adminManagementTableHeaderRowStyle(
          "1.05fr 1.5fr 1.7fr 0.85fr 72px"
        )}
      >
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Role
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Description
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Permissions
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Status
        </div>
        <div
          style={adminManagementTableCellStyle({
            fontWeight: "var(--font-weight-bold)",
            justifyContent: "center",
          })}
        >
          Action
        </div>
      </div>
      {rolesPagination.rows.map((role, index) => {
        const memberCount = users.filter((user) => user.role === role.name).length;

        return (
          <div
            key={role.id}
            style={adminManagementTableRowStyle(
              "1.05fr 1.5fr 1.7fr 0.85fr 72px",
              index === rolesPagination.rows.length - 1
            )}
          >
            <div
              style={adminManagementTableCellStyle({
                flexDirection: "column",
                alignItems: "flex-start",
                gap: "2px",
              })}
            >
              <span style={{ fontWeight: "var(--font-weight-bold)" }}>
                {role.name}
              </span>
              <span
                style={{
                  fontSize: "12px",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                {memberCount} members
              </span>
            </div>
            <div style={adminManagementTableCellStyle()}>{role.description}</div>
            <div
              style={adminManagementTableCellStyle({
                flexWrap: "wrap",
                gap: "8px",
                alignContent: "center",
              })}
            >
              {getRolePermissionSummary(role.permissions).map((summaryChip) => (
                <span
                  key={summaryChip.key}
                  style={{
                    height: "28px",
                    padding: "0 8px",
                    borderRadius: "8px",
                    background: "var(--feature-brand-container-lighter)",
                    display: "inline-flex",
                    alignItems: "center",
                    fontSize: "12px",
                    color: "var(--neutral-on-surface-primary)",
                    whiteSpace: "nowrap",
                  }}
                >
                  {summaryChip.text}
                </span>
              ))}
            </div>
            <div style={adminManagementTableCellStyle()}>
              <StatusBadge
                variant={role.status === "Active" ? "green-light" : "grey-light"}
              >
                {role.status}
              </StatusBadge>
            </div>
            <div
              style={adminManagementTableCellStyle({
                justifyContent: "center",
                position: "relative",
              })}
            >
              <button
                type="button"
                onClick={(event) => {
                  const rect = event.currentTarget.getBoundingClientRect();
                  setRoleActionMenuPosition({
                    top: rect.bottom + 8,
                    left: rect.right - 176,
                  });
                  setOpenRoleActionMenuId((prev) =>
                    prev === role.id ? null : role.id
                  );
                }}
                style={{
                  width: "32px",
                  height: "32px",
                  borderRadius: "8px",
                  border: "1px solid var(--neutral-line-separator-1)",
                  background: "var(--neutral-surface-primary)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                }}
              >
                <MoreVerticalIcon
                  size={16}
                  color="var(--neutral-on-surface-secondary)"
                />
              </button>

              {openRoleActionMenuId === role.id ? (
                <>
                  <div
                    style={{ position: "fixed", inset: 0, zIndex: 90 }}
                    onClick={() => setOpenRoleActionMenuId(null)}
                  />
                  <div
                    style={{
                      position: "fixed",
                      top: roleActionMenuPosition.top,
                      left: roleActionMenuPosition.left,
                      minWidth: "176px",
                      minWidth: "180px",
                      padding: "4px 0",
                      background: "var(--neutral-surface-primary)",
                      border: "1px solid var(--neutral-line-separator-1)",
                      borderRadius: "var(--radius-small)",
                      boxShadow: "var(--elevation-sm)",
                      zIndex: 9999,
                      overflow: "hidden",
                    }}
                  >
                    <div
                      onMouseEnter={() => setHoveredRoleMenuItem(`edit-${role.id}`)}
                      onMouseLeave={() => setHoveredRoleMenuItem(null)}
                      onClick={() => {
                        setOpenRoleActionMenuId(null);
                        openEditRoleDrawer(role);
                      }}
                      style={{
                        padding: "12px 16px",
                        display: "flex",
                        alignItems: "center",
                        gap: "8px",
                        cursor: "pointer",
                        fontSize: "var(--text-title-3)",
                        color: "var(--neutral-on-surface-primary)",
                        background: hoveredRoleMenuItem === `edit-${role.id}` ? "var(--neutral-surface-grey-lighter)" : "transparent",
                      }}
                    >
                      <EditIcon size={16} /> Edit
                    </div>
                    <div
                      onMouseEnter={() => setHoveredRoleMenuItem(`delete-${role.id}`)}
                      onMouseLeave={() => setHoveredRoleMenuItem(null)}
                      onClick={() => {
                        setOpenRoleActionMenuId(null);
                        handleDeleteRole(role);
                      }}
                      style={{
                        padding: "12px 16px",
                        display: "flex",
                        alignItems: "center",
                        gap: "8px",
                        cursor: "pointer",
                        fontSize: "var(--text-title-3)",
                        color: "var(--status-red-primary)",
                        background: hoveredRoleMenuItem === `delete-${role.id}` ? "#FAE6E8" : "transparent",
                      }}
                    >
                      <DeleteIcon
                        size={16}
                        color="var(--status-red-primary)"
                      />
                      Delete
                    </div>
                  </div>
                </>
              ) : null}
            </div>
          </div>
        );
      })}
      {rolesPagination.totalRows === 0 ? (
        <div style={poReferenceTableEmptyStateStyle}>No roles found.</div>
      ) : null}
    </div>
  );

  const renderGroupsTab = () => (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <div
        style={adminManagementTableHeaderRowStyle(
          "1fr 1.5fr 1fr 72px"
        )}
      >
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Team
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Description
        </div>
        <div style={adminManagementTableCellStyle({ fontWeight: "var(--font-weight-bold)" })}>
          Members
        </div>
        <div
          style={adminManagementTableCellStyle({
            fontWeight: "var(--font-weight-bold)",
            justifyContent: "center",
          })}
        >
          Action
        </div>
      </div>
      {groupsPagination.rows.map((group, index) => (
        <div
          key={group.id}
          style={adminManagementTableRowStyle(
            "1fr 1.5fr 1fr 72px",
            index === groupsPagination.rows.length - 1
          )}
        >
          <div
            style={adminManagementTableCellStyle({
              flexDirection: "column",
              alignItems: "flex-start",
              gap: "4px",
            })}
          >
            <span style={{ fontWeight: "var(--font-weight-bold)" }}>
              {group.name}
            </span>
            <span
              style={{
                fontSize: "12px",
                color: "var(--neutral-on-surface-secondary)",
              }}
            >
              {group.members.length} members
            </span>
          </div>
          <div
            style={adminManagementTableCellStyle({
              color: "var(--neutral-on-surface-secondary)",
            })}
          >
            {group.description}
          </div>
          <div
            style={adminManagementTableCellStyle({
              flexWrap: "wrap",
              gap: "6px",
              alignContent: "center",
            })}
          >
            {group.members.length > 0 ? (
              group.members.map((member) => (
                <StatusBadge key={member} variant="grey-light">
                  {member}
                </StatusBadge>
              ))
            ) : (
              <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>
                -
              </span>
            )}
          </div>
          <div
            style={adminManagementTableCellStyle({
              justifyContent: "center",
              position: "relative",
            })}
          >
            <button
              type="button"
              onClick={(event) => {
                const rect = event.currentTarget.getBoundingClientRect();
                setGroupActionMenuPosition({
                  top: rect.bottom + 8,
                  left: rect.right - 176,
                });
                setOpenGroupActionMenuId((prev) =>
                  prev === group.id ? null : group.id
                );
              }}
              style={{
                width: "32px",
                height: "32px",
                borderRadius: "8px",
                border: "1px solid var(--neutral-line-separator-1)",
                background: "var(--neutral-surface-primary)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
              }}
            >
              <MoreVerticalIcon
                size={16}
                color="var(--neutral-on-surface-secondary)"
              />
            </button>

            {openGroupActionMenuId === group.id ? (
              <>
                <div
                  style={{ position: "fixed", inset: 0, zIndex: 90 }}
                  onClick={() => setOpenGroupActionMenuId(null)}
                />
                <div
                  style={{
                    position: "fixed",
                    top: groupActionMenuPosition.top,
                    left: groupActionMenuPosition.left,
                    minWidth: "180px",
                    padding: "4px 0",
                    background: "var(--neutral-surface-primary)",
                    border: "1px solid var(--neutral-line-separator-1)",
                    borderRadius: "var(--radius-small)",
                    boxShadow: "var(--elevation-sm)",
                    zIndex: 9999,
                    overflow: "hidden",
                  }}
                >
                  <div
                    onMouseEnter={() => setHoveredGroupMenuItem(`edit-${group.id}`)}
                    onMouseLeave={() => setHoveredGroupMenuItem(null)}
                    onClick={() => {
                      setOpenGroupActionMenuId(null);
                      openEditGroupModal(group);
                    }}
                    style={{
                      padding: "12px 16px",
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                      cursor: "pointer",
                      fontSize: "var(--text-title-3)",
                      color: "var(--neutral-on-surface-primary)",
                      background: hoveredGroupMenuItem === `edit-${group.id}` ? "var(--neutral-surface-grey-lighter)" : "transparent",
                    }}
                  >
                    <EditIcon size={16} /> Edit
                  </div>
                  <div
                    onMouseEnter={() => setHoveredGroupMenuItem(`delete-${group.id}`)}
                    onMouseLeave={() => setHoveredGroupMenuItem(null)}
                    onClick={() => {
                      setOpenGroupActionMenuId(null);
                      handleDeleteGroup(group);
                    }}
                    style={{
                      padding: "12px 16px",
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                      cursor: "pointer",
                      fontSize: "var(--text-title-3)",
                      color: "var(--status-red-primary)",
                      background: hoveredGroupMenuItem === `delete-${group.id}` ? "#FAE6E8" : "transparent",
                    }}
                  >
                    <DeleteIcon
                      size={16}
                      color="var(--status-red-primary)"
                    />
                    Delete
                  </div>
                </div>
              </>
            ) : null}
          </div>
        </div>
      ))}
      {groupsPagination.totalRows === 0 ? (
        <div style={poReferenceTableEmptyStateStyle}>No teams found.</div>
      ) : null}
    </div>
  );

  const renderChipEditor = (items, onRemove, variant = "grey") => (
    <React.Fragment>
      {items.length > 0 ? (
        items.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => onRemove(item)}
            style={{
              border: "none",
              background:
                variant === "blue"
                  ? "var(--feature-brand-container-lighter)"
                  : "var(--neutral-surface-grey-lighter)",
              color:
                variant === "blue"
                  ? "var(--feature-brand-primary)"
                  : "var(--neutral-on-surface-primary)",
              height: "32px",
              padding: "0 12px",
              borderRadius: "8px",
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              cursor: "pointer",
              fontSize: "var(--text-title-3)",
            }}
          >
            <span>{item}</span>
            <CloseIcon size={12} />
          </button>
        ))
      ) : null}
    </React.Fragment>
  );

  const renderRolePermissionRows = (nodes, depth = 0) =>
    nodes.map((node) => {
      const currentPermission = roleDrawerState.permissions[node.key] || {
        level: "no_access",
        canApprove: false,
      };
      const isExpandable = !!node.children?.length;
      const isExpanded = expandedRolePermissionKeys.includes(node.key);

      return (
        <React.Fragment key={node.key}>
          <div
            style={poReferenceTableRowStyle(rolePermissionTableColumns, false, {
              minHeight: "56px",
              paddingTop: "8px",
              paddingBottom: "8px",
            })}
          >
            <div
              style={poReferenceTableCellStyle({
                gap: "10px",
                paddingLeft: `${depth * 18}px`,
              })}
            >
              {isExpandable ? (
                <button
                  type="button"
                  onClick={() => toggleRolePermissionGroup(node.key)}
                  style={{
                    width: "24px",
                    height: "24px",
                    borderRadius: "6px",
                    border: "1px solid var(--neutral-line-separator-1)",
                    background: "var(--neutral-surface-primary)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    flexShrink: 0,
                  }}
                >
                  <ChevronDownIcon
                    size={16}
                    color="var(--neutral-on-surface-secondary)"
                    style={{
                      transform: isExpanded ? "rotate(0deg)" : "rotate(-90deg)",
                      transition: "transform 0.15s ease",
                    }}
                  />
                </button>
              ) : (
                <div style={{ width: "24px", flexShrink: 0 }} />
              )}
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "2px",
                  minWidth: 0,
                }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-3)",
                    fontWeight: isExpandable
                      ? "var(--font-weight-bold)"
                      : "var(--font-weight-regular)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  {node.label}
                </span>
                {node.approvable ? (
                  <span
                    style={{
                      fontSize: "12px",
                      color: "var(--neutral-on-surface-secondary)",
                    }}
                  >
                    Optional approval permission
                  </span>
                ) : null}
              </div>
            </div>

            <div style={poReferenceTableCellStyle()}>
              <DropdownSelect
                value={currentPermission.level}
                onChange={(nextValue) =>
                  updateRolePermissionLevel(node.key, nextValue)
                }
                options={ADMIN_PERMISSION_ACCESS_OPTIONS}
                fieldHeight="36px"
                borderRadius="10px"
                fontSize="var(--text-title-3)"
                optionFontSize="var(--text-title-3)"
                menuWidth={260}
              />
            </div>

            <div
              style={poReferenceTableCellStyle({ justifyContent: "center" })}
            >
              {node.approvable ? (
                <label
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "8px",
                    cursor:
                      currentPermission.level === "no_access"
                        ? "not-allowed"
                        : "pointer",
                  }}
                >
                  <Checkbox
                    checked={currentPermission.canApprove}
                    disabled={currentPermission.level === "no_access"}
                    onChange={(checked) =>
                      updateRolePermissionApprove(node.key, checked)
                    }
                  />
                  <span
                    style={{
                      fontSize: "12px",
                      color: "var(--neutral-on-surface-secondary)",
                      whiteSpace: "nowrap",
                    }}
                  >
                    Can Approve
                  </span>
                </label>
              ) : null}
            </div>
          </div>

          {isExpandable && isExpanded
            ? renderRolePermissionRows(node.children, depth + 1)
            : null}
        </React.Fragment>
      );
    });

  return (
    <>
      <div
        style={{
          height: "calc(100vh - 64px)",
          padding: "24px",
          boxSizing: "border-box",
          display: "flex",
          flexDirection: "column",
          gap: "20px",
          overflow: "hidden",
          minHeight: 0,
        }}
      >


        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "16px",
            flexWrap: "wrap",
          }}
        >
          <h1
            style={{
              margin: 0,
              fontSize: "var(--text-large-title)",
              fontWeight: "var(--font-weight-bold)",
            }}
          >
            User Management
          </h1>
          {activeHeaderAction}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" }}>
          {[
            {
              title: "Total Users",
              count: users.length,
              description: "Registered users with system access",
              icon: <UserIcon size={20} color="var(--feature-brand-primary)" />,
            },
            {
              title: "Total Roles",
              count: roles.length,
              description: "Defined permission sets and access levels",
              icon: <RoleIcon size={20} color="var(--feature-brand-primary)" />,
            },
            {
              title: "Total Teams",
              count: groups.length,
              description: "Functional groups and departments",
              icon: <TeamIcon size={20} color="var(--feature-brand-primary)" />,
            },
          ].map((card, i) => (
            <div
              key={i}
              style={{
                background: "var(--neutral-surface-primary)",
                borderRadius: "12px",
                padding: "20px",
                border: "1px solid var(--neutral-line-separator-1)",
                display: "flex",
                alignItems: "flex-start",
                gap: "16px",
              }}
            >
              <div
                style={{
                  width: "40px",
                  height: "40px",
                  borderRadius: "10px",
                  background: "var(--feature-brand-container-lighter)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                {card.icon}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                <span style={{ fontSize: "13px", color: "var(--neutral-on-surface-secondary)" }}>
                  {card.title}
                </span>
                <span
                  style={{
                    fontSize: "24px",
                    fontWeight: "var(--font-weight-bold)",
                    color: "var(--neutral-on-surface-primary)",
                    lineHeight: "1",
                  }}
                >
                  {card.count}
                </span>
                <span style={{ fontSize: "12px", color: "var(--neutral-on-surface-tertiary)" }}>
                  {card.description}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div
          style={{
            background: "var(--neutral-surface-primary)",
            borderRadius: "12px",
            border: "1px solid var(--neutral-line-separator-1)",
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            minHeight: 0,
            flex: 1,
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "flex-end",
              gap: 0,
              padding: "0 20px 0 0",
              borderBottom: "1px solid var(--neutral-surface-grey-lighter)",
              background: "var(--neutral-surface-primary)",
              flexShrink: 0,
            }}
          >
            {[
              { id: "users", label: "User", count: users.length },
              { id: "roles", label: "Role", count: roles.length },
              { id: "groups", label: "Team", count: groups.length },
            ].map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(tab.id);
                    setOpenRoleActionMenuId(null);
                    setOpenGroupActionMenuId(null);
                  }}
                  style={{
                    ...administrationTabRowStyle(isActive),
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                  }}
                >
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {renderTableToolbar()}

          <div
            style={{
              flex: 1,
              minHeight: 0,
              overflow: "auto",
            }}
          >
            {activeTab === "users"
              ? renderUsersTab()
              : activeTab === "roles"
                ? renderRolesTab()
                : renderGroupsTab()}
          </div>

          <TablePaginationFooter
            totalRows={currentPagination.totalRows}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={applyRowsPerPage}
            currentPage={currentPagination.currentPage}
            totalPages={currentPagination.totalPages}
            onPageChange={(nextPage) => updateTabPage(activeTab, nextPage)}
          />
        </div>
      </div>

      {userChangesModal ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 3000,
          }}
        >
          <div
            style={{
              width: "680px",
              maxWidth: "calc(100vw - 32px)",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "0",
              display: "flex",
              flexDirection: "column",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
              maxHeight: "90vh",
              overflow: "hidden",
            }}
          >
            {/* Header — centered title pattern per design system */}
            <div
              style={{
                padding: "64px 24px 20px",
                borderBottom: "1px solid var(--neutral-line-separator-1)",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "8px",
                textAlign: "center",
                position: "relative",
                flexShrink: 0,
              }}
            >
              <IconButton
                icon={CloseIcon}
                size="small"
                onClick={() => setUserChangesModal(null)}
                style={{ position: "absolute", top: "20px", right: "20px" }}
              />
              <h2
                style={{
                  margin: 0,
                  fontSize: "var(--text-headline)",
                  fontWeight: "var(--font-weight-bold)",
                }}
              >
                Confirm User Changes
              </h2>
              <p
                style={{
                  margin: 0,
                  fontSize: "var(--text-title-2)",
                  color: "var(--neutral-on-surface-secondary)",
                  lineHeight: "22px",
                }}
              >
                Review the updates below before saving them to the system.
              </p>
            </div>

            {/* Scrollable body */}
            <div
              style={{
                flex: "1 1 auto",
                minHeight: 0,
                overflowY: "auto",
                padding: "20px 24px",
                display: "flex",
                flexDirection: "column",
                gap: "16px",
              }}
            >
              {/* Summary counts */}
              {(() => {
                const roleChangeCount = userChangesModal.changes.filter((c) => c.roleChanged).length;
                const teamChangeCount = userChangesModal.changes.filter((c) => c.groupChanged).length;
                const totalCount = userChangesModal.changes.length;

                return (
                  <div
                    style={{
                      background: "var(--neutral-surface-secondary)",
                      borderRadius: "12px",
                      padding: "14px 16px",
                      display: "flex",
                      flexDirection: "column",
                      gap: "6px",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "var(--text-title-2)",
                        fontWeight: "var(--font-weight-bold)",
                      }}
                    >
                      You are updating {totalCount} user{totalCount !== 1 ? "s" : ""}:
                    </span>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "4px",
                      }}
                    >
                      {roleChangeCount > 0 && (
                        <span style={{ fontSize: "14px", color: "var(--neutral-on-surface-secondary)" }}>
                          • Role changes: {roleChangeCount} user{roleChangeCount !== 1 ? "s" : ""}
                        </span>
                      )}
                      {teamChangeCount > 0 && (
                        <span style={{ fontSize: "14px", color: "var(--neutral-on-surface-secondary)" }}>
                          • Team changes: {teamChangeCount} user{teamChangeCount !== 1 ? "s" : ""}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* Direct user list for < 4 users, or accordions for >= 4 */}
              {userChangesModal.changes.length < 4 ? (
                <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                  {userChangesModal.changes.map((change) => (
                    <div
                      key={change.userId}
                      style={{
                        border: "1px solid var(--neutral-line-separator-1)",
                        borderRadius: "12px",
                        padding: "12px 16px",
                        display: "flex",
                        flexDirection: "column",
                        gap: "6px",
                      }}
                    >
                      <span style={{ fontSize: "var(--text-title-3)", fontWeight: "var(--font-weight-bold)" }}>
                        {change.userName}
                      </span>
                      {change.roleChanged && (
                        <span style={{ fontSize: "12px", color: "var(--neutral-on-surface-secondary)" }}>
                          Role: {change.currentRole || "Unassigned"} → {change.nextRole || "Unassigned"}
                        </span>
                      )}
                      {change.groupChanged && (
                        <span style={{ fontSize: "12px", color: "var(--neutral-on-surface-secondary)" }}>
                          Team: {change.currentGroup === "-" || !change.currentGroup ? "No team" : change.currentGroup} → {change.nextGroup === "-" || !change.nextGroup ? "No team" : change.nextGroup}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <>
                  {/* Collapsible: View Role Changes Detail */}
                  {userChangesModal.changes.some((c) => c.roleChanged) && (() => {
                    const roleGroups = {};
                    userChangesModal.changes
                      .filter((c) => c.roleChanged)
                      .forEach((c) => {
                        const key = c.nextRole || "Unassigned";
                        if (!roleGroups[key]) roleGroups[key] = [];
                        roleGroups[key].push(c);
                      });

                    return (
                      <div
                        style={{
                          border: "1px solid var(--neutral-line-separator-1)",
                          borderRadius: "12px",
                          overflow: "hidden",
                        }}
                      >
                        <button
                          type="button"
                          onClick={() => setRoleChangesExpanded((prev) => !prev)}
                          style={{
                            width: "100%",
                            padding: "12px 16px",
                            background: "var(--neutral-surface-primary)",
                            border: "none",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            gap: "12px",
                            fontSize: "var(--text-title-3)",
                            fontWeight: "var(--font-weight-bold)",
                            textAlign: "left",
                          }}
                        >
                          <span>View Role Changes Detail</span>
                          <ChevronDownIcon
                            size={16}
                            style={{
                              transition: "transform 0.2s",
                              transform: roleChangesExpanded ? "rotate(-180deg)" : "rotate(0deg)",
                              flexShrink: 0,
                            }}
                          />
                        </button>

                        {roleChangesExpanded && (
                          <div
                            style={{
                              borderTop: "1px solid var(--neutral-line-separator-1)",
                              padding: "16px 16px",
                              display: "flex",
                              flexDirection: "column",
                              gap: "16px",
                              maxHeight: "200px",
                              overflowY: "auto",
                              boxSizing: "border-box",
                            }}
                          >
                            {Object.entries(roleGroups).map(([roleName, members]) => (
                              <div key={roleName} style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                                <span
                                  style={{
                                    fontSize: "var(--text-title-3)",
                                    fontWeight: "var(--font-weight-bold)",
                                  }}
                                >
                                  {roleName} ({members.length})
                                </span>
                                <ul
                                  style={{
                                    margin: 0,
                                    paddingLeft: "18px",
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: "4px",
                                  }}
                                >
                                  {members.map((m) => (
                                    <li
                                      key={m.userId}
                                      style={{
                                        fontSize: "var(--text-title-3)",
                                        color: "var(--neutral-on-surface-secondary)",
                                      }}
                                    >
                                      {m.userName} — {m.currentRole || "Unassigned"} → {m.nextRole || "Unassigned"}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })()}

                  {/* Collapsible: View Team Changes Detail */}
                  {userChangesModal.changes.some((c) => c.groupChanged) && (() => {
                    const teamGroups = {};
                    userChangesModal.changes
                      .filter((c) => c.groupChanged)
                      .forEach((c) => {
                        const key = c.nextGroup && c.nextGroup !== "-" ? `${c.nextGroup} Team` : "No Team";
                        if (!teamGroups[key]) teamGroups[key] = [];
                        teamGroups[key].push(c);
                      });

                    return (
                      <div
                        style={{
                          border: "1px solid var(--neutral-line-separator-1)",
                          borderRadius: "12px",
                          overflow: "hidden",
                        }}
                      >
                        <button
                          type="button"
                          onClick={() => setTeamChangesExpanded((prev) => !prev)}
                          style={{
                            width: "100%",
                            padding: "12px 16px",
                            background: "var(--neutral-surface-primary)",
                            border: "none",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            gap: "12px",
                            fontSize: "var(--text-title-3)",
                            fontWeight: "var(--font-weight-bold)",
                            textAlign: "left",
                          }}
                        >
                          <span>View Team Changes Detail</span>
                          <ChevronDownIcon
                            size={16}
                            style={{
                              transition: "transform 0.2s",
                              transform: teamChangesExpanded ? "rotate(-180deg)" : "rotate(0deg)",
                              flexShrink: 0,
                            }}
                          />
                        </button>

                        {teamChangesExpanded && (
                          <div
                            style={{
                              borderTop: "1px solid var(--neutral-line-separator-1)",
                              padding: "16px 16px",
                              display: "flex",
                              flexDirection: "column",
                              gap: "16px",
                              maxHeight: "200px",
                              overflowY: "auto",
                              boxSizing: "border-box",
                            }}
                          >
                            {Object.entries(teamGroups).map(([teamName, members]) => (
                               <div key={teamName} style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                                <span
                                  style={{
                                    fontSize: "var(--text-title-3)",
                                    fontWeight: "var(--font-weight-bold)",
                                  }}
                                >
                                  {teamName} ({members.length})
                                </span>
                                <ul
                                  style={{
                                    margin: 0,
                                    paddingLeft: "18px",
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: "4px",
                                  }}
                                >
                                  {members.map((m) => (
                                    <li
                                      key={m.userId}
                                      style={{
                                        fontSize: "var(--text-title-3)",
                                        color: "var(--neutral-on-surface-secondary)",
                                      }}
                                    >
                                      {m.userName} — {m.currentGroup === "-" || !m.currentGroup ? "No group" : m.currentGroup} → {m.nextGroup === "-" || !m.nextGroup ? "No group" : m.nextGroup}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </>
              )}
            </div>

            {/* Footer */}
            <div
              style={{
                padding: "16px 24px 24px",
                borderTop: "1px solid var(--neutral-line-separator-1)",
                display: "flex",
                flexDirection: "column",
                gap: "12px",
                flexShrink: 0,
              }}
            >
              <Button
                variant="filled"
                size="large"
                style={{ width: "100%" }}
                onClick={confirmUserChanges}
              >
                Save Changes
              </Button>
              <Button
                variant="outlined"
                size="large"
                style={{ width: "100%" }}
                onClick={() => setUserChangesModal(null)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {deleteConfirmation.open && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 4000,
          }}
        >
          <div
            style={{
              width: "400px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "28px 22px 22px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setDeleteConfirmation({ open: false, type: null, data: null })}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />
            <h2
              style={{
                margin: "20px 0 0 0",
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Delete {deleteConfirmation.type === "role" ? "Role?" : "Team?"}
            </h2>
            <p
              style={{
                margin: 0,
                textAlign: "center",
                fontSize: "var(--text-title-3)",
                color: "var(--neutral-on-surface-secondary)",
                lineHeight: "1.6",
              }}
            >
              Are you sure you want to delete <b>{deleteConfirmation.data?.name}</b>? This action cannot be undone.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              <Button
                variant="filled"
                size="large"
                onMouseEnter={() => setIsHoveredConfirmDelete(true)}
                onMouseLeave={() => setIsHoveredConfirmDelete(false)}
                style={{
                  width: "100%",
                  backgroundColor: isHoveredConfirmDelete ? "#D32F2F" : "var(--status-red-primary)",
                  color: "white",
                  border: "none",
                  transition: "background-color 0.2s"
                }}
                onClick={() => {
                  if (deleteConfirmation.type === "role") {
                    confirmDeleteRole(deleteConfirmation.data);
                  } else {
                    confirmDeleteGroup(deleteConfirmation.data);
                  }
                }}
              >
                Yes, Delete
              </Button>
              <Button
                variant="outlined"
                size="large"
                style={{ width: "100%" }}
                onClick={() => setDeleteConfirmation({ open: false, type: null, data: null })}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}

      {adminSnackbar.open && (
        <div
          style={{
            position: "fixed",
            top: "40px",
            right: "40px",
            width: "335px",
            height: "51px",
            background: "#282828",
            color: "#FFFFFF",
            padding: "0 20px",
            borderRadius: "8px",
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.2)",
            zIndex: 5000,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <span style={{ fontSize: "16px", fontWeight: "400" }}>
              {adminSnackbar.message}
            </span>
          </div>
          <span
            style={{
              fontSize: "14px",
              fontWeight: "700",
              cursor: "pointer",
              color: "#FFFFFF",
            }}
            onClick={() => setAdminSnackbar({ open: false, message: "" })}
          >
            Oke
          </span>
        </div>
      )}

      {roleDrawerState.open ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0, 0, 0, 0.28)",
            display: "flex",
            justifyContent: "flex-end",
            zIndex: 3000,
          }}
        >
          <div
            style={{ position: "absolute", inset: 0 }}
            onClick={closeRoleDrawer}
          />
          <div
            style={{
              position: "relative",
              width: "820px",
              maxWidth: "calc(100vw - 24px)",
              height: "100vh",
              background: "var(--neutral-surface-primary)",
              boxShadow: "-12px 0 32px rgba(0, 0, 0, 0.08)",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                padding: "24px 24px 20px",
                borderBottom: "1px solid var(--neutral-line-separator-1)",
                display: "flex",
                alignItems: "flex-start",
                justifyContent: "space-between",
                gap: "16px",
              }}
            >
              <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: "var(--text-headline)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  {roleDrawerState.mode === "edit" ? "Edit Role" : "New Role"}
                </h2>
                <p
                  style={{
                    margin: 0,
                    fontSize: "var(--text-title-3)",
                    color: "var(--neutral-on-surface-secondary)",
                    lineHeight: "20px",
                  }}
                >
                  Configure what access this role gets across the system.
                </p>
              </div>
              <IconButton icon={CloseIcon} size="large" onClick={closeRoleDrawer} />
            </div>

            <div
              style={{
                flex: 1,
                minHeight: 0,
                overflowY: "auto",
                padding: "24px",
                display: "flex",
                flexDirection: "column",
                gap: "24px",
              }}
            >
              <div
                style={{
                  display: "grid",
                  gap: "16px",
                  paddingBottom: "24px",
                  borderBottom: "1px solid var(--neutral-line-separator-1)",
                }}
              >
                <InputField
                  label="Role Name"
                  value={roleDrawerState.name}
                  onChange={(event) => {
                    setRoleDrawerState((prev) => ({
                      ...prev,
                      name: event.target.value,
                    }));
                    if (roleDrawerErrors.name) {
                      setRoleDrawerErrors((prev) => ({ ...prev, name: "" }));
                    }
                  }}
                  placeholder="Enter role name"
                  error={roleDrawerErrors.name}
                />
                <InputField
                  label="Description"
                  value={roleDrawerState.description}
                  onChange={(event) =>
                    setRoleDrawerState((prev) => ({
                      ...prev,
                      description: event.target.value,
                    }))
                  }
                  placeholder="Describe the role responsibilities"
                  multiline
                />
              </div>

              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "16px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "6px",
                  }}
                >
                  <h3
                    style={{
                      margin: 0,
                      fontSize: "var(--text-subtitle-1)",
                      fontWeight: "var(--font-weight-bold)",
                    }}
                  >
                    Permission Configurations
                  </h3>
                  <p
                    style={{
                      margin: 0,
                      fontSize: "var(--text-title-3)",
                      color: "var(--neutral-on-surface-secondary)",
                    }}
                  >
                    Set the access level for each module and enable approval only
                    where it is required.
                  </p>
                </div>

                <div
                  style={{
                    border: "none",
                    borderRadius: "0",
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={poReferenceTableHeaderRowStyle(
                      rolePermissionTableColumns
                    )}
                  >
                    <span
                      style={poReferenceTableHeaderCellStyle()}
                    >
                      Menu
                    </span>
                    <span
                      style={poReferenceTableHeaderCellStyle()}
                    >
                      Access Level
                    </span>
                    <span
                      style={poReferenceTableHeaderCellStyle({
                        justifyContent: "center",
                      })}
                    >
                      Approval
                    </span>
                  </div>

                  <div
                    style={{
                      background: "var(--neutral-surface-primary)",
                      maxHeight: "calc(100vh - 360px)",
                      overflow: "auto",
                    }}
                  >
                    {renderRolePermissionRows(ADMIN_PERMISSION_TREE)}
                  </div>
                </div>
              </div>
            </div>

            <div
              style={{
                padding: "16px 24px 24px",
                borderTop: "1px solid var(--neutral-line-separator-1)",
                background: "var(--neutral-surface-primary)",
                display: "flex",
                gap: "12px",
              }}
            >
              <Button
                variant="outlined"
                size="large"
                onClick={closeRoleDrawer}
                style={{ flex: 1 }}
              >
                Cancel
              </Button>
              <Button
                variant="filled"
                size="large"
                onClick={saveRoleDrawer}
                style={{ flex: 1 }}
              >
                Save Changes
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {groupModalState.open ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 3000,
          }}
        >
          <div
            style={{
              width: "760px",
              maxWidth: "calc(100vw - 32px)",
              maxHeight: "calc(100vh - 48px)",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "24px 22px 22px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              boxShadow: "var(--elevation-sm)",
              position: "relative",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={closeGroupModal}
              style={{ position: "absolute", top: "16px", right: "16px" }}
            />
            <h2
              style={{
                margin: "8px 0 0 0",
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              {groupModalState.mode === "edit" ? "Edit Team" : "New Team"}
            </h2>
            <div
              style={{
                display: "grid",
                gap: "16px",
                overflow: "auto",
                paddingRight: "4px",
              }}
            >
              <InputField
                label="Team Name"
                value={groupModalState.name}
                onChange={(event) => {
                  setGroupModalState((prev) => ({
                    ...prev,
                    name: event.target.value,
                  }));
                  if (groupModalErrors.name) {
                    setGroupModalErrors((prev) => ({ ...prev, name: "" }));
                  }
                }}
                placeholder="Enter team name"
                error={groupModalErrors.name}
              />
              <InputField
                label="Description"
                value={groupModalState.description}
                onChange={(event) =>
                  setGroupModalState((prev) => ({
                    ...prev,
                    description: event.target.value,
                  }))
                }
                placeholder="Describe the team responsibility"
                multiline
              />

              <div style={{ display: "grid", gap: "12px" }}>
                <span
                  style={{
                    fontSize: "var(--text-title-3)",
                    color: "var(--neutral-on-surface-secondary)",
                  }}
                >
                  User Members
                </span>
                <UnifiedInputShell
                  style={{
                    height: "auto",
                    minHeight: 0,
                    display: "flex",
                    flexWrap: "wrap",
                    padding: "10px 12px",
                    gap: "8px",
                    alignItems: "flex-start",
                  }}
                >
                  {renderChipEditor(
                    groupModalState.members,
                    (member) =>
                      setGroupModalState((prev) => ({
                        ...prev,
                        members: prev.members.filter((item) => item !== member),
                      }))
                  )}
                  <DropdownSelect
                    value=""
                    onChange={(nextValue) =>
                      setGroupModalState((prev) => ({
                        ...prev,
                        members: Array.from(
                          new Set([...prev.members, nextValue])
                        ),
                      }))
                    }
                    options={userOptions.filter(
                      (option) => !groupModalState.members.includes(option.value)
                    )}
                    placeholder="Add user member"
                    disabled={
                      userOptions.filter(
                        (option) => !groupModalState.members.includes(option.value)
                      ).length === 0
                    }
                    borderless
                    fieldHeight="30px"
                    fontSize="var(--text-title-3)"
                    optionFontSize="var(--text-title-3)"
                    style={{ flex: 1, minWidth: "140px" }}
                    renderOption={(option) => (
                      <div style={{ display: "flex", flexDirection: "column", gap: "2px", alignItems: "flex-start", textAlign: "left" }}>
                        <span style={{ fontSize: "var(--text-title-3)", fontWeight: "var(--font-weight-bold)", color: "var(--neutral-on-surface-primary)" }}>
                          {option.label}
                        </span>
                        {option.email && (
                          <span style={{ fontSize: "12px", color: "var(--neutral-on-surface-secondary)" }}>
                            {option.email}
                          </span>
                        )}
                      </div>
                    )}
                  />
                </UnifiedInputShell>
              </div>
            </div>
            <div
              style={{
                display: "flex",
                gap: "12px",
                paddingTop: "20px",
                borderTop: "1px solid var(--neutral-line-separator-1)",
                marginTop: "4px",
                flexShrink: 0,
              }}
            >
              <Button
                variant="outlined"
                size="large"
                style={{ flex: 1 }}
                onClick={closeGroupModal}
              >
                Cancel
              </Button>
              <Button
                variant="filled"
                size="large"
                style={{ flex: 1 }}
                onClick={saveGroupModal}
              >
                Save
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
};

const notificationChannelTabStyle = (isActive) => ({
  height: "40px",
  padding: "0 18px",
  borderRadius: "999px",
  border: `1px solid ${
    isActive
      ? "var(--feature-brand-primary)"
      : "var(--neutral-line-separator-1)"
  }`,
  background: isActive
    ? "var(--feature-brand-container-lighter)"
    : "var(--neutral-surface-primary)",
  color: isActive
    ? "var(--feature-brand-primary)"
    : "var(--neutral-on-surface-secondary)",
  fontSize: "var(--text-title-3)",
  fontWeight: isActive
    ? "var(--font-weight-bold)"
    : "var(--font-weight-regular)",
  cursor: "pointer",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  whiteSpace: "nowrap",
});

const notificationSummaryCardStyle = {
  minHeight: "96px",
  padding: "18px 20px",
  borderRadius: "16px",
  border: "1px solid var(--neutral-line-separator-1)",
  background: "var(--neutral-surface-primary)",
  display: "flex",
  alignItems: "flex-start",
  gap: "14px",
  boxSizing: "border-box",
};

const AdministrationNotificationSettings = ({
  isSidebarCollapsed,
  notificationSettings,
  onSaveNotificationSettings,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeChannel, setActiveChannel] = useState("all");
  const [settings, setSettings] = useState(() =>
    cloneNotificationSettings(notificationSettings || DEFAULT_NOTIFICATION_SETTINGS)
  );
  const [toastMessage, setToastMessage] = useState("");
  const toastTimerRef = useRef(null);

  useEffect(() => {
    setSettings(
      cloneNotificationSettings(
        notificationSettings || DEFAULT_NOTIFICATION_SETTINGS
      )
    );
  }, [notificationSettings]);

  useEffect(
    () => () => {
      if (toastTimerRef.current) {
        window.clearTimeout(toastTimerRef.current);
      }
    },
    []
  );

  const showToast = (message) => {
    setToastMessage(message);
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage("");
    }, 3200);
  };

  const updateNotificationItem = (sectionId, itemId, patch) => {
    setSettings((prev) =>
      prev.map((section) =>
        section.id !== sectionId
          ? section
          : {
              ...section,
              items: section.items.map((item) =>
                item.id === itemId ? { ...item, ...patch } : item
              ),
            }
      )
    );
  };

  const restoreDefaults = () => {
    setSettings(cloneNotificationSettings());
    showToast("Notification settings restored");
  };

  const handleSave = () => {
    onSaveNotificationSettings?.(cloneNotificationSettings(settings));
    showToast("Notification settings saved");
  };

  const normalizedSearch = searchQuery.trim().toLowerCase();
  const channelOptions = [
    { id: "all", label: "All Channels" },
    ...settings.map((section) => ({
      id: section.id,
      label: section.title,
    })),
  ];

  const filteredSections = settings
    .filter((section) => activeChannel === "all" || section.id === activeChannel)
    .map((section) => ({
      ...section,
      items: section.items.filter((item) => {
        if (!normalizedSearch) return true;
        return `${item.title} ${item.description} ${item.module} ${item.delivery}`
          .toLowerCase()
          .includes(normalizedSearch);
      }),
    }))
    .filter((section) => section.items.length > 0);

  const allItems = settings.flatMap((section) =>
    section.items.map((item) => ({ ...item, channelId: section.id }))
  );
  const enabledRuleCount = allItems.filter((item) => item.enabled).length;
  const criticalAlertCount = allItems.filter((item) =>
    ["Only Critical", "Only High Priority"].includes(item.delivery)
  ).length;
  const digestRuleCount = allItems.filter((item) =>
    item.delivery.includes("Digest")
  ).length;
  const liveAlertCount =
    settings.find((section) => section.id === "realtime")?.items.filter(
      (item) => item.enabled
    ).length || 0;

  return (
    <div
      style={{
        height: "calc(100vh - 64px)",
        padding: "24px",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        gap: "20px",
        overflow: "hidden",
        minHeight: 0,
      }}
    >
      {toastMessage ? (
        <div
          style={{
            position: "sticky",
            top: "16px",
            alignSelf: "flex-end",
            background: "var(--status-green-primary)",
            color: "var(--status-green-on-primary)",
            padding: "12px 16px",
            borderRadius: "var(--radius-small)",
            display: "flex",
            alignItems: "center",
            gap: "12px",
            boxShadow: "var(--elevation-sm)",
            zIndex: 10,
            minWidth: "320px",
            justifyContent: "space-between",
          }}
        >
          <span style={{ fontSize: "var(--text-title-3)" }}>{toastMessage}</span>
          <span
            style={{
              fontWeight: "var(--font-weight-bold)",
              cursor: "pointer",
              fontSize: "var(--text-title-3)",
            }}
            onClick={() => setToastMessage("")}
          >
            Okay
          </span>
        </div>
      ) : null}

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: "16px",
          flexWrap: "wrap",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          <h1
            style={{
              margin: 0,
              fontSize: "var(--text-large-title)",
              fontWeight: "var(--font-weight-bold)",
            }}
          >
            Notification Settings
          </h1>
          <p
            style={{
              margin: 0,
              maxWidth: "760px",
              fontSize: "var(--text-title-3)",
              lineHeight: "22px",
              color: "var(--neutral-on-surface-secondary)",
            }}
          >
            Operational approvals and execution alerts across procurement,
            manufacturing, sales, and administration.
          </p>
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "12px",
            flexWrap: "wrap",
          }}
        >
          <Button variant="outlined" size="small" onClick={restoreDefaults}>
            Restore Defaults
          </Button>
          <Button variant="filled" size="small" onClick={handleSave}>
            Save Changes
          </Button>
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "16px",
        }}
      >
        {[
          {
            title: "Active Rules",
            value: `${enabledRuleCount}/${allItems.length}`,
            hint: "Enabled notification automations",
            Icon: Bell,
          },
          {
            title: "Critical Alerts",
            value: criticalAlertCount,
            hint: "Escalation-focused rules",
            Icon: Info,
          },
          {
            title: "Digest Rules",
            value: digestRuleCount,
            hint: "Hourly or daily summary delivery",
            Icon: FileText,
          },
          {
            title: "Live Alerts",
            value: liveAlertCount,
            hint: "Real-time toasts, sound, and badges",
            Icon: LayoutGrid,
          },
        ].map(({ title, value, hint, Icon }) => (
          <div key={title} style={notificationSummaryCardStyle}>
            <div
              style={{
                width: "42px",
                height: "42px",
                borderRadius: "12px",
                background: "var(--feature-brand-container-lighter)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <Icon size={20} color="var(--feature-brand-primary)" />
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
              <span
                style={{
                  fontSize: "var(--text-title-3)",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                {title}
              </span>
              <span
                style={{
                  fontSize: "var(--text-headline)",
                  fontWeight: "var(--font-weight-bold)",
                }}
              >
                {value}
              </span>
              <span
                style={{
                  fontSize: "12px",
                  lineHeight: "18px",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                {hint}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div
        style={{
          background: "var(--neutral-surface-primary)",
          borderRadius: "16px",
          border: "1px solid var(--neutral-line-separator-1)",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          minHeight: 0,
          flex: 1,
        }}
      >
        <div
          style={{
            padding: "20px 20px 16px",
            borderBottom: "1px solid var(--neutral-line-separator-1)",
            display: "flex",
            flexDirection: "column",
            gap: "16px",
            background: "var(--neutral-surface-primary)",
            position: "sticky",
            top: 0,
            zIndex: 2,
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: "16px",
              flexWrap: "wrap",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
              {channelOptions.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setActiveChannel(option.id)}
                  style={notificationChannelTabStyle(activeChannel === option.id)}
                >
                  {option.label}
                </button>
              ))}
            </div>

            <TableSearchField
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder="Search notification, module, or rule"
              width="360px"
            />
          </div>
        </div>

        <div
          style={{
            display: "flex",
            flexDirection: "column",
            padding: "8px 0 0",
            overflow: "auto",
            minHeight: 0,
            flex: 1,
          }}
        >
          {filteredSections.length === 0 ? (
            <div
              style={{
                padding: "56px 24px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "8px",
              }}
            >
              <span
                style={{
                  fontSize: "var(--text-title-1)",
                  fontWeight: "var(--font-weight-bold)",
                }}
              >
                No notification rules found.
              </span>
              <span
                style={{
                  maxWidth: "420px",
                  textAlign: "center",
                  fontSize: "var(--text-title-3)",
                  lineHeight: "22px",
                  color: "var(--neutral-on-surface-secondary)",
                }}
              >
                Adjust the search or channel filter to see more notification
                configurations.
              </span>
            </div>
          ) : (
            filteredSections.map((section, sectionIndex) => (
              <div
                key={section.id}
                style={{
                  display: "grid",
                  gridTemplateColumns: "280px minmax(0, 1fr)",
                  gap: "24px",
                  padding: "24px 24px 28px",
                  borderTop:
                    sectionIndex === 0
                      ? "none"
                      : "1px solid var(--neutral-line-separator-1)",
                }}
              >
                <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      gap: "12px",
                    }}
                  >
                    <h2
                      style={{
                        margin: 0,
                        fontSize: "var(--text-headline)",
                        fontWeight: "var(--font-weight-bold)",
                      }}
                    >
                      {section.title}
                    </h2>
                    <StatusBadge variant="blue-light">
                      {section.items.length} Rules
                    </StatusBadge>
                  </div>
                  <p
                    style={{
                      margin: 0,
                      fontSize: "var(--text-title-3)",
                      lineHeight: "22px",
                      color: "var(--neutral-on-surface-secondary)",
                    }}
                  >
                    {section.description}
                  </p>
                </div>

                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    border: "1px solid var(--neutral-line-separator-1)",
                    borderRadius: "16px",
                    overflow: "hidden",
                  }}
                >
                  {section.items.map((item, index) => (
                    <div
                      key={item.id}
                      style={{
                        display: "grid",
                        gridTemplateColumns: "auto minmax(0, 1fr) 220px",
                        gap: "16px",
                        alignItems: "center",
                        padding: "18px 20px",
                        borderTop:
                          index === 0
                            ? "none"
                            : "1px solid var(--neutral-line-separator-1)",
                        background: item.enabled
                          ? "var(--neutral-surface-primary)"
                          : "#FCFCFC",
                      }}
                    >
                      <ToggleSwitch
                        checked={item.enabled}
                        onChange={(checked) =>
                          updateNotificationItem(section.id, item.id, {
                            enabled: checked,
                          })
                        }
                      />
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "6px",
                          minWidth: 0,
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "8px",
                            flexWrap: "wrap",
                          }}
                        >
                          <span
                            style={{
                              fontSize: "var(--text-title-2)",
                              fontWeight: "var(--font-weight-bold)",
                              minWidth: 0,
                            }}
                          >
                            {item.title}
                          </span>
                          <StatusBadge variant="grey-light">
                            {item.module}
                          </StatusBadge>
                        </div>
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            lineHeight: "22px",
                            color: "var(--neutral-on-surface-secondary)",
                          }}
                        >
                          {item.description}
                        </span>
                      </div>
                      <DropdownSelect
                        value={item.delivery}
                        onChange={(nextValue) =>
                          updateNotificationItem(section.id, item.id, {
                            delivery: nextValue,
                          })
                        }
                        options={NOTIFICATION_DELIVERY_OPTIONS}
                        fieldHeight="42px"
                        borderRadius="12px"
                        fontSize="var(--text-title-3)"
                        optionFontSize="var(--text-title-3)"
                      />
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

const buildReceiptStateFromLines = (
  lines = [],
  currentStatus = "Draft",
  seededLogs = []
) => {
  const shouldBeCompleted = currentStatus === "Completed";
  const baseLines = (lines || []).map((line) => {
    const orderedQty = Number(line.qty || line.orderedQty || 0);
    const initialReceivedQty = Number(line.receivedQty || 0);
    return {
      id: line.id,
      type: line.type || "manual",
      item: line.item,
      code: line.code || line.sku || "-",
      desc: line.desc || "-",
      woRef: line.woRef || "-",
      orderedQty,
      receivedQty: shouldBeCompleted
        ? orderedQty
        : Math.min(initialReceivedQty, orderedQty),
      receiveNow: "",
    };
  });

  const lineMap = Object.fromEntries(baseLines.map((line) => [line.id, line]));
  const normalizedSeededLogs = (seededLogs || []).map((log, index) => ({
    id: log.id || `receipt-log-seed-${index}`,
    receiptNumber:
      log.receiptNumber || `RCPT-${String(index + 1).padStart(4, "0")}`,
    date: log.date || "-",
    time: log.time || "-",
    receivedBy: log.receivedBy || "-",
    proofDocuments: normalizeProofDocuments(
      log.proofDocuments || log.attachments,
      log.proof
    ),
    notes: log.notes || "-",
    items: (log.items || []).map((item, itemIndex) => ({
      id:
        item.id || `${log.id || `receipt-log-seed-${index}`}-item-${itemIndex}`,
      item: item.item || lineMap[item.id]?.item || "-",
      code: item.code || lineMap[item.id]?.code || "-",
      receivedNow: Number(item.receivedNow) || 0,
    })),
  }));

  const hasAnyLine = baseLines.length > 0;
  const isCompleted = currentStatus === "Completed";
  const receiptLogs =
    normalizedSeededLogs.length > 0
      ? normalizedSeededLogs
      : isCompleted && hasAnyLine
        ? [
          {
            id: "receipt-log-completed-seed",
            receiptNumber: "RCPT-0001",
            date: "2026-03-30",
            time: "10:24",
            receivedBy: "Natasha Smith",
            proofDocuments: normalizeProofDocuments(
              [],
              "receipt-proof-completed.pdf"
            ),
            notes: "-",
            items: baseLines.map((line) => ({
              id: line.id,
              item: line.item,
              code: line.code || "-",
              receivedNow: line.orderedQty,
            })),
          },
        ]
        : [];

  return { receiptLines: baseLines, receiptLogs };
};

const buildReceiptActivityLogs = (logs = []) => {
  return (logs || []).map((log) => ({
    name: log.receivedBy || "Natasha Smith",
    email: "-",
    title: "Receipt Confirmed",
    desc: [
      (log.items || [])
        .map((item) => `${item.item}: Received ${item.receivedNow || 0} pcs`)
        .join(", "),
      log.notes && log.notes !== "-" ? `Notes: ${log.notes}` : "",
    ]
      .filter(Boolean)
      .join(" | "),
    timestamp: `${log.date} at ${log.time}`,
  }));
};

const parseActivityTimestamp = (value) => {
  if (!value) return 0;
  const normalized = String(value).replace(" at ", "T").replace(/\./g, "-");
  const parsed = new Date(normalized);
  return Number.isNaN(parsed.getTime()) ? 0 : parsed.getTime();
};

const formatActivityTimestamp = (date) => {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  const hh = String(date.getHours()).padStart(2, "0");
  const min = String(date.getMinutes()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd} at ${hh}:${min}`;
};

const sortLogsLatest = (logs = []) => {
  return [...logs].sort(
    (a, b) =>
      parseActivityTimestamp(b.timestamp) - parseActivityTimestamp(a.timestamp)
  );
};

const ensureCompletedLogIsLatest = (logs = [], currentStatus) => {
  const sortedLogs = sortLogsLatest(logs);
  if (currentStatus !== "Completed") return sortedLogs;

  const completedLogIndex = sortedLogs.findIndex(
    (log) => log.title === "PO Completed"
  );
  if (completedLogIndex === -1) return sortedLogs;

  const nextLogs = [...sortedLogs];
  const completedLog = { ...nextLogs[completedLogIndex] };
  nextLogs.splice(completedLogIndex, 1);

  const latestExistingTimestamp =
    nextLogs.length > 0
      ? Math.max(
        ...nextLogs.map((log) => parseActivityTimestamp(log.timestamp))
      )
      : parseActivityTimestamp(completedLog.timestamp);

  const safeBaseTimestamp =
    Number.isFinite(latestExistingTimestamp) && latestExistingTimestamp > 0
      ? latestExistingTimestamp
      : Date.now();

  completedLog.timestamp = formatActivityTimestamp(
    new Date(safeBaseTimestamp + 60 * 1000)
  );

  return [completedLog, ...nextLogs];
};

const PurchaseOrderDetail = ({
  onNavigate,
  initialData,
  poApprovalSettings,
  isSidebarCollapsed = false,
}) => {
  const scrollToTop = () => {
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "auto" });
    }
  };

  const navigateWithReset = (cb, ...args) => {
    scrollToTop();
    cb(...args);
  };
  const pageTopRef = useRef(null);
  const poNumber = initialData?.poNumber || "PO-202603-0001";
  const [currentStatus, setCurrentStatus] = useState(
    initialData?.status || "Draft"
  );
  const [currentBadge, setCurrentBadge] = useState(
    initialData?.sBadge || "grey-light"
  );
  const formData = initialData?.formData || null;
  const hasDraftData = !!formData;
  const displayValue = (value, fallback = "-") => {
    if (value === undefined || value === null) return fallback;
    if (typeof value === "string" && value.trim() === "") return fallback;
    return value;
  };
  const createdDate = hasDraftData
    ? displayValue(formData?.poDate)
    : initialData?.createdDate || "2026-03-20";
  const [showActionToast, setShowActionToast] = useState(false);
  const [actionToastMessage, setActionToastMessage] = useState("");
  const [isDecisionModalOpen, setIsDecisionModalOpen] = useState(false);
  const [decisionType, setDecisionType] = useState(null);
  const [decisionComment, setDecisionComment] = useState("");
  const [decisionError, setDecisionError] = useState("");
  const [revisionMessage, setRevisionMessage] = useState(
    currentStatus === "Need Revision"
      ? "Please update the delivery timeline and review the requested changes before resubmitting this purchase order."
      : ""
  );
  const [canceledMessage, setCanceledMessage] = useState(
    currentStatus === "Canceled"
      ? "The purchase order has been canceled and will not proceed further."
      : ""
  );
  const [approvalComment, setApprovalComment] = useState("");
  const approvalCommentRequired = !!(
    poApprovalSettings?.isApprovalActive && poApprovalSettings?.requireComment
  );
  const [activeTab, setActiveTab] = useState("details");
  const [showSubmitGuardModal, setShowSubmitGuardModal] = useState(false);
  const [showDetailSubmitConfirmModal, setShowDetailSubmitConfirmModal] =
    useState(false);
  const [documents, setDocuments] = useState(
    initialData?.formData?.documents || MOCK_PO_DOCUMENTS
  );
  const [openDocumentMenuId, setOpenDocumentMenuId] = useState(null);
  const [showDocumentToast, setShowDocumentToast] = useState(false);
  const [documentToastMessage, setDocumentToastMessage] = useState("");
  const [documentSearch, setDocumentSearch] = useState("");
  const [documentTypeFilter, setDocumentTypeFilter] = useState("all");
  const [documentView, setDocumentView] = useState("list");
  const [showDocumentFilterMenu, setShowDocumentFilterMenu] = useState(false);
  const [showUploadDocumentModal, setShowUploadDocumentModal] = useState(false);
  const [documentUploadFileName, setDocumentUploadFileName] = useState("");
  const [documentUploadFileSize, setDocumentUploadFileSize] = useState(0);
  const [documentUploadFileObject, setDocumentUploadFileObject] =
    useState(null);
  const [documentUploadDescription, setDocumentUploadDescription] =
    useState("");
  const [documentUploadDocumentType, setDocumentUploadDocumentType] =
    useState("other");
  const [documentUploadError, setDocumentUploadError] = useState("");
  const [documentMenuPosition, setDocumentMenuPosition] = useState({
    top: 0,
    left: 0,
  });
  const [showRenameDocumentModal, setShowRenameDocumentModal] = useState(false);
  const [showDeleteDocumentModal, setShowDeleteDocumentModal] = useState(false);
  const [selectedDocumentId, setSelectedDocumentId] = useState(null);
  const [renameDocumentValue, setRenameDocumentValue] = useState("");
  const [editDocumentTypeValue, setEditDocumentTypeValue] = useState("other");
  const [receiptLogs, setReceiptLogs] = useState([]);
  const [showConfirmReceiptModal, setShowConfirmReceiptModal] = useState(false);
  const [receiptProofDocuments, setReceiptProofDocuments] = useState([]);
  const [receiptProofUploadError, setReceiptProofUploadError] = useState("");
  const [receiptProofDescriptionErrors, setReceiptProofDescriptionErrors] =
    useState({});
  const [receiptReceivedBy, setReceiptReceivedBy] = useState("Natasha Smith");
  const [receiptNotes, setReceiptNotes] = useState("");
  const [receiptErrors, setReceiptErrors] = useState({});
  const [documentActivityLogs, setDocumentActivityLogs] = useState([]);
  const getCurrentLogTimestamp = () => {
    return formatActivityTimestamp(new Date());
  };

  useEffect(() => {
    if (initialData?.showDraftToast) {
      if (pageTopRef.current) {
        pageTopRef.current.scrollIntoView({ behavior: "auto", block: "start" });
      } else if (typeof window !== "undefined") {
        window.scrollTo({ top: 0, behavior: "auto" });
      }
      setActionToastMessage("Purchase order draft saved successfully");
      setShowActionToast(true);
      const timer = setTimeout(() => setShowActionToast(false), 4000);
      return () => clearTimeout(timer);
    }
  }, [initialData]);

  const vendorInfo = hasDraftData
    ? {
      name: displayValue(formData?.vendorName),
      phone: displayValue(formData?.vendorDetails?.phone),
      email: displayValue(formData?.vendorDetails?.email),
      address: displayValue(formData?.vendorDetails?.address),
    }
    : {
      name: initialData?.vendorName || "PT Mitra Sejahtera",
      phone: "08123456789",
      email: "contact@mitra.com",
      address: "Jl. Sudirman No.1, Jakarta Pusat, 10220",
    };

  const shipToInfo = hasDraftData
    ? {
      name: displayValue(formData?.shipTo?.name),
      phone: displayValue(formData?.shipTo?.phone),
      email: displayValue(formData?.shipTo?.email),
      address: displayValue(formData?.shipTo?.address),
    }
    : {
      name: "Labamu Manufacturing",
      phone: "+62 21 555 1234",
      email: "procurement@labamu.com",
      address:
        "Jl. Industri Utama Kav 9, South Tangerang, Banten, Indonesia 15320",
    };

  const mockLines = hasDraftData
    ? formData?.lines?.length
      ? formData.lines
      : []
    : [
      {
        id: 1,
        type: "wo",
        item: "Wooden Chair Frame",
        code: "WCF-A1",
        desc: "Pre-assembled frame part A",
        woRef: "WO-202603-001",
        qty: 100,
        price: 150000,
        image: "",
      },
      {
        id: 2,
        type: "manual",
        item: "Varnish 5L",
        code: "VRN-5",
        desc: "Clear gloss varnish for finishing",
        woRef: "-",
        qty: 20,
        price: 250000,
        image: "",
      },
    ];

  const subtotal = mockLines.reduce(
    (acc, line) =>
      acc + (parseFloat(line.qty) || 0) * (parseFloat(line.price) || 0),
    0
  );
  const tax = hasDraftData
    ? subtotal * ((parseFloat(formData?.tax) || 0) / 100)
    : subtotal * 0.11;
  const fees = hasDraftData
    ? (formData?.feeLines || []).reduce(
      (acc, fee) => acc + (parseFloat(fee.amount) || 0),
      0
    )
    : 150000;
  const total = subtotal + tax + fees;
  const detailNotes = hasDraftData
    ? displayValue(formData?.notes)
    : "Please ensure all items are packaged securely to prevent damage during transit. Deliveries are only accepted between 08:00 AM and 04:00 PM on weekdays.";
  const detailTerms = hasDraftData
    ? displayValue(formData?.terms)
    : "Payment within 30 days from invoice date. Vendor must deliver goods according to the agreed schedule and quantity.";
  const currencyLabel = hasDraftData
    ? formData?.currency === "USD"
      ? "USD - US Dollar"
      : formData?.currency === "IDR"
        ? "IDR - Indonesian Rupiah"
        : displayValue(formData?.currency)
    : "IDR - Indonesian Rupiah";
  const expectedDeliveryDate = hasDraftData
    ? displayValue(formData?.deliveryDate)
    : "2026-04-10";
  const [receiptLines, setReceiptLines] = useState([]);

  const validateDetailRequiredInfo = () => {
    const missing = [];
    if (!(formData?.vendorName || initialData?.vendorName))
      missing.push("Vendor");
    if (!createdDate || createdDate === "-") missing.push("PO Date");
    if (!currencyLabel || currencyLabel === "-") missing.push("Currency");
    if (!mockLines.length) missing.push("Purchase Order Lines");
    return missing;
  };

  const showHeaderEdit =
    currentStatus === "Draft" || currentStatus === "Need Revision";
  const showHeaderPrint = currentStatus === "Completed";
  const showFooterSubmit =
    currentStatus === "Draft" || currentStatus === "Need Revision";
  const showFooterApprovalActions = currentStatus === "Waiting for Approval";
  const hasReceiptHistory =
    receiptLogs.length > 0 ||
    (!!formData?.receiptLogs && formData.receiptLogs.length > 0);
  const showFooterIssuedCancel =
    currentStatus === "Issued" && !hasReceiptHistory;

  const clearLinkedWorkOrderVendorPo = (sourceData) => {
    if (!sourceData) return sourceData;

    return {
      ...sourceData,
      vendors: (sourceData.vendors || []).map((vendor) =>
        vendor.poNumber === poNumber
          ? {
              ...vendor,
              poNumber: "",
              isPoApproved: false,
              poStatus: "",
              poBadge: "",
              poStatusKey: "",
              status: "Waiting",
              receivedOutput: 0,
              receivedDate: "",
              receipts: [],
            }
          : vendor
      ),
    };
  };

  const handlePoAction = (message) => {
    setActionToastMessage(message);
    setShowActionToast(true);
    setTimeout(() => setShowActionToast(false), 4000);
  };

  const handleDetailSubmitClick = () => {
    const missingFields = validateDetailRequiredInfo();
    if (missingFields.length > 0) {
      setShowSubmitGuardModal(true);
      return;
    }
    setShowDetailSubmitConfirmModal(true);
  };

  const getApprovedVendorReturnState = (vendor) => {
    const assignedQty = Number(vendor?.output || 0);
    const receivedQty = Number(vendor?.receivedOutput || 0);

    return {
      ...vendor,
      isPoApproved: true,
      status:
        assignedQty > 0 && receivedQty >= assignedQty
          ? "Completed"
          : receivedQty > 0
            ? "Partially Received"
            : "In Progress",
    };
  };

  const handleConfirmDetailSubmit = () => {
    const approvalOn = !!poApprovalSettings?.isApprovalActive;
    const nextStatus = approvalOn ? "Waiting for Approval" : "Issued";
    const nextBadge = approvalOn ? "blue-light" : "blue";

    setCurrentStatus(nextStatus);
    setCurrentBadge(nextBadge);
    setShowDetailSubmitConfirmModal(false);

    if (
      !approvalOn &&
      initialData?.from === "work_order_detail" &&
      initialData?.returnTo?.data
    ) {
      const updatedReturnData = {
        ...initialData.returnTo.data,
        vendors: (initialData.returnTo.data.vendors || []).map((vendor) =>
          vendor.poNumber === poNumber
            ? getApprovedVendorReturnState(vendor)
            : vendor
        ),
      };

      initialData.returnTo = {
        ...initialData.returnTo,
        data: updatedReturnData,
      };
    }

    handlePoAction(
      approvalOn
        ? "Purchase order submitted for approval"
        : "Purchase order approved successfully"
    );
  };

  const handleEditPo = () => {
    scrollToTop();
    onNavigate("create", {
      source: "edit_purchase_order",
      poNumber,
      ...(initialData?.from ? { from: initialData.from } : {}),
      ...(initialData?.returnTo ? { returnTo: initialData.returnTo } : {}),
      ...(initialData?.from === "work_order_detail"
        ? {
          workOrder: {
            wo:
              initialData?.returnTo?.data?.wo ||
              mockLines.find((line) => line.type === "wo")?.woRef ||
              "-",
            product:
              initialData?.returnTo?.data?.product ||
              mockLines.find((line) => line.type === "wo")?.item ||
              "",
            sku:
              initialData?.returnTo?.data?.sku ||
              mockLines.find((line) => line.type === "wo")?.code ||
              "",
            image:
              initialData?.returnTo?.data?.image ||
              mockLines.find((line) => line.type === "wo")?.image ||
              "",
          },
          assignedOutput:
            mockLines.find((line) => line.type === "wo")?.qty || 0,
          outsourceSteps: initialData?.returnTo?.data?.outsourceSteps || [],
        }
        : {}),
      formData: {
        vendorName: vendorInfo.name !== "-" ? vendorInfo.name : "",
        vendorDetails: {
          phone: vendorInfo.phone !== "-" ? vendorInfo.phone : "",
          email: vendorInfo.email !== "-" ? vendorInfo.email : "",
          address: vendorInfo.address !== "-" ? vendorInfo.address : "",
        },
        poDate: createdDate !== "-" ? createdDate : "",
        deliveryDate: expectedDeliveryDate ?? "",
        currency: hasDraftData ? formData?.currency : "IDR",
        shipTo: {
          name: shipToInfo.name !== "-" ? shipToInfo.name : "",
          phone: shipToInfo.phone !== "-" ? shipToInfo.phone : "",
          email: shipToInfo.email !== "-" ? shipToInfo.email : "",
          address: shipToInfo.address !== "-" ? shipToInfo.address : "",
        },
        lines: mockLines,
        tax: hasDraftData ? formData?.tax || 0 : 11,
        feeLines: hasDraftData ? formData?.feeLines || [] : [],
        notes: detailNotes !== "-" ? detailNotes : "",
        terms: detailTerms !== "-" ? detailTerms : "",
      },
    });
  };

  const openDecisionModal = (type) => {
    setDecisionType(type);
    setDecisionComment("");
    setDecisionError("");
    setIsDecisionModalOpen(true);
  };

  const getDecisionMeta = () => {
    if (decisionType === "cancel") {
      return {
        title: "Cancel Purchase Order",
        helper: "Add a reason for canceling this purchase order.",
        mandatory: true,
      };
    }
    if (decisionType === "revision") {
      return {
        title: "Ask for Revision",
        helper: "Add revision notes for the requester.",
        mandatory: true,
      };
    }
    return {
      title: "Approve Purchase Order",
      helper: approvalCommentRequired
        ? "Comment is required before approving this purchase order."
        : "Add a comment for approval if needed.",
      mandatory: approvalCommentRequired,
    };
  };

  const handleSubmitDecision = () => {
    const meta = getDecisionMeta();
    const trimmedComment = decisionComment.trim();
    if (meta.mandatory && !trimmedComment) {
      setDecisionError("Comment is required.");
      return;
    }

    if (decisionType === "cancel") {
      setCurrentStatus("Canceled");
      setCurrentBadge("red");
      setCanceledMessage(trimmedComment);
      setRevisionMessage("");
      setApprovalComment("");

      if (
        currentStatus === "Issued" &&
        !hasReceiptHistory &&
        initialData?.from === "work_order_detail" &&
        initialData?.returnTo?.data
      ) {
        initialData.returnTo = {
          ...initialData.returnTo,
          data: clearLinkedWorkOrderVendorPo(initialData.returnTo.data),
        };
      }

      handlePoAction("Purchase order canceled");
    } else if (decisionType === "revision") {
      setCurrentStatus("Need Revision");
      setCurrentBadge("yellow-light");
      setRevisionMessage(trimmedComment);
      setCanceledMessage("");
      setApprovalComment("");
      handlePoAction("Revision has been requested");
    } else {
      setCurrentStatus("Issued");
      setCurrentBadge("blue");
      setRevisionMessage("");
      setCanceledMessage("");
      setApprovalComment(trimmedComment);

      if (
        initialData?.from === "work_order_detail" &&
        initialData?.returnTo?.data
      ) {
        const updatedReturnData = {
          ...initialData.returnTo.data,
          vendors: (initialData.returnTo.data.vendors || []).map((vendor) =>
            vendor.poNumber === poNumber
              ? getApprovedVendorReturnState(vendor)
              : vendor
          ),
        };

        initialData.returnTo = {
          ...initialData.returnTo,
          data: updatedReturnData,
        };
      }

      handlePoAction("Purchase order approved");
    }

    setIsDecisionModalOpen(false);
    setDecisionType(null);
    setDecisionComment("");
    setDecisionError("");
  };

  const handleBackNavigation = () => {
    if (initialData?.from === "work_order_detail" && initialData?.returnTo) {
      const nextReturnData = {
        ...initialData.returnTo.data,
        vendors: (initialData.returnTo.data?.vendors || []).map((vendor) => {
          if (vendor.poNumber !== poNumber) return vendor;
          const isApprovedStatus =
            currentStatus === "Issued" || currentStatus === "Completed";
          return {
            ...vendor,
            ...(isApprovedStatus ? getApprovedVendorReturnState(vendor) : {}),
            isPoApproved: isApprovedStatus,
          };
        }),
      };
      onNavigate(initialData.returnTo.view || "detail", nextReturnData);
      return;
    }
    onNavigate("list");
  };

  const approvalEnabled = !!poApprovalSettings?.isApprovalActive;
  const approverList = poApprovalSettings?.approvers?.length
    ? poApprovalSettings.approvers
    : [
      {
        id: "default-approver",
        name: "Natasha Smith",
        email: "natasha.smith@company.com",
        position: "Owner",
      },
    ];
  const requestedBy = "Joko";
  const requestedAt = createdDate;

  const getApprovalRowStatus = () => {
    if (currentStatus === "Issued" || currentStatus === "Completed")
      return { text: "Approved", variant: "green-light" };
    if (currentStatus === "Canceled")
      return { text: "Rejected", variant: "red-light" };
    if (currentStatus === "Need Revision")
      return { text: "Ask for Revision", variant: "yellow-light" };
    return { text: "Pending", variant: "grey-light" };
  };

  const getApprovalRowComment = () => {
    if (currentStatus === "Need Revision") return revisionMessage || "-";
    if (currentStatus === "Canceled") return canceledMessage || "-";
    if (currentStatus === "Issued" || currentStatus === "Completed")
      return approvalComment || "-";
    return "-";
  };

  const baseActivityLogs = [
    {
      name: "Joko",
      email: "joko@company.com",
      title: "PO Created",
      desc: "",
      timestamp: `${createdDate} at 14:30`,
    },
  ];

  const statusActivityLogs = (() => {
    if (currentStatus === "Waiting for Approval") {
      return [
        {
          name: "Joko",
          email: "joko@company.com",
          title: "PO Submitted",
          desc: "",
          timestamp: `${createdDate} at 15:15`,
        },
      ];
    }

    if (currentStatus === "Need Revision") {
      return [
        {
          name: approverList[0]?.name || "Approver",
          email: approverList[0]?.email || "-",
          title: "Ask for Revision",
          desc: revisionMessage || "-",
          timestamp: `${createdDate} at 16:30`,
        },
        {
          name: "Joko",
          email: "joko@company.com",
          title: "PO Submitted",
          desc: "",
          timestamp: `${createdDate} at 15:15`,
        },
      ];
    }

    if (currentStatus === "Issued") {
      return [
        {
          name: approvalEnabled
            ? approverList[0]?.name || "Approver"
            : "System",
          email: approvalEnabled ? approverList[0]?.email || "-" : "-",
          title: "PO Approved",
          desc: approvalComment || "",
          timestamp: `${createdDate} at 16:30`,
        },
        ...(approvalEnabled
          ? [
            {
              name: "Joko",
              email: "joko@company.com",
              title: "PO Submitted",
              desc: "",
              timestamp: `${createdDate} at 15:15`,
            },
          ]
          : []),
      ];
    }

    if (currentStatus === "Canceled") {
      return [
        {
          name: approverList[0]?.name || "Approver",
          email: approverList[0]?.email || "-",
          title: "PO Canceled",
          desc: canceledMessage || "-",
          timestamp: `${createdDate} at 16:30`,
        },
        {
          name: "Joko",
          email: "joko@company.com",
          title: "PO Submitted",
          desc: "",
          timestamp: `${createdDate} at 15:15`,
        },
      ];
    }

    if (currentStatus === "Completed") {
      return [
        {
          name: "System",
          email: "-",
          title: "PO Completed",
          desc: "All ordered items have been fully received.",
          timestamp: `${createdDate} at 17:30`,
        },
        {
          name: approvalEnabled
            ? approverList[0]?.name || "Approver"
            : "System",
          email: approvalEnabled ? approverList[0]?.email || "-" : "-",
          title: "PO Approved",
          desc: approvalComment || "",
          timestamp: `${createdDate} at 16:30`,
        },
        ...(approvalEnabled
          ? [
            {
              name: "Joko",
              email: "joko@company.com",
              title: "PO Submitted",
              desc: "",
              timestamp: `${createdDate} at 15:15`,
            },
          ]
          : []),
      ];
    }

    return [];
  })();

  const receiptActivityLogs = buildReceiptActivityLogs(receiptLogs);
  const dynamicActivityLogs = ensureCompletedLogIsLatest(
    [
      ...statusActivityLogs,
      ...receiptActivityLogs,
      ...documentActivityLogs,
      ...baseActivityLogs,
    ],
    currentStatus
  );
  const groupedReceiptLogs = receiptLogs.reduce((acc, log) => {
    const key = log.receiptNumber || log.id;
    const existing = acc.find((entry) => entry.receiptNumber === key);
    const normalizedProofDocuments = normalizeProofDocuments(
      log.proofDocuments || log.attachments,
      log.proof
    );
    if (existing) {
      existing.items = [...(existing.items || []), ...(log.items || [])];
      existing.proofDocuments = [
        ...(existing.proofDocuments || []),
        ...normalizedProofDocuments,
      ].filter(
        (doc, index, docs) =>
          docs.findIndex(
            (candidate) =>
              (candidate.id && doc.id && candidate.id === doc.id) ||
              (candidate.name === doc.name &&
                candidate.description === doc.description &&
                candidate.type === doc.type)
          ) === index
      );
      return acc;
    }

    acc.push({
      ...log,
      receiptNumber: key,
      items: [...(log.items || [])],
      proofDocuments: normalizedProofDocuments,
    });
    return acc;
  }, []);

  const tabButtonStyle = (isActive) => ({
    height: "48px",
    padding: "0 28px",
    borderRadius: "100px",
    border: isActive
      ? "2px solid var(--feature-brand-primary)"
      : "1px solid transparent",
    background: isActive ? "#EAF1FF" : "var(--neutral-surface-primary)",
    color: isActive ? "var(--feature-brand-primary)" : "#7F7F7F",
    fontSize: "var(--text-title-2)",
    fontWeight: isActive
      ? "var(--font-weight-bold)"
      : "var(--font-weight-regular)",
    cursor: "pointer",
    boxShadow: "none",
    transition: "all 0.18s ease",
  });

  const getDocumentTypeLabel = (documentType) => {
    if (documentType === "invoice") return "Invoice";
    if (documentType === "delivery_note") return "Delivery Note";
    if (documentType === "quotation_vendor") return "Quotation (Vendor)";
    if (documentType === "contract") return "Contract / Agreement";
    if (documentType === "contract_agreement") return "Contract / Agreement";
    if (documentType === "packing_list") return "Packing List";
    return "Other";
  };

  const getDocumentPreview = (doc, compact = false) => {
    const radius = compact ? "12px" : "0px";
    if (doc.type === "image" && doc.previewUrl) {
      return (
        <img
          src={doc.previewUrl}
          alt={doc.name}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            borderRadius: radius,
            display: "block",
          }}
        />
      );
    }
    if (doc.type === "video" && doc.previewUrl) {
      return (
        <div
          style={{
            width: "100%",
            height: "100%",
            position: "relative",
            borderRadius: radius,
            overflow: "hidden",
            background: "#111",
          }}
        >
          <video
            src={doc.previewUrl}
            muted
            playsInline
            preload="metadata"
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              display: "block",
            }}
          />
          <div
            style={{
              position: "absolute",
              inset: 0,
              background:
                "linear-gradient(180deg, rgba(0,0,0,0.0) 0%, rgba(0,0,0,0.22) 100%)",
            }}
          />
          <div
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              transform: "translate(-50%, -50%)",
              width: compact ? "22px" : "54px",
              height: compact ? "22px" : "54px",
              borderRadius: "50%",
              background: "rgba(255,255,255,0.22)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <div
              style={{
                width: 0,
                height: 0,
                borderTop: compact
                  ? "6px solid transparent"
                  : "10px solid transparent",
                borderBottom: compact
                  ? "6px solid transparent"
                  : "10px solid transparent",
                borderLeft: compact ? "10px solid white" : "16px solid white",
                marginLeft: compact ? "2px" : "4px",
              }}
            />
          </div>
        </div>
      );
    }
    if (doc.type === "image") {
      return (
        <div
          style={{
            width: "100%",
            height: "100%",
            background: "linear-gradient(180deg, #CFE1FF 0%, #F6E6C9 100%)",
            borderRadius: radius,
            overflow: "hidden",
            position: "relative",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              background:
                "linear-gradient(180deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0) 36%)",
            }}
          />
          <div
            style={{
              position: "absolute",
              left: compact ? "5px" : "18px",
              right: compact ? "5px" : "18px",
              bottom: compact ? "5px" : "18px",
              height: compact ? "13px" : "38px",
              background: "#7DB06E",
              borderRadius: compact ? "8px" : "14px",
            }}
          />
          <div
            style={{
              position: "absolute",
              left: compact ? "8px" : "24px",
              bottom: compact ? "11px" : "34px",
              width: compact ? "14px" : "34px",
              height: compact ? "10px" : "24px",
              background: "#89B97A",
              transform: "skewX(-18deg)",
              borderRadius: "3px",
            }}
          />
          <div
            style={{
              position: "absolute",
              left: compact ? "18px" : "56px",
              bottom: compact ? "11px" : "34px",
              width: compact ? "18px" : "50px",
              height: compact ? "14px" : "34px",
              background: "#6E9FD8",
              transform: "skewX(-18deg)",
              borderRadius: "4px",
            }}
          />
          <div
            style={{
              position: "absolute",
              right: compact ? "6px" : "20px",
              top: compact ? "6px" : "16px",
              width: compact ? "7px" : "18px",
              height: compact ? "7px" : "18px",
              borderRadius: "50%",
              background: "#FFD66B",
            }}
          />
        </div>
      );
    }
    if (doc.type === "video") {
      return (
        <div
          style={{
            width: "100%",
            height: "100%",
            background:
              "linear-gradient(135deg, #252525 0%, #4C4C4C 52%, #2D2D2D 100%)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            borderRadius: radius,
            position: "relative",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              position: "absolute",
              left: 0,
              right: 0,
              bottom: 0,
              height: compact ? "12px" : "30px",
              background:
                "linear-gradient(180deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.35) 100%)",
            }}
          />
          <div
            style={{
              width: compact ? "22px" : "54px",
              height: compact ? "22px" : "54px",
              borderRadius: "50%",
              background: "rgba(255,255,255,0.16)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              position: "relative",
              zIndex: 1,
            }}
          >
            <div
              style={{
                width: 0,
                height: 0,
                borderTop: compact
                  ? "6px solid transparent"
                  : "10px solid transparent",
                borderBottom: compact
                  ? "6px solid transparent"
                  : "10px solid transparent",
                borderLeft: compact ? "10px solid white" : "16px solid white",
                marginLeft: compact ? "2px" : "4px",
              }}
            />
          </div>
        </div>
      );
    }
    return (
      <div
        style={{
          width: "100%",
          height: "100%",
          background: "transparent",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          borderRadius: radius,
        }}
      >
        <DocumentTypeBadge
          fileName={doc.name}
          type={doc.type}
          size={compact ? "preview" : "preview"}
        />
      </div>
    );
  };

  const resetDocumentUploadState = () => {
    setDocumentUploadFileName("");
    setDocumentUploadFileSize(0);
    setDocumentUploadFileObject(null);
    setDocumentUploadDescription("");
    setDocumentUploadDocumentType("other");
    setDocumentUploadError("");
  };

  const handleDocumentUploadFileSelection = (files) => {
    const nextFile = Array.from(files || [])[0];
    if (!nextFile) return;
    const validationMessage = validateUploadFile(nextFile);
    setDocumentUploadFileName(nextFile.name);
    setDocumentUploadFileSize(nextFile.size || 0);
    setDocumentUploadFileObject(nextFile);
    setDocumentUploadError(validationMessage);
  };

  const handleReceiptProofFilesSelected = (files) => {
    const incomingFiles = Array.from(files || []);
    if (incomingFiles.length === 0) return;

    let nextUploadError = "";

    setReceiptProofDocuments((prev) => {
      const nextDocuments = [...prev];
      incomingFiles.forEach((file) => {
        if (nextDocuments.length >= MAX_PROOF_UPLOAD_FILES) {
          nextUploadError = "Max 3 files, 25MB each";
          return;
        }

        const validationMessage = validateUploadFile(file);
        if (validationMessage) {
          nextUploadError = validationMessage;
          return;
        }

        nextDocuments.push(
          createUploadDocumentRecord(file, { description: "" })
        );
      });
      return nextDocuments;
    });

    setReceiptProofUploadError(nextUploadError);
    setReceiptProofDescriptionErrors({});
  };

  const updateReceiptProofDescription = (docId, value) => {
    setReceiptProofDocuments((prev) =>
      prev.map((doc) =>
        doc.id === docId ? { ...doc, description: value } : doc
      )
    );
    setReceiptProofUploadError("");
    setReceiptProofDescriptionErrors((prev) => ({ ...prev, [docId]: "" }));
  };

  const removeReceiptProofDocument = (docId) => {
    setReceiptProofDocuments((prev) => prev.filter((doc) => doc.id !== docId));
    setReceiptProofDescriptionErrors((prev) => {
      const next = { ...prev };
      delete next[docId];
      return next;
    });
    setReceiptProofUploadError("");
  };

  const filteredDocuments = documents.filter((doc) => {
    const normalizedSearch = documentSearch.toLowerCase();
    const matchesSearch =
      !documentSearch.trim() ||
      doc.name.toLowerCase().includes(normalizedSearch) ||
      (doc.description || "").toLowerCase().includes(normalizedSearch) ||
      (doc.meta || "").toLowerCase().includes(normalizedSearch) ||
      getDocumentTypeLabel(doc.documentType)
        .toLowerCase()
        .includes(normalizedSearch);
    const matchesType =
      documentTypeFilter === "all" || doc.type === documentTypeFilter;
    return matchesSearch && matchesType;
  });

  const handleUploadDocument = () => {
    if (!(currentStatus === "Draft" || currentStatus === "Need Revision")) {
      setDocumentUploadError(
        "Documents can only be uploaded in Draft or Need Revision status"
      );
      return;
    }
    if (!documentUploadDocumentType) {
      setDocumentUploadError("Document type cannot be empty");
      return;
    }
    if (!documentUploadFileObject || !documentUploadFileName) {
      setDocumentUploadError("Please choose a file");
      return;
    }
    const validationMessage = validateUploadFile(documentUploadFileObject);
    if (validationMessage) {
      setDocumentUploadError(validationMessage);
      return;
    }
    const modifiedLabel = "Mar 31, 2026";
    const newDoc = createUploadDocumentRecord(documentUploadFileObject, {
      id: `doc-${Date.now()}`,
      name: documentUploadFileName,
      description: documentUploadDescription.trim(),
      meta: `Uploaded by Natasha Smith on ${modifiedLabel}`,
      documentType: documentUploadDocumentType,
      modifiedDate: modifiedLabel,
      size: formatUploadFileSize(documentUploadFileSize),
    });
    setDocuments((prev) => [newDoc, ...prev]);
    setDocumentActivityLogs((prev) => [
      {
        name: "Natasha Smith",
        email: "natasha.smith@company.com",
        title: "Document Uploaded",
        desc: newDoc.description
          ? `${newDoc.description} (${newDoc.name})`
          : newDoc.name,
        timestamp: getCurrentLogTimestamp(),
      },
      ...prev,
    ]);
    setShowUploadDocumentModal(false);
    resetDocumentUploadState();
    setDocumentToastMessage("Document uploaded successfully");
    setShowDocumentToast(true);
    setTimeout(() => setShowDocumentToast(false), 4000);
  };

  const handleDocumentAction = (message, docId = null) => {
    if (docId && (message === "delete" || message === "rename")) {
      if (message === "delete") {
        const targetDoc = documents.find((doc) => doc.id === docId);
        setSelectedDocumentId(docId);
        setRenameDocumentValue(targetDoc?.name || "");
        setShowDeleteDocumentModal(true);
        setOpenDocumentMenuId(null);
        return;
      }
      if (message === "rename") {
        const targetDoc = documents.find((doc) => doc.id === docId);
        setSelectedDocumentId(docId);
        setRenameDocumentValue(targetDoc?.name || "");
        setEditDocumentTypeValue(
          targetDoc?.documentType === "contract"
            ? "contract_agreement"
            : targetDoc?.documentType || "other"
        );
        setShowRenameDocumentModal(true);
        setOpenDocumentMenuId(null);
        return;
      }
    }
    setDocumentToastMessage(message);
    setOpenDocumentMenuId(null);
    setShowDocumentToast(true);
    setTimeout(() => setShowDocumentToast(false), 4000);
  };

  const handleConfirmRenameDocument = () => {
    const trimmedName = renameDocumentValue.trim();
    if (!trimmedName || !selectedDocumentId) return;
    const todayLabel = "Mar 31, 2026";
    setDocuments((prev) =>
      prev.map((doc) =>
        doc.id === selectedDocumentId
          ? {
            ...doc,
            name: trimmedName,
            documentType: editDocumentTypeValue,
            meta: `Uploaded by Natasha Smith on ${todayLabel}`,
            modifiedDate: todayLabel,
          }
          : doc
      )
    );
    setDocumentActivityLogs((prev) => [
      {
        name: "Natasha Smith",
        email: "natasha.smith@company.com",
        title: "Document Renamed",
        desc: trimmedName,
        timestamp: getCurrentLogTimestamp(),
      },
      ...prev,
    ]);
    setShowRenameDocumentModal(false);
    setSelectedDocumentId(null);
    setRenameDocumentValue("");
    setEditDocumentTypeValue("other");
    setDocumentToastMessage("Document updated successfully");
    setShowDocumentToast(true);
    setTimeout(() => setShowDocumentToast(false), 4000);
  };

  const handleConfirmDeleteDocument = () => {
    if (!selectedDocumentId) return;
    const deletedDoc = documents.find((doc) => doc.id === selectedDocumentId);
    setDocuments((prev) => prev.filter((doc) => doc.id !== selectedDocumentId));
    if (deletedDoc) {
      setDocumentActivityLogs((prev) => [
        {
          name: "Natasha Smith",
          email: "natasha.smith@company.com",
          title: "Document Deleted",
          desc: deletedDoc.name,
          timestamp: getCurrentLogTimestamp(),
        },
        ...prev,
      ]);
    }
    setShowDeleteDocumentModal(false);
    setSelectedDocumentId(null);
    setRenameDocumentValue("");
    setDocumentToastMessage("Document deleted successfully");
    setShowDocumentToast(true);
    setTimeout(() => setShowDocumentToast(false), 4000);
  };

  const updateReceiptLine = (lineId, value) => {
    setReceiptLines((prev) =>
      prev.map((line) =>
        line.id === lineId ? { ...line, receiveNow: value } : line
      )
    );
    setReceiptErrors((prev) => ({ ...prev, [lineId]: "" }));
  };

  const handleReceiptConfirmClick = () => {
    const nextErrors = {};
    let hasValue = false;
    receiptLines.forEach((line) => {
      const receiveNow = Number(line.receiveNow) || 0;
      const remainingQty = line.orderedQty - line.receivedQty;
      if (receiveNow > 0) hasValue = true;
      if (receiveNow > remainingQty) {
        nextErrors[line.id] = "Receive now cannot exceed remaining qty";
      }
    });
    if (!hasValue) {
      nextErrors._global = "Fill at least one Receive Now field to proceed";
    }
    setReceiptErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    setReceiptProofUploadError("");
    setReceiptProofDescriptionErrors({});
    setShowConfirmReceiptModal(true);
  };

  const handleSubmitReceipt = () => {
    const submittedAt = new Date();
    const submittedDate = submittedAt.toISOString().slice(0, 10);
    const submittedTime = submittedAt.toLocaleTimeString("en-GB", {
      hour: "2-digit",
      minute: "2-digit",
    });
    const affectedLines = receiptLines.filter(
      (line) => (Number(line.receiveNow) || 0) > 0
    );
    const normalizedReceiptNotes = receiptNotes.trim() || "-";
    const normalizedProofDocuments = receiptProofDocuments.map((doc) => ({
      ...doc,
      description: (doc.description || "").trim(),
    }));
    const nextProofDescriptionErrors = {};

    if (normalizedProofDocuments.length === 0) {
      setReceiptProofUploadError("Upload at least one proof document");
      return;
    }

    normalizedProofDocuments.forEach((doc) => {
      if (!doc.description) {
        nextProofDescriptionErrors[doc.id] = "Description is required";
      }
    });

    if (Object.keys(nextProofDescriptionErrors).length > 0) {
      setReceiptProofDescriptionErrors(nextProofDescriptionErrors);
      setReceiptProofUploadError("Add description for each proof document");
      return;
    }

    const nextReceiptLines = receiptLines.map((line) => {
      const receivedNow = Number(line.receiveNow) || 0;
      return {
        ...line,
        receivedQty: line.receivedQty + receivedNow,
        receiveNow: "",
      };
    });

    const nextReceiptEntry = {
      id: `receipt-log-${Date.now()}`,
      receiptNumber: `RCPT-${String(receiptLogs.length + 1).padStart(4, "0")}`,
      date: submittedDate,
      time: submittedTime,
      receivedBy: receiptReceivedBy || "-",
      proofDocuments: normalizedProofDocuments,
      notes: normalizedReceiptNotes,
      items: affectedLines.map((line) => ({
        id: line.id,
        item: line.item,
        code: line.code || "-",
        receivedNow: Number(line.receiveNow) || 0,
      })),
    };

    setReceiptLines(nextReceiptLines);
    setReceiptLogs((prev) => [nextReceiptEntry, ...prev]);
    setReceiptProofUploadError("");
    setReceiptProofDescriptionErrors({});

    const allRemainingQtyZero =
      nextReceiptLines.length > 0 &&
      nextReceiptLines.every((line) => {
        const remainingQty = Math.max(
          (Number(line.orderedQty) || 0) - (Number(line.receivedQty) || 0),
          0
        );
        return remainingQty === 0;
      });
    const workOrderReceivedNow = affectedLines.reduce(
      (sum, line) =>
        line.type === "wo" ? sum + (Number(line.receiveNow) || 0) : sum,
      0
    );

    if (
      initialData?.from === "work_order_detail" &&
      initialData?.returnTo?.data
    ) {
      const nextPoStatus = allRemainingQtyZero ? "Completed" : currentStatus;
      const nextPoBadge = allRemainingQtyZero ? "green" : currentBadge;
      const nextPoStatusKey = allRemainingQtyZero
        ? "completed"
        : initialData?.statusKey || "issued";

      const updatedReturnData = {
        ...initialData.returnTo.data,
        vendors: (initialData.returnTo.data.vendors || []).map((vendor) => {
          if (vendor.poNumber !== poNumber) return vendor;

          const vendorOutput = Number(vendor.output || 0);
          const currentVendorReceived = Number(vendor.receivedOutput || 0);
          const nextVendorReceived =
            workOrderReceivedNow > 0
              ? vendorOutput > 0
                ? Math.min(
                  vendorOutput,
                  currentVendorReceived + workOrderReceivedNow
                )
                : currentVendorReceived + workOrderReceivedNow
              : currentVendorReceived;
          const vendorFullyReceived =
            vendorOutput > 0 && nextVendorReceived >= vendorOutput;
          const nextVendorReceipt =
            workOrderReceivedNow > 0
              ? {
                amount: workOrderReceivedNow,
                date: submittedDate,
                time: submittedTime,
                attachment:
                  normalizedProofDocuments[0]?.name || "No Document Provided",
                attachments: normalizedProofDocuments,
                note: normalizedReceiptNotes,
                receivedBy: receiptReceivedBy || "Natasha Smith",
              }
              : null;

          return {
            ...vendor,
            receivedOutput: nextVendorReceived,
            status:
              workOrderReceivedNow > 0
                ? vendorFullyReceived
                  ? "Completed"
                  : "Partially Received"
                : vendor.status,
            receivedDate:
              workOrderReceivedNow > 0
                ? vendorFullyReceived
                  ? submittedDate
                  : vendor.receivedDate || ""
                : vendor.receivedDate,
            receipts: nextVendorReceipt
              ? [...(vendor.receipts || []), nextVendorReceipt]
              : vendor.receipts || [],
            poStatus: nextPoStatus,
            poBadge: nextPoBadge,
            poStatusKey: nextPoStatusKey,
            isPoApproved:
              nextPoStatus === "Issued" || nextPoStatus === "Completed"
                ? true
                : vendor.isPoApproved,
          };
        }),
      };

      initialData.returnTo = {
        ...initialData.returnTo,
        data: updatedReturnData,
      };
    }

    if (allRemainingQtyZero) {
      setCurrentStatus("Completed");
      setCurrentBadge("green");
    }

    setShowConfirmReceiptModal(false);
    setReceiptProofDocuments([]);
    setReceiptReceivedBy("Natasha Smith");
    setReceiptNotes("");
    setReceiptErrors({});
    setActionToastMessage(
      allRemainingQtyZero
        ? "Receipt confirmed successfully. Purchase order marked as completed"
        : "Receipt confirmed successfully"
    );
    setShowActionToast(true);
    setTimeout(() => setShowActionToast(false), 4000);
  };

  useEffect(() => {
    const syncedState = buildReceiptStateFromLines(
      mockLines,
      currentStatus,
      formData?.receiptLogs || []
    );
    setReceiptLines((prev) => {
      const hasUserReceiptProgress = prev.some(
        (line) =>
          (Number(line.receivedQty) || 0) > 0 ||
          (line.receiveNow || "").toString().trim() !== ""
      );
      if (hasUserReceiptProgress && currentStatus !== "Completed") return prev;
      return syncedState.receiptLines;
    });

    setReceiptLogs((prev) => {
      if (prev.length > 0) return prev;
      return syncedState.receiptLogs;
    });
  }, [currentStatus, mockLines, formData?.receiptLogs]);

  return (
    <div
      ref={pageTopRef}
      style={{
        padding: "24px",
        display: "flex",
        flexDirection: "column",
        gap: "16px",
        paddingBottom:
          showFooterSubmit || showFooterApprovalActions || showFooterIssuedCancel
            ? "100px"
            : "24px",
        position: "relative",
        background: "#F5F5F7",
      }}
    >
      {showActionToast || showDocumentToast ? (
        <div
          style={{
            position: "sticky",
            top: "16px",
            alignSelf: "flex-end",
            background: "var(--status-green-primary)",
            color: "var(--status-green-on-primary)",
            padding: "12px 16px",
            borderRadius: "var(--radius-small)",
            display: "flex",
            alignItems: "center",
            gap: "12px",
            boxShadow: "var(--elevation-sm)",
            zIndex: 1000,
            minWidth: "320px",
            justifyContent: "space-between",
          }}
        >
          <span style={{ fontSize: "var(--text-title-3)" }}>
            {showDocumentToast ? documentToastMessage : actionToastMessage}
          </span>
          <span
            style={{
              fontWeight: "var(--font-weight-bold)",
              cursor: "pointer",
              fontSize: "var(--text-title-3)",
            }}
            onClick={() => setShowActionToast(false)}
          >
            Okay
          </span>
        </div>
      ) : null}

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          marginBottom: "8px",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              cursor: "pointer",
              marginLeft: "-4px",
            }}
            onClick={handleBackNavigation}
          >
            <ChevronLeftIcon
              size={28}
              color="var(--neutral-on-surface-primary)"
            />
            <h1
              style={{
                margin: 0,
                fontSize: "var(--text-large-title)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Purchase Order Detail
            </h1>
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "var(--text-title-3)",
            }}
          >
            <span
              style={{
                color: "var(--neutral-on-surface-secondary)",
                cursor: "pointer",
              }}
              onClick={handleBackNavigation}
            >
              Purchase Order
            </span>
            <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>
              /
            </span>
            <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>
              Purchase Order Detail
            </span>
          </div>
        </div>
        <div style={{ display: "flex", gap: "12px" }}>
          {showHeaderEdit ? (
            <Button
              variant="outlined"
              leftIcon={EditIcon}
              onClick={handleEditPo}
            >
              Edit PO
            </Button>
          ) : null}
          {showHeaderPrint ? <Button variant="outlined">Print</Button> : null}
        </div>
      </div>

      {currentStatus === "Need Revision" || currentStatus === "Canceled" ? (
        <div
          style={{
            border: `1px solid ${currentStatus === "Need Revision" ? "#F5B342" : "#E04B45"
              }`,
            background:
              currentStatus === "Need Revision" ? "#F8EFDF" : "#F8E6E8",
            borderRadius: "16px",
            padding: "20px 22px",
            display: "flex",
            alignItems: "flex-start",
            gap: "12px",
          }}
        >
          <Info
            size={16}
            strokeWidth={2.1}
            color={
              currentStatus === "Need Revision"
                ? "var(--status-orange-primary)"
                : "var(--status-red-primary)"
            }
            style={{ flexShrink: 0, marginTop: "2px" }}
          />
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            <span
              style={{
                fontSize: "var(--text-title-2)",
                fontWeight: "var(--font-weight-bold)",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              {currentStatus === "Need Revision"
                ? "Revision Requested"
                : "Purchase Order Canceled"}
            </span>
            <span
              style={{
                fontSize: "var(--text-title-3)",
                color: "var(--neutral-on-surface-primary)",
                lineHeight: "1.6",
              }}
            >
              {currentStatus === "Need Revision"
                ? revisionMessage
                : canceledMessage}
            </span>
          </div>
        </div>
      ) : null}

      <div
        style={{
          background: "var(--neutral-surface-primary)",
          borderRadius: "16px",
          border: "1px solid var(--neutral-line-separator-1)",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            padding: "20px 24px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <span
            style={{
              fontSize: "var(--text-headline)",
              fontWeight: "var(--font-weight-bold)",
              color: "var(--neutral-on-surface-primary)",
            }}
          >
            {poNumber}
          </span>
          <StatusBadge variant={currentBadge}>{currentStatus}</StatusBadge>
        </div>
        <div
          style={{
            margin: "0 24px",
            borderTop: "1px solid var(--neutral-line-separator-1)",
          }}
        />
        <div
          style={{
            padding: "16px 24px",
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: "24px",
          }}
        >
          <LabelValue label="PO Date" value={createdDate} />
          <LabelValue
            label="Expected Delivery Date"
            value={expectedDeliveryDate ?? null}
          />
          <LabelValue label="Currency" value="IDR - Indonesian Rupiah" />
          <LabelValue label="Created By" value="Joko" />
        </div>
      </div>

      <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
        <button
          type="button"
          onClick={() => setActiveTab("details")}
          style={tabButtonStyle(activeTab === "details")}
        >
          PO Details
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("receipt")}
          style={tabButtonStyle(activeTab === "receipt")}
        >
          Receipt
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("documents")}
          style={tabButtonStyle(activeTab === "documents")}
        >
          Documents
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("logs")}
          style={tabButtonStyle(activeTab === "logs")}
        >
          Logs
        </button>
      </div>

      {activeTab === "details" ? (
        <>
          <div
            style={{ display: "flex", flexDirection: "column", gap: "16px" }}
          >
            <div
              style={{
                background: "var(--neutral-surface-primary)",
                borderRadius: "16px",
                border: "1px solid var(--neutral-line-separator-1)",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  padding: "24px 24px 0 24px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  Vendor Information
                </span>
              </div>
              <div
                style={{
                  padding: "20px 24px 24px 24px",
                  display: "grid",
                  gridTemplateColumns: "repeat(4, 1fr)",
                  gap: "24px",
                }}
              >
                <LabelValue label="Vendor Name" value={vendorInfo.name} />
                <LabelValue label="Phone Number" value={vendorInfo.phone} />
                <LabelValue label="Email" value={vendorInfo.email} />
                <LabelValue label="Address" value={vendorInfo.address} />
              </div>
            </div>

            <div
              style={{
                background: "var(--neutral-surface-primary)",
                borderRadius: "16px",
                border: "1px solid var(--neutral-line-separator-1)",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  padding: "24px 24px 0 24px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  Ship To
                </span>
              </div>
              <div
                style={{
                  padding: "20px 24px 24px 24px",
                  display: "grid",
                  gridTemplateColumns: "repeat(4, 1fr)",
                  gap: "24px",
                }}
              >
                <LabelValue label="Recipient Name" value={shipToInfo.name} />
                <LabelValue label="Phone Number" value={shipToInfo.phone} />
                <LabelValue label="Email" value={shipToInfo.email} />
                <LabelValue label="Address" value={shipToInfo.address} />
              </div>
            </div>

            <div
              style={{
                background: "var(--neutral-surface-primary)",
                borderRadius: "16px",
                border: "1px solid var(--neutral-line-separator-1)",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  padding: "24px 24px 0 24px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  Purchase Order Lines
                </span>
              </div>
              <div style={{ padding: "20px 24px 24px 24px" }}>
                <div
                  style={{
                    border: "none",
                    borderRadius: "0",
                    overflow: "hidden",
                    width: "100%",
                  }}
                >
                  <div style={{ overflowX: "auto", width: "100%" }}>
                    <div
                      style={{
                        minWidth: "1180px",
                        width: "100%",
                        display: "flex",
                        flexDirection: "column",
                      }}
                    >
                      <div
                        style={{
                          display: "grid",
                          gridTemplateColumns:
                            "84px 112px minmax(220px, 1.5fr) minmax(180px, 1fr) minmax(220px, 1.4fr) 130px 90px 160px 160px",
                          gap: "0",
                          padding: "0 16px",
                          height: "49px",
                          alignItems: "center",
                          background: "var(--neutral-surface-primary)",
                          borderBottom:
                            "1px solid var(--neutral-line-separator-1)",
                          fontSize: "var(--text-title-3)",
                          fontWeight: "var(--font-weight-bold)",
                          color: "var(--neutral-on-surface-primary)",
                        }}
                      >
                        <span>Type</span>
                        <span>Image</span>
                        <span>Name</span>
                        <span>SKU</span>
                        <span>Description</span>
                        <span>WO Ref</span>
                        <span style={{ textAlign: "center" }}>Qty</span>
                        <span style={{ textAlign: "right" }}>Unit Price</span>
                        <span style={{ textAlign: "right" }}>Subtotal</span>
                      </div>

                      {mockLines.length > 0 ? (
                        mockLines.map((line, idx) => {
                          const isWO = line.type === "wo";
                          const lineSubtotal =
                            (parseFloat(line.qty) || 0) *
                            (parseFloat(line.price) || 0);
                          return (
                            <div
                              key={line.id}
                              style={{
                                display: "grid",
                                gridTemplateColumns:
                                  "84px 112px minmax(220px, 1.5fr) minmax(180px, 1fr) minmax(220px, 1.4fr) 130px 90px 160px 160px",
                                gap: "0",
                                padding: "0 16px",
                                minHeight: "64px",
                                alignItems: "center",
                                borderBottom:
                                  idx === mockLines.length - 1
                                    ? "none"
                                    : "1px solid var(--neutral-line-separator-1)",
                                background: "var(--neutral-surface-primary)",
                              }}
                            >
                              <div>
                                <StatusBadge
                                  variant={
                                    isWO
                                      ? "blue-light"
                                      : line.type === "material"
                                        ? "yellow-light"
                                        : "grey-light"
                                  }
                                >
                                  {isWO
                                    ? "WO"
                                    : line.type === "material"
                                      ? "Material"
                                      : "Manual"}
                                </StatusBadge>
                              </div>
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                }}
                              >
                                <div
                                  style={{
                                    width: "40px",
                                    height: "40px",
                                    borderRadius: "8px",
                                    background:
                                      "var(--neutral-surface-grey-lighter)",
                                    border:
                                      "1px solid var(--neutral-line-separator-1)",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    flexShrink: 0,
                                    overflow: "hidden",
                                  }}
                                >
                                  <ImageAssetIcon
                                    size={20}
                                    color="var(--neutral-on-surface-tertiary)"
                                  />
                                </div>
                              </div>
                              <div style={{ minWidth: 0 }}>
                                <span
                                  style={{
                                    display: "block",
                                    fontSize: "var(--text-title-3)",
                                    fontWeight: "var(--font-weight-bold)",
                                    color: "var(--neutral-on-surface-primary)",
                                    whiteSpace: "nowrap",
                                    overflow: "hidden",
                                    textOverflow: "ellipsis",
                                  }}
                                  title={displayValue(line.item)}
                                >
                                  {displayValue(line.item)}
                                </span>
                              </div>
                              <div style={{ minWidth: 0 }}>
                                <span
                                  style={{
                                    display: "block",
                                    fontSize: "var(--text-title-3)",
                                    color: "var(--neutral-on-surface-primary)",
                                    whiteSpace: "nowrap",
                                    overflow: "hidden",
                                    textOverflow: "ellipsis",
                                  }}
                                  title={displayValue(line.code)}
                                >
                                  {displayValue(line.code)}
                                </span>
                              </div>
                              <div style={{ minWidth: 0 }}>
                                <span
                                  style={{
                                    display: "block",
                                    fontSize: "var(--text-title-3)",
                                    color:
                                      "var(--neutral-on-surface-secondary)",
                                    whiteSpace: "nowrap",
                                    overflow: "hidden",
                                    textOverflow: "ellipsis",
                                  }}
                                  title={displayValue(line.desc)}
                                >
                                  {displayValue(line.desc)}
                                </span>
                              </div>
                              <div style={{ minWidth: 0 }}>
                                <span
                                  style={{
                                    display: "block",
                                    fontSize: "var(--text-title-3)",
                                    color: "var(--neutral-on-surface-primary)",
                                    whiteSpace: "nowrap",
                                    overflow: "hidden",
                                    textOverflow: "ellipsis",
                                  }}
                                  title={displayValue(line.woRef)}
                                >
                                  {displayValue(line.woRef)}
                                </span>
                              </div>
                              <div
                                style={{
                                  textAlign: "center",
                                  fontSize: "var(--text-title-3)",
                                  color: "var(--neutral-on-surface-primary)",
                                }}
                              >
                                {displayValue(line.qty, 0)}
                              </div>
                              <div
                                style={{
                                  textAlign: "right",
                                  fontSize: "var(--text-title-3)",
                                  color: "var(--neutral-on-surface-primary)",
                                }}
                              >
                                {formatCurrency(line.price)}
                              </div>
                              <div
                                style={{
                                  textAlign: "right",
                                  fontSize: "var(--text-title-3)",
                                  fontWeight: "var(--font-weight-bold)",
                                  color: "var(--neutral-on-surface-primary)",
                                }}
                              >
                                {formatCurrency(lineSubtotal)}
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div
                          style={{
                            padding: "32px",
                            textAlign: "center",
                            color: "var(--neutral-on-surface-tertiary)",
                            fontSize: "var(--text-title-3)",
                            background: "var(--neutral-surface-primary)",
                          }}
                        >
                          No purchase order lines added.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div
              style={{
                background: "var(--neutral-surface-primary)",
                borderRadius: "16px",
                border: "1px solid var(--neutral-line-separator-1)",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  padding: "24px 24px 0 24px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  Summary
                </span>
              </div>
              <div
                style={{
                  padding: "20px 24px 24px 24px",
                  display: "flex",
                  flexDirection: "column",
                  gap: "16px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    fontSize: "var(--text-title-3)",
                  }}
                >
                  <span
                    style={{ color: "var(--neutral-on-surface-secondary)" }}
                  >
                    Subtotal
                  </span>
                  <span style={{ fontWeight: "var(--font-weight-bold)" }}>
                    {formatCurrency(subtotal)}
                  </span>
                </div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    fontSize: "var(--text-title-3)",
                  }}
                >
                  <span
                    style={{ color: "var(--neutral-on-surface-secondary)" }}
                  >
                    Tax ({formData ? Number(formData.tax) || 0 : 11}%)
                  </span>
                  <span style={{ fontWeight: "var(--font-weight-bold)" }}>
                    {formatCurrency(tax)}
                  </span>
                </div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    fontSize: "var(--text-title-3)",
                  }}
                >
                  <span
                    style={{ color: "var(--neutral-on-surface-secondary)" }}
                  >
                    Fees
                  </span>
                  <span style={{ fontWeight: "var(--font-weight-bold)" }}>
                    {formatCurrency(fees)}
                  </span>
                </div>
                <div
                  style={{
                    borderTop: "1px solid var(--neutral-line-separator-1)",
                  }}
                />
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    fontSize: "var(--text-title-1)",
                    fontWeight: "var(--font-weight-black)",
                  }}
                >
                  <span>Total</span>
                  <span>{formatCurrency(total)}</span>
                </div>
              </div>
            </div>

            <div
              style={{
                background: "var(--neutral-surface-primary)",
                borderRadius: "16px",
                border: "1px solid var(--neutral-line-separator-1)",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  padding: "24px 24px 0 24px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-2)",
                    fontWeight: "var(--font-weight-bold)",
                  }}
                >
                  Notes & Terms
                </span>
              </div>
              <div
                style={{
                  padding: "20px 24px 24px 24px",
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: "24px 40px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "var(--text-body)",
                      color: "var(--neutral-on-surface-secondary)",
                    }}
                  >
                    Notes
                  </span>
                  <p
                    style={{
                      margin: 0,
                      fontSize: "var(--text-title-3)",
                      color: "var(--neutral-on-surface-primary)",
                      lineHeight: "1.6",
                    }}
                  >
                    {detailNotes}
                  </p>
                </div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "var(--text-body)",
                      color: "var(--neutral-on-surface-secondary)",
                    }}
                  >
                    Terms
                  </span>
                  <p
                    style={{
                      margin: 0,
                      fontSize: "var(--text-title-3)",
                      color: "var(--neutral-on-surface-primary)",
                      lineHeight: "1.6",
                    }}
                  >
                    {detailTerms}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </>
      ) : activeTab === "documents" ? (
        <div
          style={{
            background: "var(--neutral-surface-primary)",
            borderRadius: "16px",
            border: "1px solid var(--neutral-line-separator-1)",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              padding: "20px 24px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: "16px",
                flexWrap: "wrap",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                  flexWrap: "wrap",
                  flex: 1,
                }}
              >
                <TableSearchField
                  value={documentSearch}
                  onChange={(e) => setDocumentSearch(e.target.value)}
                  placeholder="Search documents"
                  width="320px"
                />
                <div style={{ position: "relative" }}>
                  <div
                    onClick={() => setShowDocumentFilterMenu((prev) => !prev)}
                  >
                    <FilterPill
                      label="Type"
                      active={documentTypeFilter !== "all"}
                      isOpen={showDocumentFilterMenu}
                      count={documentTypeFilter !== "all" ? 1 : 0}
                    />
                  </div>

                  {showDocumentFilterMenu ? (
                    <>
                      <div
                        style={{ position: "fixed", inset: 0, zIndex: 89 }}
                        onClick={() => setShowDocumentFilterMenu(false)}
                      />
                      <div
                        style={{
                          position: "absolute",
                          top: "calc(100% + 8px)",
                          left: 0,
                          minWidth: "220px",
                          background: "var(--neutral-surface-primary)",
                          border: "1px solid var(--neutral-line-separator-1)",
                          borderRadius: "16px",
                          boxShadow: "var(--elevation-sm)",
                          padding: "8px 0",
                          zIndex: 90,
                        }}
                      >
                        {[
                          { key: "all", label: "All Types" },
                          { key: "pdf", label: "PDF" },
                          { key: "image", label: "Image" },
                          { key: "sheet", label: "Spreadsheet" },
                          { key: "video", label: "Video" },
                        ].map((opt) => (
                          <div
                            key={opt.key}
                            onClick={() => {
                              setDocumentTypeFilter(opt.key);
                              setShowDocumentFilterMenu(false);
                            }}
                            style={{
                              padding: "12px 14px",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "space-between",
                              cursor: "pointer",
                              fontSize: "var(--text-title-3)",
                              color: "var(--neutral-on-surface-primary)",
                              background:
                                documentTypeFilter === opt.key
                                  ? "var(--feature-brand-container-lighter)"
                                  : "transparent",
                            }}
                          >
                            <span>{opt.label}</span>
                            {documentTypeFilter === opt.key ? (
                              <CheckIcon
                                size={16}
                                color="var(--feature-brand-primary)"
                              />
                            ) : null}
                          </div>
                        ))}
                      </div>
                    </>
                  ) : null}
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                  flexShrink: 0,
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    border: "1px solid var(--neutral-line-separator-1)",
                    borderRadius: "12px",
                    overflow: "hidden",
                    flexShrink: 0,
                  }}
                >
                  <button
                    type="button"
                    onClick={() => setDocumentView("list")}
                    style={{
                      width: "40px",
                      height: "40px",
                      border: "1px solid var(--neutral-line-separator-1)",
                      background:
                        documentView === "list"
                          ? "var(--feature-brand-container-darker)"
                          : "var(--neutral-surface-primary)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      cursor: "pointer",
                    }}
                  >
                    <ListViewIcon
                      size={18}
                      color={
                        documentView === "list"
                          ? "var(--feature-brand-primary)"
                          : "var(--neutral-on-surface-secondary)"
                      }
                    />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDocumentView("grid")}
                    style={{
                      width: "40px",
                      height: "40px",
                      border: "1px solid var(--neutral-line-separator-1)",
                      borderLeft: "1px solid var(--neutral-line-separator-2)",
                      background:
                        documentView === "grid"
                          ? "var(--feature-brand-container-darker)"
                          : "var(--neutral-surface-primary)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      cursor: "pointer",
                    }}
                  >
                    <GridViewIcon
                      size={18}
                      color={
                        documentView === "grid"
                          ? "var(--feature-brand-primary)"
                          : "var(--neutral-on-surface-secondary)"
                      }
                    />
                  </button>
                </div>
                <Button
                  variant="filled"
                  leftIcon={UploadIcon}
                  disabled={
                    !(
                      currentStatus === "Draft" ||
                      currentStatus === "Need Revision"
                    )
                  }
                  onClick={() => {
                    resetDocumentUploadState();
                    setShowUploadDocumentModal(true);
                  }}
                >
                  Upload
                </Button>
              </div>
            </div>

            {documentView === "list" ? (
              <div style={poReferenceTableFrameStyle}>
                <div style={poReferenceTableScrollerStyle}>
                  <div style={poReferenceTableInnerStyle("1020px")}>
                    <div
                      style={poReferenceTableHeaderRowStyle(
                        "2.2fr 1fr 1.2fr 1fr 0.9fr 72px"
                      )}
                    >
                      <div style={poReferenceTableHeaderCellStyle()}>Name</div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Document Type
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Uploaded By
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Date Modified
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        File Size
                      </div>
                      <div
                        style={poReferenceTableHeaderCellStyle({
                          justifyContent: "flex-end",
                        })}
                      >
                        Action
                      </div>
                    </div>

                    {filteredDocuments.length > 0 ? (
                      filteredDocuments.map((doc, idx) => {
                        const metaText = doc.meta || "";
                        const uploadedBy =
                          metaText.indexOf("Uploaded by ") === 0
                            ? metaText.slice(12).split(" on ")[0]
                            : "-";
                        const modifiedDate =
                          doc.modifiedDate ||
                          (metaText.indexOf(" on ") > -1
                            ? metaText.split(" on ")[1]
                            : "-");
                        const primaryLabel = getDocumentPrimaryLabel(doc);
                        const secondaryLabel = getDocumentSecondaryLabel(doc);
                        return (
                          <div
                            key={doc.id}
                            style={poReferenceTableRowStyle(
                              "2.2fr 1fr 1.2fr 1fr 0.9fr 72px",
                              idx === filteredDocuments.length - 1
                            )}
                          >
                            <div
                              style={poReferenceTableCellStyle({
                                gap: "12px",
                                minWidth: 0,
                              })}
                            >
                              <div
                                style={{
                                  width: "40px",
                                  height: "40px",
                                  borderRadius: "12px",
                                  flexShrink: 0,
                                  overflow: "hidden",
                                }}
                              >
                                {getDocumentPreview(doc, true)}
                              </div>
                              <div
                                style={{
                                  minWidth: 0,
                                  display: "flex",
                                  flexDirection: "column",
                                  gap: "2px",
                                }}
                              >
                                <span
                                  style={{
                                    fontSize: "var(--text-title-3)",
                                    fontWeight: "var(--font-weight-bold)",
                                    color: "var(--neutral-on-surface-primary)",
                                    whiteSpace: "nowrap",
                                    overflow: "hidden",
                                    textOverflow: "ellipsis",
                                    display: "block",
                                  }}
                                >
                                  {primaryLabel}
                                </span>
                                {secondaryLabel ? (
                                  <span
                                    style={{
                                      fontSize: "var(--text-body)",
                                      color:
                                        "var(--neutral-on-surface-secondary)",
                                      whiteSpace: "nowrap",
                                      overflow: "hidden",
                                      textOverflow: "ellipsis",
                                      display: "block",
                                    }}
                                  >
                                    {secondaryLabel}
                                  </span>
                                ) : null}
                              </div>
                            </div>
                            <div
                              style={poReferenceTableCellStyle({
                                color: "var(--neutral-on-surface-secondary)",
                              })}
                            >
                              {getDocumentTypeLabel(doc.documentType)}
                            </div>
                            <div style={poReferenceTableCellStyle()}>
                              {uploadedBy}
                            </div>
                            <div style={poReferenceTableCellStyle()}>
                              {modifiedDate}
                            </div>
                            <div style={poReferenceTableCellStyle()}>
                              {doc.size || "-"}
                            </div>
                            <div
                              style={poReferenceTableCellStyle({
                                justifyContent: "flex-end",
                                position: "relative",
                              })}
                            >
                              <button
                                type="button"
                                onClick={(e) => {
                                  const rect =
                                    e.currentTarget.getBoundingClientRect();
                                  setDocumentMenuPosition({
                                    top: rect.bottom + 8,
                                    left: rect.right - 180,
                                  });
                                  setOpenDocumentMenuId((prev) =>
                                    prev === doc.id ? null : doc.id
                                  );
                                }}
                                style={{
                                  width: "32px",
                                  height: "32px",
                                  borderRadius: "8px",
                                  border:
                                    "1px solid var(--neutral-line-separator-1)",
                                  background: "var(--neutral-surface-primary)",
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  cursor: "pointer",
                                }}
                              >
                                <MoreVerticalIcon
                                  size={16}
                                  color="var(--neutral-on-surface-secondary)"
                                />
                              </button>

                              {openDocumentMenuId === doc.id ? (
                                <>
                                  <div
                                    style={{
                                      position: "fixed",
                                      inset: 0,
                                      zIndex: 90,
                                    }}
                                    onClick={() => setOpenDocumentMenuId(null)}
                                  />
                                  <div
                                    style={{
                                      position: "fixed",
                                      top: documentMenuPosition.top,
                                      left: documentMenuPosition.left,
                                      minWidth: "180px",
                                      background:
                                        "var(--neutral-surface-primary)",
                                      border:
                                        "1px solid var(--neutral-line-separator-1)",
                                      borderRadius: "12px",
                                      boxShadow: "var(--elevation-sm)",
                                      zIndex: 9999,
                                      overflow: "hidden",
                                    }}
                                  >
                                    <div
                                      onClick={() =>
                                        handleDocumentAction(
                                          `${doc.name} downloaded`
                                        )
                                      }
                                      style={{
                                        padding: "12px 14px",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "10px",
                                        cursor: "pointer",
                                        fontSize: "var(--text-title-3)",
                                        borderTop:
                                          "1px solid var(--neutral-line-separator-1)",
                                      }}
                                    >
                                      <DownloadIcon size={16} /> Download
                                    </div>
                                    <div
                                      onClick={() =>
                                        handleDocumentAction("rename", doc.id)
                                      }
                                      style={{
                                        padding: "12px 14px",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "10px",
                                        cursor: "pointer",
                                        fontSize: "var(--text-title-3)",
                                        borderTop:
                                          "1px solid var(--neutral-line-separator-1)",
                                      }}
                                    >
                                      <EditIcon size={16} /> Edit
                                    </div>
                                    <div
                                      onClick={() =>
                                        handleDocumentAction("delete", doc.id)
                                      }
                                      style={{
                                        padding: "12px 14px",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "10px",
                                        cursor: "pointer",
                                        fontSize: "var(--text-title-3)",
                                        borderTop:
                                          "1px solid var(--neutral-line-separator-1)",
                                        color: "var(--status-red-primary)",
                                      }}
                                    >
                                      <DeleteIcon
                                        size={16}
                                        color="var(--status-red-primary)"
                                      />{" "}
                                      Delete
                                    </div>
                                  </div>
                                </>
                              ) : null}
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div
                        style={{
                          ...poReferenceTableEmptyStateStyle,
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          gap: "8px",
                        }}
                      >
                        <span
                          style={{
                            fontSize: "var(--text-title-2)",
                            fontWeight: "var(--font-weight-bold)",
                          }}
                        >
                          No documents found
                        </span>
                        <span
                          style={{
                            fontSize: "var(--text-title-3)",
                            color: "var(--neutral-on-surface-secondary)",
                          }}
                        >
                          Try changing your search or filter.
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
                  gap: "16px",
                }}
              >
                {filteredDocuments.length > 0 ? (
                  filteredDocuments.map((doc) => {
                    const metaText = doc.meta || "";
                    const uploadedBy =
                      metaText.indexOf("Uploaded by ") === 0
                        ? metaText.slice(12).split(" on ")[0]
                        : "-";
                    const modifiedDate =
                      doc.modifiedDate ||
                      (metaText.indexOf(" on ") > -1
                        ? metaText.split(" on ")[1]
                        : "-");
                    const primaryLabel = getDocumentPrimaryLabel(doc);
                    const secondaryLabel = getDocumentSecondaryLabel(doc);
                    return (
                      <div
                        key={doc.id}
                        style={{
                          border: "1px solid var(--neutral-line-separator-1)",
                          borderRadius: "16px",
                          background: "var(--neutral-surface-primary)",
                          overflow: "hidden",
                          display: "flex",
                          flexDirection: "column",
                        }}
                      >
                        <div style={{ height: "152px", overflow: "hidden" }}>
                          {getDocumentPreview(doc, false)}
                        </div>
                        <div
                          style={{
                            padding: "16px",
                            display: "flex",
                            flexDirection: "column",
                            gap: "10px",
                          }}
                        >
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              gap: "8px",
                              alignItems: "flex-start",
                            }}
                          >
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "column",
                                gap: "2px",
                                flex: 1,
                                minWidth: 0,
                              }}
                            >
                              <span
                                style={{
                                  fontSize: "var(--text-title-3)",
                                  fontWeight: "var(--font-weight-bold)",
                                  color: "var(--neutral-on-surface-primary)",
                                  lineHeight: "1.5",
                                  minWidth: 0,
                                  overflow: "hidden",
                                  textOverflow: "ellipsis",
                                  whiteSpace: "nowrap",
                                }}
                              >
                                {primaryLabel}
                              </span>
                              {secondaryLabel ? (
                                <span
                                  style={{
                                    fontSize: "var(--text-body)",
                                    color:
                                      "var(--neutral-on-surface-secondary)",
                                    lineHeight: "1.4",
                                    minWidth: 0,
                                    overflow: "hidden",
                                    textOverflow: "ellipsis",
                                    whiteSpace: "nowrap",
                                  }}
                                >
                                  {secondaryLabel}
                                </span>
                              ) : null}
                            </div>
                            <div style={{ position: "relative" }}>
                              <button
                                type="button"
                                onClick={(e) => {
                                  const rect =
                                    e.currentTarget.getBoundingClientRect();
                                  setDocumentMenuPosition({
                                    top: rect.bottom + 8,
                                    left: rect.right - 180,
                                  });
                                  setOpenDocumentMenuId((prev) =>
                                    prev === doc.id ? null : doc.id
                                  );
                                }}
                                style={{
                                  width: "28px",
                                  height: "28px",
                                  borderRadius: "8px",
                                  border:
                                    "1px solid var(--neutral-line-separator-1)",
                                  background: "var(--neutral-surface-primary)",
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  cursor: "pointer",
                                }}
                              >
                                <MoreVerticalIcon
                                  size={14}
                                  color="var(--neutral-on-surface-secondary)"
                                />
                              </button>

                              {openDocumentMenuId === doc.id ? (
                                <>
                                  <div
                                    style={{
                                      position: "fixed",
                                      inset: 0,
                                      zIndex: 90,
                                    }}
                                    onClick={() => setOpenDocumentMenuId(null)}
                                  />
                                  <div
                                    style={{
                                      position: "fixed",
                                      top: documentMenuPosition.top,
                                      left: documentMenuPosition.left,
                                      minWidth: "180px",
                                      background:
                                        "var(--neutral-surface-primary)",
                                      border:
                                        "1px solid var(--neutral-line-separator-1)",
                                      borderRadius: "12px",
                                      boxShadow: "var(--elevation-sm)",
                                      zIndex: 9999,
                                      overflow: "hidden",
                                    }}
                                  >
                                    <div
                                      onClick={() =>
                                        handleDocumentAction(
                                          `${doc.name} downloaded`
                                        )
                                      }
                                      style={{
                                        padding: "12px 14px",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "10px",
                                        cursor: "pointer",
                                        fontSize: "var(--text-title-3)",
                                        borderTop:
                                          "1px solid var(--neutral-line-separator-1)",
                                      }}
                                    >
                                      <DownloadIcon size={16} /> Download
                                    </div>
                                    <div
                                      onClick={() =>
                                        handleDocumentAction("rename", doc.id)
                                      }
                                      style={{
                                        padding: "12px 14px",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "10px",
                                        cursor: "pointer",
                                        fontSize: "var(--text-title-3)",
                                        borderTop:
                                          "1px solid var(--neutral-line-separator-1)",
                                      }}
                                    >
                                      <EditIcon size={16} /> Edit
                                    </div>
                                    <div
                                      onClick={() =>
                                        handleDocumentAction("delete", doc.id)
                                      }
                                      style={{
                                        padding: "12px 14px",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "10px",
                                        cursor: "pointer",
                                        fontSize: "var(--text-title-3)",
                                        borderTop:
                                          "1px solid var(--neutral-line-separator-1)",
                                        color: "var(--status-red-primary)",
                                      }}
                                    >
                                      <DeleteIcon
                                        size={16}
                                        color="var(--status-red-primary)"
                                      />{" "}
                                      Delete
                                    </div>
                                  </div>
                                </>
                              ) : null}
                            </div>
                          </div>
                          <div
                            style={{
                              display: "flex",
                              flexDirection: "column",
                              gap: "6px",
                            }}
                          >
                            <span
                              style={{
                                fontSize: "var(--text-body)",
                                color: "var(--neutral-on-surface-secondary)",
                              }}
                            >
                              Document Type:{" "}
                              {getDocumentTypeLabel(doc.documentType)}
                            </span>
                            <span
                              style={{
                                fontSize: "var(--text-body)",
                                color: "var(--neutral-on-surface-secondary)",
                              }}
                            >
                              Uploaded by: {uploadedBy}
                            </span>
                            <span
                              style={{
                                fontSize: "var(--text-body)",
                                color: "var(--neutral-on-surface-secondary)",
                              }}
                            >
                              Date modified: {modifiedDate}
                            </span>
                            <span
                              style={{
                                fontSize: "var(--text-body)",
                                color: "var(--neutral-on-surface-secondary)",
                              }}
                            >
                              File size: {doc.size || "-"}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div
                    style={{
                      gridColumn: "1 / -1",
                      padding: "48px 24px",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "8px",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "var(--text-title-2)",
                        fontWeight: "var(--font-weight-bold)",
                      }}
                    >
                      No documents found
                    </span>
                    <span
                      style={{
                        fontSize: "var(--text-title-3)",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      Try changing your search or filter.
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      ) : activeTab === "receipt" ? (
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
          <div
            style={{
              background: "var(--neutral-surface-primary)",
              borderRadius: "16px",
              border: "1px solid var(--neutral-line-separator-1)",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                padding: "24px 24px 0 24px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "12px",
              }}
            >
              <span
                style={{
                  fontSize: "var(--text-title-2)",
                  fontWeight: "var(--font-weight-bold)",
                }}
              >
                Receipt
              </span>
              <Button
                variant="filled"
                onClick={handleReceiptConfirmClick}
                disabled={currentStatus !== "Issued"}
              >
                Confirm Receipt
              </Button>
            </div>
            <div
              style={{
                padding: "20px 24px 24px 24px",
                display: "flex",
                flexDirection: "column",
              }}
            >
              {currentStatus !== "Issued" ? (
                <div
                  style={{
                    marginBottom: "16px",
                    display: "flex",
                    alignItems: "flex-start",
                    gap: "12px",
                    padding: "12px 16px",
                    borderRadius: "12px",
                    background: "var(--feature-brand-container-lighter)",
                    border: "1px solid var(--feature-brand-container-darker)",
                  }}
                >
                  <Info
                    size={16}
                    strokeWidth={2.1}
                    color="var(--feature-brand-primary)"
                    style={{ flexShrink: 0, marginTop: "2px" }}
                  />
                  <span
                    style={{
                      fontSize: "var(--text-title-3)",
                      color: "var(--feature-brand-primary)",
                      lineHeight: "1.5",
                    }}
                  >
                    Receipt confirmation is only available when the purchase
                    order status is Issued.
                  </span>
                </div>
              ) : null}
              <div style={poReferenceTableFrameStyle}>
                <div style={poReferenceTableScrollerStyle}>
                  <div style={poReferenceTableInnerStyle("1260px")}>
                    <div
                      style={poReferenceTableHeaderRowStyle(
                        "84px minmax(220px, 1.5fr) minmax(180px, 1fr) minmax(220px, 1.4fr) 110px 110px 120px 180px"
                      )}
                    >
                      <div style={poReferenceTableHeaderCellStyle()}>Type</div>
                      <div style={poReferenceTableHeaderCellStyle()}>Item</div>
                      <div style={poReferenceTableHeaderCellStyle()}>SKU</div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Description
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Ordered Qty
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Received Qty
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Remaining Qty
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Receive Now
                      </div>
                    </div>
                    {receiptLines.map((line, idx) => {
                      const remainingQty = Math.max(
                        line.orderedQty - line.receivedQty,
                        0
                      );
                      const lineTypeLabel =
                        line.type === "wo"
                          ? "WO"
                          : line.type === "material"
                            ? "Material"
                            : "Manual";
                      const lineTypeVariant =
                        line.type === "wo"
                          ? "blue-light"
                          : line.type === "material"
                            ? "yellow-light"
                            : "grey-light";
                      return (
                        <div
                          key={line.id}
                          style={poReferenceTableRowStyle(
                            "84px minmax(220px, 1.5fr) minmax(180px, 1fr) minmax(220px, 1.4fr) 110px 110px 120px 180px",
                            idx === receiptLines.length - 1,
                            { minHeight: "64px" }
                          )}
                        >
                          <div style={poReferenceTableCellStyle()}>
                            <StatusBadge variant={lineTypeVariant}>
                              {lineTypeLabel}
                            </StatusBadge>
                          </div>
                          <div
                            style={poReferenceTableCellStyle({
                              minWidth: 0,
                              fontWeight: "var(--font-weight-bold)",
                            })}
                          >
                            <span
                              style={{
                                display: "block",
                                width: "100%",
                                whiteSpace: "nowrap",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                              }}
                              title={displayValue(line.item)}
                            >
                              {displayValue(line.item)}
                            </span>
                          </div>
                          <div
                            style={poReferenceTableCellStyle({ minWidth: 0 })}
                          >
                            <span
                              style={{
                                display: "block",
                                width: "100%",
                                whiteSpace: "nowrap",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                              }}
                              title={displayValue(line.code)}
                            >
                              {displayValue(line.code)}
                            </span>
                          </div>
                          <div
                            style={poReferenceTableCellStyle({
                              minWidth: 0,
                              color: "var(--neutral-on-surface-secondary)",
                            })}
                          >
                            <span
                              style={{
                                display: "block",
                                width: "100%",
                                whiteSpace: "nowrap",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                              }}
                              title={displayValue(line.desc)}
                            >
                              {displayValue(line.desc)}
                            </span>
                          </div>
                          <div style={poReferenceTableCellStyle()}>
                            {line.orderedQty}
                          </div>
                          <div style={poReferenceTableCellStyle()}>
                            {line.receivedQty}
                          </div>
                          <div style={poReferenceTableCellStyle()}>
                            {remainingQty}
                          </div>
                          <div style={poReferenceTableCellStyle()}>
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "column",
                                gap: "6px",
                                width: "100%",
                                padding: "9px 0",
                              }}
                            >
                              <input
                                type="number"
                                min="0"
                                placeholder="0"
                                value={line.receiveNow}
                                onChange={(e) =>
                                  updateReceiptLine(line.id, e.target.value)
                                }
                                style={{
                                  height: "46px",
                                  border: "1px solid transparent",
                                  background:
                                    remainingQty === 0 ||
                                      currentStatus !== "Issued"
                                      ? "var(--neutral-surface-grey-lighter)"
                                      : "var(--neutral-surface-primary)",
                                  ...inputFrameStyle(
                                    remainingQty === 0 ||
                                    currentStatus !== "Issued",
                                    !!receiptErrors[line.id]
                                  ),
                                  ...inputControlStyle(
                                    remainingQty === 0 ||
                                    currentStatus !== "Issued",
                                    !!line.receiveNow
                                  ),
                                  padding: "0 14px",
                                  cursor:
                                    currentStatus !== "Issued"
                                      ? "not-allowed"
                                      : "text",
                                }}
                                disabled={
                                  remainingQty === 0 ||
                                  currentStatus !== "Issued"
                                }
                                onFocus={(e) =>
                                  focusInputFrame(e.currentTarget)
                                }
                                onBlur={(e) =>
                                  blurInputFrame(
                                    e.currentTarget,
                                    remainingQty === 0 ||
                                    currentStatus !== "Issued",
                                    !!receiptErrors[line.id]
                                  )
                                }
                              />
                              {receiptErrors[line.id] ? (
                                <span
                                  style={{
                                    fontSize: "var(--text-body)",
                                    color: "var(--status-red-primary)",
                                  }}
                                >
                                  {receiptErrors[line.id]}
                                </span>
                              ) : null}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
              {receiptErrors._global ? (
                <span
                  style={{
                    marginTop: "12px",
                    fontSize: "var(--text-body)",
                    color: "var(--status-red-primary)",
                  }}
                >
                  {receiptErrors._global}
                </span>
              ) : null}
            </div>
          </div>

          <div
            style={{
              background: "var(--neutral-surface-primary)",
              borderRadius: "16px",
              border: "1px solid var(--neutral-line-separator-1)",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                padding: "24px 24px 0 24px",
                display: "flex",
                alignItems: "center",
              }}
            >
              <span
                style={{
                  fontSize: "var(--text-title-2)",
                  fontWeight: "var(--font-weight-bold)",
                }}
              >
                Receipt Logs
              </span>
            </div>
            <div
              style={{
                padding: "20px 24px 24px 24px",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <div style={poReferenceTableFrameStyle}>
                <div style={poReferenceTableScrollerStyle}>
                  <div style={poReferenceTableInnerStyle("1260px")}>
                    <div
                      style={poReferenceTableHeaderRowStyle(
                        "1.2fr 1fr 1.4fr 1fr 1.3fr 1.1fr 1.6fr"
                      )}
                    >
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Receipt Date & Time
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Receipt Number
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Item Name
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        SKU / Code
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Received Qty
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Received By
                      </div>
                      <div style={poReferenceTableHeaderCellStyle()}>
                        Proof Document
                      </div>
                    </div>
                    {groupedReceiptLogs.length > 0 ? (
                      groupedReceiptLogs.map((log, idx) => (
                        <div
                          key={log.id}
                          style={poReferenceTableRowStyle(
                            "1.2fr 1fr 1.4fr 1fr 1.3fr 1.1fr 1.6fr",
                            idx === groupedReceiptLogs.length - 1,
                            { alignItems: "start" }
                          )}
                        >
                          <div
                            style={poReferenceTableCellStyle({
                              alignItems: "flex-start",
                              padding: "12px 0",
                            })}
                          >
                            {log.date} · {log.time}
                          </div>
                          <div
                            style={poReferenceTableCellStyle({
                              alignItems: "flex-start",
                              padding: "12px 0",
                            })}
                          >
                            {log.receiptNumber || "-"}
                          </div>
                          <div
                            style={poReferenceTableCellStyle({
                              alignItems: "flex-start",
                              padding: "12px 0",
                              flexDirection: "column",
                              gap: "10px",
                            })}
                          >
                            {(log.items || []).map((item, itemIndex) => (
                              <span
                                key={`${log.id}-item-${item.id || itemIndex}`}
                                style={{
                                  fontSize: "var(--text-title-3)",
                                  lineHeight: "20px",
                                  letterSpacing: "0.09625px",
                                  fontWeight: "var(--font-weight-bold)",
                                  color: "var(--neutral-on-surface-primary)",
                                }}
                              >
                                {item.item || "-"}
                              </span>
                            ))}
                          </div>
                          <div
                            style={poReferenceTableCellStyle({
                              alignItems: "flex-start",
                              padding: "12px 0",
                              flexDirection: "column",
                              gap: "10px",
                            })}
                          >
                            {(log.items || []).map((item, itemIndex) => (
                              <span
                                key={`${log.id}-code-${item.id || itemIndex}`}
                                style={{
                                  fontSize: "var(--text-title-3)",
                                  lineHeight: "20px",
                                  letterSpacing: "0.09625px",
                                  color: "var(--neutral-on-surface-primary)",
                                }}
                              >
                                {item.code || "-"}
                              </span>
                            ))}
                          </div>
                          <div
                            style={poReferenceTableCellStyle({
                              alignItems: "flex-start",
                              padding: "12px 0",
                              flexDirection: "column",
                              gap: "10px",
                            })}
                          >
                            {(log.items || []).map((item, itemIndex) => (
                              <span
                                key={`${log.id}-qty-${item.id || itemIndex}`}
                                style={{
                                  fontSize: "var(--text-title-3)",
                                  lineHeight: "20px",
                                  letterSpacing: "0.09625px",
                                  color: "var(--neutral-on-surface-primary)",
                                }}
                              >
                                {item.receivedNow || 0} pcs
                              </span>
                            ))}
                          </div>
                          <div
                            style={poReferenceTableCellStyle({
                              alignItems: "flex-start",
                              padding: "12px 0",
                            })}
                          >
                            {log.receivedBy || "-"}
                          </div>
                          <div
                            style={poReferenceTableCellStyle({
                              alignItems: "flex-start",
                              padding: "12px 0",
                            })}
                          >
                            <ProofDocumentList
                              documents={
                                log.proofDocuments ||
                                log.attachments ||
                                normalizeProofDocuments([], log.proof)
                              }
                              onDocumentClick={(doc) => {
                                setDocumentToastMessage(
                                  `${doc?.name || "Document"} opened`
                                );
                                setShowDocumentToast(true);
                                setTimeout(
                                  () => setShowDocumentToast(false),
                                  4000
                                );
                              }}
                            />
                          </div>
                        </div>
                      ))
                    ) : (
                      <div style={poReferenceTableEmptyStateStyle}>
                        No receipt history yet.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : activeTab === "logs" ? (
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
          {approvalEnabled ? (
            <div
              style={{
                background: "var(--neutral-surface-primary)",
                borderRadius: "16px",
                border: "1px solid var(--neutral-line-separator-1)",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  padding: "24px 24px 0 24px",
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-1)",
                    fontWeight: "var(--font-weight-bold)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  Approval Logs
                </span>
              </div>
              <div style={{ padding: "24px" }}>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: "24px",
                    marginBottom: "28px",
                  }}
                >
                  <LabelValue label="Requested By" value={requestedBy} />
                  <LabelValue label="Requested At" value={requestedAt} />
                </div>

                <div style={{ display: "flex", flexDirection: "column" }}>
                  <div
                    style={{
                      display: "flex",
                      paddingBottom: "12px",
                      borderBottom: "1px solid var(--neutral-line-separator-1)",
                      fontWeight: "var(--font-weight-bold)",
                      fontSize: "var(--text-title-3)",
                      color: "var(--neutral-on-surface-primary)",
                    }}
                  >
                    <div style={{ flex: "1.1" }}>Approvers</div>
                    <div style={{ width: "140px" }}>Status</div>
                    <div style={{ flex: "2.4" }}>Comments</div>
                  </div>
                  {approverList.map((approver, idx) => {
                    const rowStatus = getApprovalRowStatus();
                    const showApproved =
                      currentStatus === "Issued" ||
                      currentStatus === "Completed";
                    const showRejected = currentStatus === "Canceled";
                    const showPending = !showApproved && !showRejected;
                    const thisStatus =
                      idx === 0
                        ? rowStatus
                        : { text: "Pending", variant: "grey-light" };
                    const thisComment =
                      idx === 0 ? getApprovalRowComment() : "-";
                    return (
                      <div
                        key={approver.id || idx}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          padding: "18px 0 10px 0",
                          fontSize: "var(--text-title-3)",
                          borderBottom:
                            idx === approverList.length - 1
                              ? "none"
                              : "1px solid var(--neutral-line-separator-1)",
                        }}
                      >
                        <div
                          style={{
                            flex: "1.1",
                            color: "var(--neutral-on-surface-primary)",
                          }}
                        >
                          {approver.name}
                        </div>
                        <div style={{ width: "140px" }}>
                          <StatusBadge variant={thisStatus.variant}>
                            {thisStatus.text}
                          </StatusBadge>
                        </div>
                        <div
                          style={{
                            flex: "2.4",
                            color: "var(--neutral-on-surface-secondary)",
                            lineHeight: "1.5",
                          }}
                        >
                          {thisComment}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : null}

          <div
            style={{
              background: "var(--neutral-surface-primary)",
              borderRadius: "16px",
              border: "1px solid var(--neutral-line-separator-1)",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                padding: "24px 24px 0 24px",
                display: "flex",
                alignItems: "center",
              }}
            >
              <span
                style={{
                  fontSize: "var(--text-title-1)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--neutral-on-surface-primary)",
                }}
              >
                Activity Logs
              </span>
            </div>
            <div style={{ padding: "24px" }}>
              <div style={{ display: "flex", flexDirection: "column" }}>
                <div
                  style={{
                    display: "flex",
                    paddingBottom: "12px",
                    borderBottom: "1px solid var(--neutral-line-separator-1)",
                    fontWeight: "var(--font-weight-bold)",
                    fontSize: "var(--text-title-3)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  <div style={{ flex: "1.1" }}>Name</div>
                  <div style={{ flex: "1.9" }}>Email</div>
                  <div style={{ flex: "2.8" }}>Activity</div>
                  <div style={{ width: "190px" }}>Timestamp</div>
                </div>

                {dynamicActivityLogs.map((log, idx, arr) => (
                  <div
                    key={idx}
                    style={{
                      display: "flex",
                      alignItems: "flex-start",
                      padding: "16px 0",
                      borderBottom:
                        idx === arr.length - 1
                          ? "none"
                          : "1px solid var(--neutral-line-separator-1)",
                      fontSize: "var(--text-title-3)",
                    }}
                  >
                    <div
                      style={{
                        flex: "1.1",
                        color: "var(--neutral-on-surface-primary)",
                      }}
                    >
                      {log.name}
                    </div>
                    <div
                      style={{
                        flex: "1.9",
                        color: "var(--neutral-on-surface-primary)",
                      }}
                    >
                      {log.email}
                    </div>
                    <div
                      style={{
                        flex: "2.8",
                        display: "flex",
                        flexDirection: "column",
                        gap: log.desc ? "6px" : "0",
                      }}
                    >
                      <span
                        style={{
                          fontWeight: "var(--font-weight-bold)",
                          color: "var(--neutral-on-surface-primary)",
                        }}
                      >
                        {log.title}
                      </span>
                      {log.desc ? (
                        <span
                          style={{
                            color: "var(--neutral-on-surface-secondary)",
                            lineHeight: "1.5",
                          }}
                        >
                          {log.desc}
                        </span>
                      ) : null}
                    </div>
                    <div
                      style={{
                        width: "190px",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      {log.timestamp}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <Card
          style={{
            padding: "32px",
            alignItems: "center",
            justifyContent: "center",
            minHeight: "260px",
          }}
        >
          <span
            style={{
              fontSize: "var(--text-title-2)",
              fontWeight: "var(--font-weight-bold)",
              color: "var(--neutral-on-surface-primary)",
            }}
          >
            {activeTab === "receipt" ? "Receipt" : "Documents"}
          </span>
          <span
            style={{
              fontSize: "var(--text-title-3)",
              color: "var(--neutral-on-surface-secondary)",
            }}
          >
            Content for this tab will be added next.
          </span>
        </Card>
      )}

      {showFooterSubmit || showFooterApprovalActions || showFooterIssuedCancel ? (
        <div
          style={{
            position: "fixed",
            bottom: 0,
            left: isSidebarCollapsed ? "82px" : "286px",
            transition: "left 0.2s ease",
            right: 0,
            background: "var(--neutral-surface-primary)",
            borderTop: "1px solid var(--neutral-line-separator-1)",
            padding: "12px 24px",
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "center",
            zIndex: 100,
          }}
        >
          <div style={{ display: "flex", gap: "16px" }}>
            {showFooterSubmit ? (
              <Button
                size="medium"
                variant="filled"
                onClick={handleDetailSubmitClick}
              >
                Submit PO
              </Button>
            ) : null}
            {showFooterApprovalActions ? (
              <>
                <Button
                  size="medium"
                  variant="danger"
                  onClick={() => openDecisionModal("cancel")}
                >
                  Cancel PO
                </Button>
                <Button
                  size="medium"
                  variant="outlined"
                  onClick={() => openDecisionModal("revision")}
                >
                  Ask for Revision
                </Button>
                <Button
                  size="medium"
                  variant="filled"
                  onClick={() => openDecisionModal("approve")}
                >
                  Approve
                </Button>
              </>
            ) : null}
            {showFooterIssuedCancel ? (
              <Button
                size="medium"
                variant="danger"
                onClick={() => openDecisionModal("cancel")}
              >
                Cancel PO
              </Button>
            ) : null}
          </div>
        </div>
      ) : null}

      {showSubmitGuardModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "440px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setShowSubmitGuardModal(false)}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />
            <h2
              style={{
                margin: "0",
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Complete Required Information
            </h2>
            <p
              style={{
                margin: 0,
                textAlign: "center",
                fontSize: "var(--text-title-3)",
                color: "var(--neutral-on-surface-secondary)",
                lineHeight: "1.6",
              }}
            >
              Please fill in the required information below before submitting
              this purchase order.
            </p>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "10px",
                background: "var(--neutral-surface-grey-lighter)",
                borderRadius: "12px",
                padding: "16px",
              }}
            >
              {validateDetailRequiredInfo().map((item) => (
                <div
                  key={item}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    fontSize: "var(--text-title-3)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  <div
                    style={{
                      width: "6px",
                      height: "6px",
                      borderRadius: "50%",
                      background: "var(--status-red-primary)",
                      flexShrink: 0,
                    }}
                  />
                  <span>{item}</span>
                </div>
              ))}
            </div>
            <Button
              size="large"
              style={{ width: "100%" }}
              onClick={() => setShowSubmitGuardModal(false)}
            >
              Okay
            </Button>
          </div>
        </div>
      ) : null}

      {showDetailSubmitConfirmModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "376px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "28px 22px 22px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setShowDetailSubmitConfirmModal(false)}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />
            <h2
              style={{
                margin: "20px 0 0 0",
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Submit PO?
            </h2>
            <p
              style={{
                margin: 0,
                textAlign: "center",
                fontSize: "var(--text-title-3)",
                color: "var(--neutral-on-surface-secondary)",
                lineHeight: "1.6",
              }}
            >
              {poApprovalSettings?.isApprovalActive
                ? "This PO will be submitted for approval."
                : "This PO will be automatically approved upon submission."}
            </p>
            <div
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <Button
                size="large"
                style={{ width: "100%" }}
                onClick={handleConfirmDetailSubmit}
              >
                Yes, Submit
              </Button>
              <Button
                variant="outlined"
                size="large"
                style={{ width: "100%" }}
                onClick={() => setShowDetailSubmitConfirmModal(false)}
              >
                Keep Editing
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {showUploadDocumentModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "640px",
              maxHeight: "calc(100vh - 64px)",
              overflowY: "auto",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "24px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => {
                setShowUploadDocumentModal(false);
                resetDocumentUploadState();
              }}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />

            <h2
              style={{
                margin: "0",
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              Upload Document
            </h2>

            <div
              style={{ display: "flex", flexDirection: "column", gap: "8px" }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "2px",
                  fontSize: "var(--text-body)",
                  fontWeight: "var(--font-weight-regular)",
                }}
              >
                <span style={{ color: "var(--status-red-primary)" }}>*</span>
                <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                  Document Type
                </span>
              </div>
              <DropdownSelect
                value={documentUploadDocumentType}
                onChange={(nextValue) => setDocumentUploadDocumentType(nextValue)}
                options={[
                  { value: "invoice", label: "Invoice" },
                  { value: "delivery_note", label: "Delivery Note" },
                  { value: "packing_list", label: "Packing List" },
                  { value: "quotation_vendor", label: "Quotation (Vendor)" },
                  {
                    value: "contract_agreement",
                    label: "Contract / Agreement",
                  },
                  { value: "other", label: "Other" },
                ]}
                borderRadius="12px"
              />
            </div>

            <InputField
              label="Description"
              placeholder="Enter File Description"
              value={documentUploadDescription}
              onChange={(e) => setDocumentUploadDescription(e.target.value)}
            />

            <div
              style={{ display: "flex", flexDirection: "column", gap: "8px" }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "2px",
                  fontSize: "var(--text-body)",
                  fontWeight: "var(--font-weight-regular)",
                }}
              >
                <span style={{ color: "var(--status-red-primary)" }}>*</span>
                <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                  Upload File
                </span>
              </div>
              <UploadDropzone
                maxFiles={1}
                multiple={false}
                error={documentUploadError}
                onFilesSelected={handleDocumentUploadFileSelection}
              />
              {documentUploadFileName ? (
                <UploadDescriptionCard
                  file={{
                    name: documentUploadFileName,
                    description: documentUploadDescription,
                  }}
                  hideDescriptionField
                  onRemove={() => resetDocumentUploadState()}
                />
              ) : null}
              {documentUploadError ? (
                <span
                  style={{
                    fontSize: "var(--text-body)",
                    color: "var(--status-red-primary)",
                  }}
                >
                  {documentUploadError}
                </span>
              ) : null}
            </div>

            <div style={{ display: "flex", gap: "12px" }}>
              <Button
                variant="outlined"
                size="large"
                style={{ flex: 1 }}
                onClick={() => {
                  setShowUploadDocumentModal(false);
                  resetDocumentUploadState();
                }}
              >
                Cancel
              </Button>
              <Button
                variant="filled"
                size="large"
                style={{ flex: 1 }}
                disabled={!documentUploadFileName || !!documentUploadError}
                onClick={handleUploadDocument}
              >
                Upload
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {showConfirmReceiptModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "680px",
              maxHeight: "calc(100vh - 64px)",
              overflowY: "auto",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "24px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => {
                setShowConfirmReceiptModal(false);
                setReceiptProofDocuments([]);
                setReceiptProofUploadError("");
                setReceiptProofDescriptionErrors({});
                setReceiptNotes("");
              }}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />
            <h2
              style={{
                margin: "0",
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              Confirm Receipt
            </h2>
            <div
              style={{ display: "flex", flexDirection: "column", gap: "8px" }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "2px",
                  fontSize: "var(--text-body)",
                  fontWeight: "var(--font-weight-regular)",
                }}
              >
                <span style={{ color: "var(--status-red-primary)" }}>*</span>
                <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                  Received By
                </span>
              </div>
              <input
                type="text"
                value={receiptReceivedBy}
                onChange={(e) => setReceiptReceivedBy(e.target.value)}
                placeholder="Enter receiver name"
                style={{
                  height: "48px",
                  border: "1px solid var(--neutral-line-separator-1)",
                  borderRadius: "8px",
                  padding: "0 16px",
                  background: "var(--neutral-surface-primary)",
                  fontSize: "var(--text-subtitle-1)",
                  color: "var(--neutral-on-surface-primary)",
                  width: "100%",
                  outline: "none",
                  fontFamily: "Lato, sans-serif",
                }}
              />
            </div>
            <InputField
              label="Notes"
              multiline
              placeholder="Add note for this receipt"
              value={receiptNotes}
              onChange={(e) => setReceiptNotes(e.target.value)}
            />
            <div
              style={{ display: "flex", flexDirection: "column", gap: "8px" }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "2px",
                  fontSize: "var(--text-body)",
                  fontWeight: "var(--font-weight-regular)",
                }}
              >
                <span style={{ color: "var(--status-red-primary)" }}>*</span>
                <span style={{ color: "var(--neutral-on-surface-primary)" }}>
                  Upload Proof Document
                </span>
              </div>
              <UploadDropzone
                maxFiles={MAX_PROOF_UPLOAD_FILES}
                multiple
                error={receiptProofUploadError}
                onFilesSelected={handleReceiptProofFilesSelected}
              />
              {receiptProofDocuments.length > 0 ? (
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "16px",
                  }}
                >
                  {receiptProofDocuments.map((doc) => (
                    <UploadDescriptionCard
                      key={doc.id}
                      file={doc}
                      descriptionRequired
                      descriptionError={receiptProofDescriptionErrors[doc.id]}
                      onDescriptionChange={(value) =>
                        updateReceiptProofDescription(doc.id, value)
                      }
                      onRemove={() => removeReceiptProofDocument(doc.id)}
                    />
                  ))}
                </div>
              ) : null}
              {receiptProofUploadError ? (
                <span
                  style={{
                    fontSize: "var(--text-body)",
                    color: "var(--status-red-primary)",
                  }}
                >
                  {receiptProofUploadError}
                </span>
              ) : null}
            </div>
            <div style={{ display: "flex", gap: "12px" }}>
              <Button
                variant="outlined"
                size="large"
                style={{ flex: 1 }}
                onClick={() => {
                  setShowConfirmReceiptModal(false);
                  setReceiptProofDocuments([]);
                  setReceiptProofUploadError("");
                  setReceiptProofDescriptionErrors({});
                  setReceiptNotes("");
                }}
              >
                Cancel
              </Button>
              <Button
                variant="filled"
                size="large"
                style={{ flex: 1 }}
                disabled={
                  receiptProofDocuments.length === 0 ||
                  !receiptReceivedBy.trim() ||
                  receiptProofDocuments.some(
                    (doc) => !(doc.description || "").trim()
                  )
                }
                onClick={handleSubmitReceipt}
              >
                Submit
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {showRenameDocumentModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "420px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "var(--radius-card)",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => {
                setShowRenameDocumentModal(false);
                setSelectedDocumentId(null);
                setRenameDocumentValue("");
              }}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />
            <h2
              style={{
                margin: 0,
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              Edit Document
            </h2>
            <div
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <div
                style={{ display: "flex", flexDirection: "column", gap: "8px" }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-3)",
                    fontWeight: "var(--font-weight-bold)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  Document Name
                </span>
                <input
                  type="text"
                  value={renameDocumentValue}
                  onChange={(e) => setRenameDocumentValue(e.target.value)}
                  placeholder="Enter document name"
                  style={{
                    height: "48px",
                    border: "1px solid var(--neutral-line-separator-1)",
                    borderRadius: "12px",
                    padding: "0 16px",
                    background: "var(--neutral-surface-primary)",
                    fontSize: "var(--text-subtitle-1)",
                    color: "var(--neutral-on-surface-primary)",
                    width: "100%",
                    outline: "none",
                    fontFamily: "Lato, sans-serif",
                  }}
                />
              </div>
              <div
                style={{ display: "flex", flexDirection: "column", gap: "8px" }}
              >
                <span
                  style={{
                    fontSize: "var(--text-title-3)",
                    fontWeight: "var(--font-weight-bold)",
                    color: "var(--neutral-on-surface-primary)",
                  }}
                >
                  Document Type
                </span>
                <DropdownSelect
                  value={editDocumentTypeValue}
                  onChange={(nextValue) => setEditDocumentTypeValue(nextValue)}
                  options={[
                    { value: "invoice", label: "Invoice" },
                    { value: "delivery_note", label: "Delivery Note" },
                    { value: "packing_list", label: "Packing List" },
                    { value: "quotation_vendor", label: "Quotation (Vendor)" },
                    {
                      value: "contract_agreement",
                      label: "Contract / Agreement",
                    },
                    { value: "other", label: "Other" },
                  ]}
                  borderRadius="12px"
                />
              </div>
            </div>
            <div style={{ display: "flex", gap: "12px" }}>
              <Button
                variant="outlined"
                size="large"
                style={{ flex: 1 }}
                onClick={() => {
                  setShowRenameDocumentModal(false);
                  setSelectedDocumentId(null);
                  setRenameDocumentValue("");
                }}
              >
                Cancel
              </Button>
              <Button
                variant="filled"
                size="large"
                style={{ flex: 1 }}
                disabled={!renameDocumentValue.trim()}
                onClick={handleConfirmRenameDocument}
              >
                Save
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {showDeleteDocumentModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "400px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "28px 22px 22px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => {
                setShowDeleteDocumentModal(false);
                setSelectedDocumentId(null);
                setRenameDocumentValue("");
              }}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />
            <h2
              style={{
                margin: "20px 0 0 0",
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Delete Document?
            </h2>
            <p
              style={{
                margin: 0,
                textAlign: "center",
                fontSize: "var(--text-title-3)",
                color: "var(--neutral-on-surface-secondary)",
                lineHeight: "1.6",
              }}
            >
              This document will be permanently removed from the purchase order.
            </p>
            <div
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <Button
                variant="danger"
                size="large"
                style={{ width: "100%" }}
                onClick={handleConfirmDeleteDocument}
              >
                Yes, Delete
              </Button>
              <Button
                variant="outlined"
                size="large"
                style={{ width: "100%" }}
                onClick={() => {
                  setShowDeleteDocumentModal(false);
                  setSelectedDocumentId(null);
                  setRenameDocumentValue("");
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {isDecisionModalOpen
        ? (() => {
          const meta = getDecisionMeta();
          return (
            <div
              style={{
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background: "rgba(0, 0, 0, 0.5)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 1000,
              }}
            >
              <div
                style={{
                  width: "460px",
                  background: "var(--neutral-surface-primary)",
                  borderRadius: "var(--radius-card)",
                  padding: "24px",
                  display: "flex",
                  flexDirection: "column",
                  gap: "20px",
                  position: "relative",
                  boxShadow: "var(--elevation-sm)",
                }}
              >
                <div
                  style={{
                    position: "relative",
                    minHeight: "40px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <IconButton
                    icon={CloseIcon}
                    size="large"
                    onClick={() => {
                      setIsDecisionModalOpen(false);
                      setDecisionError("");
                    }}
                    style={{ position: "absolute", top: "-8px", right: 0 }}
                    color="var(--neutral-on-surface-tertiary)"
                  />
                  <h2
                    style={{
                      margin: "0",
                      fontSize: "var(--text-headline)",
                      fontWeight: "var(--font-weight-bold)",
                      color: "var(--neutral-on-surface-primary)",
                      textAlign: "center",
                    }}
                  >
                    {meta.title}
                  </h2>
                </div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                      }}
                    >
                      {meta.mandatory ? (
                        <span
                          style={{
                            color: "var(--status-red-primary)",
                            fontSize: "var(--text-body)",
                          }}
                        >
                          *
                        </span>
                      ) : null}
                      <span
                        style={{
                          fontSize: "var(--text-title-3)",
                          fontWeight: "var(--font-weight-bold)",
                          color: "var(--neutral-on-surface-primary)",
                        }}
                      >
                        Comment
                      </span>
                    </div>
                    <span
                      style={{
                        fontSize: "var(--text-desc)",
                        color: "var(--neutral-on-surface-tertiary)",
                      }}
                    >
                      {decisionComment.length}/400
                    </span>
                  </div>
                  <textarea
                    value={decisionComment}
                    maxLength={400}
                    onChange={(e) => {
                      setDecisionComment(e.target.value);
                      if (decisionError) setDecisionError("");
                    }}
                    placeholder={meta.helper}
                    style={{
                      minHeight: "120px",
                      border: decisionError
                        ? "1px solid var(--status-red-primary)"
                        : "1px solid var(--neutral-line-separator-2)",
                      borderRadius: "12px",
                      padding: "12px 16px",
                      background: "var(--neutral-surface-primary)",
                      fontSize: "var(--text-subtitle-1)",
                      color: "var(--neutral-on-surface-primary)",
                      width: "100%",
                      outline: "none",
                      fontFamily: "Lato, sans-serif",
                      resize: "vertical",
                      boxSizing: "border-box",
                    }}
                  />
                  {decisionError ? (
                    <span
                      style={{
                        fontSize: "var(--text-body)",
                        color: "var(--status-red-primary)",
                      }}
                    >
                      {decisionError}
                    </span>
                  ) : null}
                </div>
                <div style={{ display: "flex", gap: "12px" }}>
                  <Button
                    variant="outlined"
                    size="large"
                    style={{ flex: 1 }}
                    onClick={() => {
                      setIsDecisionModalOpen(false);
                      setDecisionError("");
                    }}
                  >
                    Back
                  </Button>
                  <Button
                    variant="filled"
                    size="large"
                    style={{ flex: 1 }}
                    onClick={handleSubmitDecision}
                  >
                    Submit
                  </Button>
                </div>
              </div>
            </div>
          );
        })()
        : null}
    </div>
  );
};

const PurchaseOrderCreate = ({
  onNavigate,
  isSidebarCollapsed,
  initialData,
  poApprovalSettings,
}) => {
  const scrollToTop = () => {
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "auto" });
    }
  };

  const navigateWithReset = (cb, ...args) => {
    scrollToTop();
    cb(...args);
  };
  const pageTopRef = useRef(null);
  const navigateBackWithoutPrompt = () => {
    if (initialData?.source === "work_order_vendor_assignment") {
      if (initialData?.returnTo) {
        onNavigate(
          initialData.returnTo.view || "detail",
          initialData.returnTo.data
        );
        return;
      }
      onNavigate("list");
      return;
    }
    if (
      initialData?.source === "edit_purchase_order" &&
      initialData?.poNumber
    ) {
      onNavigate("po_detail", {
        ...buildPoPayload("Draft", "grey-light"),
        poNumber: initialData.poNumber,
      });
      return;
    }
    onNavigate("list");
  };

  const handleBackNavigation = () => {
    if (isFormDirty) {
      setShowDiscardChangesModal(true);
      return;
    }
    navigateBackWithoutPrompt();
  };

  const isFromWorkOrderAssignment =
    initialData?.source === "work_order_vendor_assignment";
  const isEditMode = initialData?.source === "edit_purchase_order";
  const editFormData = initialData?.formData || null;
  const prefilledVendor = initialData?.vendorData || null;
  const linkedWorkOrder =
    initialData?.workOrder ||
    (initialData?.returnTo?.data
      ? {
        wo: initialData.returnTo.data.wo,
        product: initialData.returnTo.data.product,
        sku: initialData.returnTo.data.sku,
        image: initialData.returnTo.data.image || "",
      }
      : null);
  const linkedOutsourceSteps =
    initialData?.outsourceSteps ||
    initialData?.returnTo?.data?.outsourceSteps ||
    [];
  const linkedRoutingStages =
    initialData?.routingStages ||
    initialData?.returnTo?.data?.routingStages ||
    [];
  const buildLinkedWorkOrderDescription = (
    workOrderNo,
    steps = [],
    stageRows = []
  ) => {
    const normalizedSteps = Array.from(
      new Set(
        (steps || [])
          .map((step) => Number(step))
          .filter((step) => Number.isFinite(step))
      )
    ).sort((a, b) => a - b);
    const baseDescription = `Generated from ${workOrderNo || "work order"}`;
    if (normalizedSteps.length === 0) return baseDescription;
    const stageLabels = normalizedSteps.map((step) => {
      const matchedStage = (stageRows || []).find(
        (stage) => Number(stage.step) === step
      );
      const operationName = matchedStage?.op || matchedStage?.operation;
      return operationName ? `[${operationName}]` : `[routing step ${step}]`;
    });
    return `${baseDescription} including ${stageLabels.join(", ")}`;
  };
  const generatedWorkOrderDescription = buildLinkedWorkOrderDescription(
    linkedWorkOrder?.wo,
    linkedOutsourceSteps,
    linkedRoutingStages
  );
  const getWorkOrderSourceId = (line) =>
    line?.sourceWorkOrderLineId || line?.id || "";
  const linkedAssignedOutput =
    parseInt(
      initialData?.assignedOutput ||
      editFormData?.lines?.find((line) => line.type === "wo")?.qty ||
      0,
      10
    ) || 0;

  const [vendorSearch, setVendorSearch] = useState(
    editFormData?.vendorName || prefilledVendor?.name || ""
  );
  const [vendorDetails, setVendorDetails] = useState({
    phone: editFormData?.vendorDetails?.phone || prefilledVendor?.phone || "",
    email: editFormData?.vendorDetails?.email || prefilledVendor?.email || "",
    address:
      editFormData?.vendorDetails?.address || prefilledVendor?.address || "",
  });
  const [isVendorLocked, setIsVendorLocked] = useState(
    !!prefilledVendor && isFromWorkOrderAssignment
  );
  const [showVendorSuggestions, setShowVendorSuggestions] = useState(false);
  const [isVendorFieldFocused, setIsVendorFieldFocused] = useState(false);
  const [productModalImages, setProductModalImages] = useState([]);
  const [shipToInfo, setShipToInfo] = useState(
    editFormData?.shipTo || {
      name: "",
      phone: "",
      email: "",
      address: "",
    }
  );
  const [poDate, setPoDate] = useState(
    editFormData?.poDate ||
    initialData?.createdDate ||
    new Date().toISOString().split("T")[0]
  );
  const [deliveryDate, setDeliveryDate] = useState(
    editFormData?.deliveryDate || initialData?.expectedDeliveryDate || ""
  );
  const [currency, setCurrency] = useState(editFormData?.currency || "IDR");
  const [notes, setNotes] = useState(editFormData?.notes || "");
  const [terms, setTerms] = useState(editFormData?.terms || "");
  const [tax, setTax] = useState(String(editFormData?.tax ?? 11));
  const [feeLines, setFeeLines] = useState(
    editFormData?.feeLines?.length
      ? editFormData.feeLines
      : [{ id: "fee-1", name: "", amount: "" }]
  );
  const [formErrors, setFormErrors] = useState({});
  const [showEmptyDraftModal, setShowEmptyDraftModal] = useState(false);
  const [showSubmitConfirmModal, setShowSubmitConfirmModal] = useState(false);
  const [showDiscardChangesModal, setShowDiscardChangesModal] = useState(false);
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [productLineType, setProductLineType] = useState("manual");
  const [productModalForm, setProductModalForm] = useState({
    manualName: "",
    manualCode: "",
    manualDesc: "",
    manualQty: "",
    manualPrice: "",
    selectedWorkOrderLineId: "",
    selectedMaterialLineId: "",
  });
  const [productModalFieldErrors, setProductModalFieldErrors] = useState({});
  const [productModalError, setProductModalError] = useState("");
  const [editingLineId, setEditingLineId] = useState(null);

  const [lines, setLines] = useState(() => {
    if (editFormData?.lines?.length) return editFormData.lines;
    if (isFromWorkOrderAssignment) {
      return [
        {
          id: 1,
          type: "wo",
          item: linkedWorkOrder?.product || "Cabinet Premium",
          code: linkedWorkOrder?.sku || "-",
          desc: generatedWorkOrderDescription,
          qty: linkedAssignedOutput,
          price: 250000,
          woRef: linkedWorkOrder?.wo || "-",
          lockedFromWorkOrder: true,
          sourceWorkOrderLineId: "generated-work-order-line",
        },
      ];
    }
    return [];
  });

  const editingLine = editingLineId
    ? lines.find((line) => line.id === editingLineId) || null
    : null;
  const isEditingLockedWorkOrderLine = !!editingLine?.lockedFromWorkOrder;

  const vendorSuggestions = MOCK_VENDORS.filter((vendor) =>
    vendor.name.toLowerCase().includes(vendorSearch.toLowerCase())
  );
  const vendorHasExactMatch = MOCK_VENDORS.some(
    (vendor) => vendor.name.toLowerCase() === vendorSearch.trim().toLowerCase()
  );
  const selectedVendorRecord =
    MOCK_VENDORS.find(
      (vendor) =>
        vendor.name.toLowerCase() === vendorSearch.trim().toLowerCase()
    ) ||
    prefilledVendor ||
    null;
  const hasLinkedWorkOrder = !!(
    linkedWorkOrder?.wo || linkedWorkOrder?.product
  );
  const generatedWorkOrderLine = hasLinkedWorkOrder
    ? {
      id: "generated-work-order-line",
      sourceWorkOrderLineId: "generated-work-order-line",
      vendorId:
        selectedVendorRecord?.id || prefilledVendor?.id || "generated-vendor",
      item: linkedWorkOrder?.product || "Cabinet Premium",
      code: linkedWorkOrder?.sku || "-",
      desc: generatedWorkOrderDescription,
      woRef: linkedWorkOrder?.wo || "-",
      qty: linkedAssignedOutput,
      price: 250000,
      image: linkedWorkOrder?.image || "work_order_product_reference.png",
    }
    : null;
  const vendorSpecificWorkOrderLines = selectedVendorRecord
    ? MOCK_WO_LINES.filter((line) => line.vendorId === selectedVendorRecord.id)
    : [];
  const preservedWorkOrderLines = lines
    .filter((line) => line.type === "wo")
    .map((line) => ({
      ...line,
      sourceWorkOrderLineId: getWorkOrderSourceId(line),
      vendorId:
        selectedVendorRecord?.id || prefilledVendor?.id || "preserved-vendor",
      image:
        line.image ||
        linkedWorkOrder?.image ||
        "work_order_product_reference.png",
    }));
  const availableWorkOrderLines = [];
  [
    ...(generatedWorkOrderLine ? [generatedWorkOrderLine] : []),
    ...vendorSpecificWorkOrderLines,
    ...preservedWorkOrderLines,
  ].forEach((line) => {
    const sourceId = getWorkOrderSourceId(line);
    if (
      !sourceId ||
      availableWorkOrderLines.some(
        (entry) => getWorkOrderSourceId(entry) === sourceId
      )
    )
      return;
    availableWorkOrderLines.push({
      ...line,
      sourceWorkOrderLineId: sourceId,
    });
  });
  const availableMaterialLines = MOCK_MATERIAL_LINES;

  const subtotal = lines.reduce(
    (acc, line) =>
      acc + (parseFloat(line.qty) || 0) * (parseFloat(line.price) || 0),
    0
  );
  const hasPrefilledDraftContent =
    isFromWorkOrderAssignment &&
    (!!vendorSearch.trim() ||
      !!deliveryDate ||
      !!poDate ||
      lines.length > 0 ||
      !!vendorDetails.phone.trim() ||
      !!vendorDetails.email.trim() ||
      !!vendorDetails.address.trim());
  const taxAmount = subtotal * ((parseFloat(tax) || 0) / 100);
  const activeFeeLines = feeLines.filter(
    (fee) => fee.name.trim() || (parseFloat(fee.amount) || 0) > 0
  );
  const feesAmount = feeLines.reduce(
    (acc, fee) => acc + (parseFloat(fee.amount) || 0),
    0
  );
  const total = subtotal + taxAmount + feesAmount;

  const buildFormDirtySnapshot = () => ({
    vendorSearch: vendorSearch.trim(),
    vendorDetails: {
      phone: vendorDetails.phone.trim(),
      email: vendorDetails.email.trim(),
      address: vendorDetails.address.trim(),
    },
    shipToInfo: {
      name: shipToInfo.name.trim(),
      phone: shipToInfo.phone.trim(),
      email: shipToInfo.email.trim(),
      address: shipToInfo.address.trim(),
    },
    poDate: poDate || "",
    deliveryDate: deliveryDate || "",
    currency: currency || "",
    notes: notes.trim(),
    terms: terms.trim(),
    tax: String(tax || ""),
    feeLines: feeLines.map((fee) => ({
      id: fee.id,
      name: fee.name.trim(),
      amount: String(fee.amount || ""),
    })),
    lines: lines.map((line) => ({
      id: line.id,
      type: line.type,
      item: line.item || "",
      code: line.code || "",
      desc: line.desc || "",
      woRef: line.woRef || "-",
      qty: Number(line.qty) || 0,
      price: Number(line.price) || 0,
      image: line.image || "",
      lockedFromWorkOrder: !!line.lockedFromWorkOrder,
      sourceWorkOrderLineId: line.sourceWorkOrderLineId || "",
    })),
  });

  const initialDirtySnapshotRef = React.useRef(null);
  if (initialDirtySnapshotRef.current === null) {
    initialDirtySnapshotRef.current = JSON.stringify(buildFormDirtySnapshot());
  }

  const isFormDirty =
    JSON.stringify(buildFormDirtySnapshot()) !==
    initialDirtySnapshotRef.current;

  const validateMandatoryFields = () => {
    const nextErrors = {};
    if (!vendorSearch.trim()) nextErrors.vendor = "Field cannot be empty";
    if (!poDate) nextErrors.poDate = "Field cannot be empty";
    if (!currency) nextErrors.currency = "Field cannot be empty";
    if (!lines.length) nextErrors.lines = "Add at least one product line";
    setFormErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const buildPoPayload = (status, badge) => ({
    poNumber:
      initialData?.poNumber ||
      `PO-202603-${String(Math.floor(1000 + Math.random() * 9000))}`,
    vendorName: vendorSearch || "-",
    amount: formatCurrency(total),
    createdDate: poDate,
    status,
    statusKey:
      status === "Draft"
        ? "draft"
        : status === "Waiting for Approval"
          ? "ready_to_send"
          : "issued",
    sBadge: badge,
    ...(initialData?.from ? { from: initialData.from } : {}),
    ...(initialData?.returnTo ? { returnTo: initialData.returnTo } : {}),
    formData: {
      vendorName: vendorSearch,
      vendorDetails,
      poDate,
      deliveryDate,
      currency,
      lines,
      tax: parseFloat(tax) || 0,
      feeLines,
      notes,
      terms,
      shipTo: shipToInfo,
    },
  });

  const handleVendorInputChange = (value) => {
    setVendorSearch(value);
    setShowVendorSuggestions(true);

    const trimmedValue = value.trim();
    const exactMatch = MOCK_VENDORS.find(
      (vendor) => vendor.name.toLowerCase() === trimmedValue.toLowerCase()
    );

    if (!trimmedValue) {
      setVendorDetails({ phone: "", email: "", address: "" });
      setIsVendorLocked(false);
      return;
    }

    if (exactMatch) {
      setVendorDetails({
        phone: exactMatch.phone,
        email: exactMatch.email,
        address: exactMatch.address,
      });
      setIsVendorLocked(true);
      return;
    }

    setVendorDetails((prev) => {
      const hasLockedVendorData = prev.phone || prev.email || prev.address;
      return hasLockedVendorData ? { phone: "", email: "", address: "" } : prev;
    });
    setIsVendorLocked(false);
  };

  const handleAddNewVendorOption = () => {
    const trimmedValue = vendorSearch.trim();
    if (!trimmedValue) return;
    setVendorSearch(trimmedValue);
    setVendorDetails({ phone: "", email: "", address: "" });
    setIsVendorLocked(false);
    setIsVendorFieldFocused(false);
    setShowVendorSuggestions(false);
  };

  const handleSelectVendorSuggestion = (vendor) => {
    setVendorSearch(vendor.name);
    setVendorDetails({
      phone: vendor.phone,
      email: vendor.email,
      address: vendor.address,
    });
    setIsVendorLocked(true);
    setIsVendorFieldFocused(false);
    setShowVendorSuggestions(false);
  };

  const handleUseCompanyDetail = () => {
    setShipToInfo({
      name: MOCK_COMPANY.name,
      phone: MOCK_COMPANY.phone,
      email: MOCK_COMPANY.email,
      address: MOCK_COMPANY.address,
    });
  };

  const handleAddFeeLine = () =>
    setFeeLines((prev) => [
      ...prev,
      { id: `fee-${Date.now()}`, name: "", amount: "" },
    ]);
  const handleFeeChange = (feeId, key, value) =>
    setFeeLines((prev) =>
      prev.map((fee) => (fee.id === feeId ? { ...fee, [key]: value } : fee))
    );
  const handleRemoveFeeLine = (feeId) =>
    setFeeLines((prev) =>
      prev.length === 1
        ? [{ id: "fee-1", name: "", amount: "" }]
        : prev.filter((fee) => fee.id !== feeId)
    );

  const openAddProductModal = () => {
    setEditingLineId(null);
    setProductLineType("manual");
    setProductModalForm({
      manualName: "",
      manualCode: "",
      manualDesc: "",
      manualQty: "",
      manualPrice: "",
      selectedWorkOrderLineId: "",
      selectedMaterialLineId: "",
    });
    setProductModalImages([]);
    setProductModalFieldErrors({});
    setProductModalError("");
    setShowAddProductModal(true);
  };

  const handleEditLine = (line) => {
    setEditingLineId(line.id);
    const isWo = line.type === "wo";
    const isMaterial = line.type === "material";
    const matchedWorkOrderLine = isWo
      ? availableWorkOrderLines.find(
        (wo) =>
          (line.sourceWorkOrderLineId &&
            getWorkOrderSourceId(wo) === line.sourceWorkOrderLineId) ||
          (wo.item === line.item && wo.woRef === line.woRef)
      )
      : null;
    const matchedMaterialLine = isMaterial
      ? availableMaterialLines.find(
        (material) =>
          material.item === line.item && material.code === line.code
      )
      : null;
    const fallbackGeneratedLineId =
      line.lockedFromWorkOrder && generatedWorkOrderLine
        ? getWorkOrderSourceId(generatedWorkOrderLine)
        : "";

    setProductLineType(isWo ? "wo" : isMaterial ? "material" : "manual");
    setProductModalForm({
      manualName: line.item || "",
      manualCode: line.code || "",
      manualDesc: line.desc || "",
      manualQty: line.qty ? String(line.qty) : "",
      manualPrice: line.price ? String(line.price) : "",
      selectedWorkOrderLineId: isWo
        ? getWorkOrderSourceId(matchedWorkOrderLine) ||
        line.sourceWorkOrderLineId ||
        fallbackGeneratedLineId
        : "",
      selectedMaterialLineId: isMaterial ? matchedMaterialLine?.id || "" : "",
    });
    setProductModalImages(
      line.image
        ? [createImageUploadRecord(line.image)]
        : line.lockedFromWorkOrder && generatedWorkOrderLine?.image
          ? [createImageUploadRecord(generatedWorkOrderLine.image)]
          : []
    );
    setProductModalFieldErrors({});
    setProductModalError("");
    setShowAddProductModal(true);
  };

  const handleSaveProductLine = () => {
    if (productLineType === "manual") {
      const nextErrors = {};
      if (!productModalForm.manualName.trim())
        nextErrors.manualName = "Field cannot be empty";
      if (!productModalForm.manualQty)
        nextErrors.manualQty = "Field cannot be empty";
      if (!productModalForm.manualPrice)
        nextErrors.manualPrice = "Field cannot be empty";
      setProductModalFieldErrors(nextErrors);
      if (Object.keys(nextErrors).length > 0) return;

      const nextLine = {
        id: editingLineId || `manual-${Date.now()}`,
        type: "manual",
        item: productModalForm.manualName,
        code: productModalForm.manualCode || "-",
        desc: productModalForm.manualDesc || "-",
        woRef: "-",
        qty: parseInt(productModalForm.manualQty, 10) || 0,
        price: parseInt(productModalForm.manualPrice, 10) || 0,
        image: getImageUploadName(productModalImages[0]),
      };

      setLines((prev) =>
        editingLineId
          ? prev.map((line) =>
            line.id === editingLineId ? { ...line, ...nextLine } : line
          )
          : [...prev, nextLine]
      );
      setShowAddProductModal(false);
      setEditingLineId(null);
      setProductModalFieldErrors({});
      return;
    }

    if (productLineType === "material") {
      const targetLine = availableMaterialLines.find(
        (line) => line.id === productModalForm.selectedMaterialLineId
      );
      const nextErrors = {};
      if (!productModalForm.selectedMaterialLineId)
        nextErrors.selectedMaterialLineId = "Field cannot be empty";
      if (!productModalForm.manualQty)
        nextErrors.manualQty = "Field cannot be empty";
      if (!productModalForm.manualPrice)
        nextErrors.manualPrice = "Field cannot be empty";
      setProductModalFieldErrors(nextErrors);
      if (Object.keys(nextErrors).length > 0 || !targetLine) return;

      const nextLine = {
        id: editingLineId || `material-${Date.now()}`,
        type: "material",
        item: targetLine.item,
        code: targetLine.code,
        desc: productModalForm.manualDesc || targetLine.desc,
        woRef: "-",
        qty: parseInt(productModalForm.manualQty, 10) || targetLine.qty,
        price: parseInt(productModalForm.manualPrice, 10) || targetLine.price,
        image: getImageUploadName(productModalImages[0]) || targetLine.image || "",
      };

      setLines((prev) =>
        editingLineId
          ? prev.map((line) =>
            line.id === editingLineId ? { ...line, ...nextLine } : line
          )
          : [...prev, nextLine]
      );
      setShowAddProductModal(false);
      setEditingLineId(null);
      setProductModalFieldErrors({});
      return;
    }

    const targetLine = availableWorkOrderLines.find(
      (line) =>
        getWorkOrderSourceId(line) === productModalForm.selectedWorkOrderLineId
    );
    const nextErrors = {};
    if (!productModalForm.selectedWorkOrderLineId)
      nextErrors.selectedWorkOrderLineId = "Field cannot be empty";
    if (!productModalForm.manualPrice)
      nextErrors.manualPrice = "Field cannot be empty";
    setProductModalFieldErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0 || !targetLine) return;

    const nextLine = {
      id: editingLineId || `wo-${Date.now()}`,
      type: "wo",
      item: targetLine.item,
      code: targetLine.code,
      desc: productModalForm.manualDesc || targetLine.desc,
      woRef: targetLine.woRef,
      qty: parseInt(productModalForm.manualQty, 10) || targetLine.qty,
      price: parseInt(productModalForm.manualPrice, 10) || targetLine.price,
      image: getImageUploadName(productModalImages[0]),
      lockedFromWorkOrder: editingLineId
        ? lines.find((line) => line.id === editingLineId)?.lockedFromWorkOrder
        : false,
      sourceWorkOrderLineId: getWorkOrderSourceId(targetLine),
    };

    setLines((prev) =>
      editingLineId
        ? prev.map((line) =>
          line.id === editingLineId ? { ...line, ...nextLine } : line
        )
        : [...prev, nextLine]
    );
    setShowAddProductModal(false);
    setEditingLineId(null);
    setProductModalFieldErrors({});
  };

  const handleRemoveLine = (lineId) =>
    setLines((prev) =>
      prev.filter((line) => line.id !== lineId || line.lockedFromWorkOrder)
    );

  const handleSaveDraft = () => {
    if (!isFormDirty && !hasPrefilledDraftContent) {
      setShowEmptyDraftModal(true);
      return;
    }

    if (pageTopRef.current) {
      pageTopRef.current.scrollIntoView({ behavior: "auto", block: "start" });
    } else if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "auto" });
    }

    const payload = {
      ...buildPoPayload("Draft", "grey-light"),
      showDraftToast: true,
    };

    if (
      initialData?.source === "work_order_vendor_assignment" &&
      initialData?.returnTo?.data
    ) {
      const targetPoNumber = payload.poNumber;
      const updatedReturnData = {
        ...initialData.returnTo.data,
        vendors: (initialData.returnTo.data.vendors || []).map((vendor) => {
          const isTargetVendor =
            vendor.name === vendorSearch ||
            vendor.poNumber === initialData?.poNumber;
          if (!isTargetVendor) return vendor;
          return {
            ...vendor,
            poNumber: targetPoNumber,
            isPoApproved: false,
          };
        }),
      };

      payload.from = "work_order_detail";
      payload.returnTo = {
        ...initialData.returnTo,
        data: updatedReturnData,
      };
    }

    scrollToTop();
    onNavigate("po_detail", payload);
  };

  const handleSubmitClick = () => {
    if (!validateMandatoryFields()) return;
    setShowSubmitConfirmModal(true);
  };

  const handleConfirmSubmit = () => {
    const approvalOn = !!poApprovalSettings?.isApprovalActive;
    const nextStatus = approvalOn ? "Waiting for Approval" : "Issued";
    const nextBadge = approvalOn ? "blue-light" : "blue";
    const payload = buildPoPayload(nextStatus, nextBadge);

    if (
      initialData?.source === "work_order_vendor_assignment" &&
      initialData?.returnTo?.data
    ) {
      const targetPoNumber = payload.poNumber;
      const updatedReturnData = {
        ...initialData.returnTo.data,
        vendors: (initialData.returnTo.data.vendors || []).map((vendor) => {
          const isTargetVendor =
            vendor.name === vendorSearch ||
            vendor.poNumber === initialData?.poNumber;
          if (!isTargetVendor) return vendor;
          return {
            ...vendor,
            poNumber: targetPoNumber,
            isPoApproved: !approvalOn,
          };
        }),
      };

      payload.from = "work_order_detail";
      payload.returnTo = {
        ...initialData.returnTo,
        data: updatedReturnData,
      };
    }

    scrollToTop();
    onNavigate("po_detail", payload);
  };

  const pageSectionStyle = {
    background: "var(--neutral-surface-primary)",
    borderRadius: "16px",
    border: "1px solid var(--neutral-line-separator-1)",
    overflow: "hidden",
  };

  const sectionHeader = (title, right) => (
    <div
      style={{
        padding: "18px 20px 0 20px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "12px",
        position: "relative",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        <div
          style={{
            width: "6px",
            height: "24px",
            borderRadius: "0 4px 4px 0",
            background: "var(--feature-brand-primary)",
            position: "absolute",
            left: 0,
            top: "18px",
          }}
        />
        <span
          style={{
            fontSize: "var(--text-title-1)",
            fontWeight: "var(--font-weight-bold)",
            color: "var(--neutral-on-surface-primary)",
          }}
        >
          {title}
        </span>
      </div>
      {right || null}
    </div>
  );

  const fieldLabelCol = (label, desc, required = false) => (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "4px",
        paddingTop: "8px",
      }}
    >
      <div style={{ display: "flex", alignItems: "flex-start", gap: "4px" }}>
        {required ? (
          <span
            style={{
              color: "var(--status-red-primary)",
              fontSize: "var(--text-title-3)",
            }}
          >
            *
          </span>
        ) : null}
        <span
          style={{
            fontSize: "var(--text-title-3)",
            color: "var(--neutral-on-surface-primary)",
            fontWeight: "var(--font-weight-bold)",
          }}
        >
          {label}
        </span>
      </div>
    </div>
  );

  const rowWrapStyle = {
    display: "grid",
    gridTemplateColumns: "220px minmax(0, 1fr)",
    gap: "20px",
    alignItems: "start",
  };
  const compactGridStyle = {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "16px",
  };
  const currencyPrefixLabel = currency === "USD" ? "USD" : "IDR";

  const handleAddProductImages = (files) => {
    const nextFile = Array.from(files || [])[0];
    if (!nextFile) return;
    const validationMessage = validateUploadFile(
      nextFile,
      ALLOWED_IMAGE_EXTENSIONS,
      UPLOAD_MAX_FILE_SIZE_BYTES,
      "Allowed formats (JPG, JPEG, PNG, WebP)"
    );
    if (validationMessage) {
      setProductModalError(validationMessage);
      return;
    }
    setProductModalError("");
    setProductModalImages([createImageUploadRecord(nextFile)]);
  };

  const handleRemoveProductImage = (imageToRemove) => {
    const imageName = getImageUploadName(imageToRemove);
    setProductModalImages((prev) =>
      prev.filter((item) => getImageUploadName(item) !== imageName)
    );
    setProductModalError("");
  };

  const renderProductImageUploader = (disabled = false) => {
    const helperText = disabled
      ? "Image is taken from the selected work order."
      : "Allowed formats (JPG, JPEG, PNG, WebP), Max size 25MB per file";

    return (
      <ImageUploadField
        label="Images"
        images={productModalImages}
        maxFiles={1}
        disabled={disabled}
        error={productModalError}
        helperText={helperText}
        onFilesSelected={handleAddProductImages}
        onRemove={handleRemoveProductImage}
      />
    );
  };

  return (
    <div
      ref={pageTopRef}
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "calc(100vh - 64px)",
        background: "#F5F5F7",
        position: "relative",
      }}
    >
      <div
        style={{
          padding: "24px",
          display: "flex",
          flexDirection: "column",
          gap: "16px",
          paddingBottom: "108px",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              cursor: "pointer",
              marginLeft: "-4px",
            }}
            onClick={handleBackNavigation}
          >
            <ChevronLeftIcon
              size={28}
              color="var(--neutral-on-surface-primary)"
            />
            <h1
              style={{
                margin: 0,
                fontSize: "var(--text-large-title)",
                fontWeight: "var(--font-weight-bold)",
                color: "var(--neutral-on-surface-primary)",
              }}
            >
              {isEditMode ? "Edit Purchase Order" : "Add New Purchase Order"}
            </h1>
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "var(--text-title-3)",
            }}
          >
            <span
              style={{
                color: "var(--neutral-on-surface-secondary)",
                cursor: "pointer",
              }}
              onClick={handleBackNavigation}
            >
              Purchase Order
            </span>
            <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>
              /
            </span>
            <span style={{ color: "var(--neutral-on-surface-tertiary)" }}>
              {isEditMode ? "Edit Purchase Order" : "Add New Purchase Order"}
            </span>
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
          <div style={pageSectionStyle}>
            {sectionHeader("Vendor Information")}
            <div
              style={{
                padding: "18px 20px 20px 20px",
                display: "flex",
                flexDirection: "column",
                gap: "16px",
              }}
            >
              <div style={rowWrapStyle}>
                {fieldLabelCol(
                  "Vendor Name",
                  "Select an existing vendor or add a new one.",
                  true
                )}
                <div style={{ position: "relative" }}>
                  <div style={{ position: "relative" }}>
                    <input
                      value={vendorSearch}
                      onChange={(e) => handleVendorInputChange(e.target.value)}
                      onFocus={() => {
                        if (!isFromWorkOrderAssignment) {
                          setIsVendorFieldFocused(true);
                          setShowVendorSuggestions(true);
                        }
                      }}
                      onClick={() => {
                        if (!isFromWorkOrderAssignment) {
                          setIsVendorFieldFocused(true);
                          setShowVendorSuggestions(true);
                        }
                      }}
                      disabled={isFromWorkOrderAssignment}
                      onBlur={() => {
                        setTimeout(() => {
                          setIsVendorFieldFocused(false);
                        }, 120);
                      }}
                      placeholder="Type to search or add vendor"
                      style={{
                        ...fieldStyle(
                          isFromWorkOrderAssignment,
                          !!vendorSearch,
                          false
                        ),
                        borderColor: isVendorFieldFocused
                          ? "var(--feature-brand-primary)"
                          : baseInputBorderColor,
                        padding: "0 48px 0 16px",
                        background: isFromWorkOrderAssignment
                          ? "var(--neutral-surface-grey-lighter)"
                          : "var(--neutral-surface-primary)",
                        cursor: isFromWorkOrderAssignment
                          ? "not-allowed"
                          : "text",
                      }}
                    />
                    <ChevronDownIcon
                      size={20}
                      color="var(--neutral-on-surface-secondary)"
                      style={{
                        position: "absolute",
                        right: "16px",
                        top: "50%",
                        transform: `translateY(-50%) ${showVendorSuggestions
                            ? "rotate(180deg)"
                            : "rotate(0deg)"
                          }`,
                        transition: "transform 0.2s ease",
                        pointerEvents: "none",
                      }}
                    />
                  </div>
                  {showVendorSuggestions && !isFromWorkOrderAssignment ? (
                    <>
                      <div
                        style={{ position: "fixed", inset: 0, zIndex: 29 }}
                        onClick={() => {
                          setShowVendorSuggestions(false);
                          setIsVendorFieldFocused(false);
                        }}
                      />
                      <div
                        style={{
                          position: "absolute",
                          top: "52px",
                          left: 0,
                          right: 0,
                          background: "var(--neutral-surface-primary)",
                          border: "1px solid var(--neutral-line-separator-1)",
                          borderRadius: "16px",
                          boxShadow: "0px 8px 20px rgba(27, 27, 27, 0.12)",
                          overflow: "hidden",
                          zIndex: 30,
                        }}
                      >
                        {vendorSuggestions.length > 0
                          ? vendorSuggestions.map((vendor, index) => (
                            <div
                              key={vendor.id}
                              onClick={() =>
                                handleSelectVendorSuggestion(vendor)
                              }
                              style={{
                                minHeight: "56px",
                                padding: "0 18px",
                                cursor: "pointer",
                                borderBottom:
                                  "1px solid var(--neutral-line-separator-1)",
                                display: "flex",
                                alignItems: "center",
                                fontSize: "var(--text-title-2)",
                                color: "var(--neutral-on-surface-primary)",
                                background: "var(--neutral-surface-primary)",
                              }}
                              onMouseEnter={(e) =>
                              (e.currentTarget.style.background =
                                "var(--neutral-surface-grey-lighter)")
                              }
                              onMouseLeave={(e) =>
                              (e.currentTarget.style.background =
                                "var(--neutral-surface-primary)")
                              }
                            >
                              {vendor.name}
                            </div>
                          ))
                          : null}
                        {!vendorHasExactMatch && vendorSearch.trim() ? (
                          <div
                            onClick={handleAddNewVendorOption}
                            style={{
                              minHeight: "48px",
                              padding: "0 18px",
                              display: "flex",
                              alignItems: "center",
                              fontSize: "var(--text-title-2)",
                              color: "var(--feature-brand-primary)",
                              cursor: "pointer",
                              background: "var(--neutral-surface-primary)",
                            }}
                            onMouseEnter={(e) =>
                            (e.currentTarget.style.background =
                              "var(--feature-brand-container-lighter)")
                            }
                            onMouseLeave={(e) =>
                            (e.currentTarget.style.background =
                              "var(--neutral-surface-primary)")
                            }
                          >
                            + Add "{vendorSearch.trim()}" as new vendor
                          </div>
                        ) : null}
                      </div>
                    </>
                  ) : null}
                  {formErrors.vendor ? (
                    <span
                      style={{
                        marginTop: "6px",
                        display: "block",
                        fontSize: "var(--text-body)",
                        color: "var(--status-red-primary)",
                      }}
                    >
                      {formErrors.vendor}
                    </span>
                  ) : null}
                </div>
              </div>

              <div style={rowWrapStyle}>
                {fieldLabelCol("Phone Number")}
                <PhoneInputField
                  value={vendorDetails.phone}
                  onChange={(nextValue) =>
                    setVendorDetails({ ...vendorDetails, phone: nextValue })
                  }
                  disabled={isVendorLocked}
                />
              </div>

              <div style={rowWrapStyle}>
                {fieldLabelCol("Email")}
                <InputField
                  value={vendorDetails.email}
                  onChange={(e) =>
                    setVendorDetails({
                      ...vendorDetails,
                      email: e.target.value,
                    })
                  }
                  disabled={isVendorLocked}
                  placeholder="Input email"
                />
              </div>

              <div style={rowWrapStyle}>
                {fieldLabelCol("Address")}
                <InputField
                  multiline
                  value={vendorDetails.address}
                  onChange={(e) =>
                    setVendorDetails({
                      ...vendorDetails,
                      address: e.target.value,
                    })
                  }
                  disabled={isVendorLocked}
                  placeholder="Input vendor address"
                />
              </div>
            </div>
          </div>

          <div style={pageSectionStyle}>
            {sectionHeader("Purchase Order Information")}
            <div
              style={{
                padding: "18px 20px 20px 20px",
                display: "flex",
                flexDirection: "column",
                gap: "16px",
              }}
            >
              <div style={rowWrapStyle}>
                {fieldLabelCol(
                  "Purchase Order Date",
                  "The date when this purchase order is created.",
                  true
                )}
                <div>
                  <InputField
                    type="date"
                    value={poDate}
                    onChange={(e) => setPoDate(e.target.value)}
                  />
                  {formErrors.poDate ? (
                    <span
                      style={{
                        marginTop: "6px",
                        display: "block",
                        fontSize: "var(--text-body)",
                        color: "var(--status-red-primary)",
                      }}
                    >
                      {formErrors.poDate}
                    </span>
                  ) : null}
                </div>
              </div>
              <div style={rowWrapStyle}>
                {fieldLabelCol(
                  "Expected Delivery Date",
                  "Estimated receiving date from the vendor."
                )}
                <InputField
                  type="date"
                  value={deliveryDate}
                  onChange={(e) => setDeliveryDate(e.target.value)}
                />
              </div>
              <div style={rowWrapStyle}>
                {fieldLabelCol(
                  "Currency",
                  "Used for all prices in this purchase order.",
                  true
                )}
                <div>
                  <DropdownSelect
                    value={currency}
                    onChange={(nextValue) => setCurrency(nextValue)}
                    options={[
                      { value: "IDR", label: "IDR - Indonesian Rupiah" },
                      { value: "USD", label: "USD - US Dollar" },
                    ]}
                  />
                  {formErrors.currency ? (
                    <span
                      style={{
                        marginTop: "6px",
                        display: "block",
                        fontSize: "var(--text-body)",
                        color: "var(--status-red-primary)",
                      }}
                    >
                      {formErrors.currency}
                    </span>
                  ) : null}
                </div>
              </div>
            </div>
          </div>

          <div style={pageSectionStyle}>
            {sectionHeader(
              "Ship To",
              <Button
                variant="tertiary"
                size="small"
                onClick={handleUseCompanyDetail}
              >
                Use Company Detail
              </Button>
            )}
            <div
              style={{
                padding: "18px 20px 20px 20px",
                display: "flex",
                flexDirection: "column",
                gap: "16px",
              }}
            >
              <div style={rowWrapStyle}>
                {fieldLabelCol(
                  "Recipient Name",
                  "The recipient name for this delivery."
                )}
                <InputField
                  value={shipToInfo.name}
                  onChange={(e) =>
                    setShipToInfo({ ...shipToInfo, name: e.target.value })
                  }
                  placeholder="Input recipient name"
                />
              </div>
              <div style={rowWrapStyle}>
                {fieldLabelCol("Phone Number")}
                <PhoneInputField
                  value={shipToInfo.phone}
                  onChange={(nextValue) =>
                    setShipToInfo({ ...shipToInfo, phone: nextValue })
                  }
                />
              </div>
              <div style={rowWrapStyle}>
                {fieldLabelCol("Email")}
                <InputField
                  value={shipToInfo.email}
                  onChange={(e) =>
                    setShipToInfo({ ...shipToInfo, email: e.target.value })
                  }
                  placeholder="Input email"
                />
              </div>
              <div style={rowWrapStyle}>
                {fieldLabelCol(
                  "Address",
                  "The destination address for the order."
                )}
                <InputField
                  multiline
                  value={shipToInfo.address}
                  onChange={(e) =>
                    setShipToInfo({ ...shipToInfo, address: e.target.value })
                  }
                  placeholder="Input address"
                />
              </div>
            </div>
          </div>

          <div style={pageSectionStyle}>
            {sectionHeader(
              "Purchase Order Lines",
              <Button
                variant="tertiary"
                size="small"
                leftIcon={AddIcon}
                onClick={openAddProductModal}
              >
                Add PO Line
              </Button>
            )}
            <div
              style={{
                padding: "18px 20px 20px 20px",
                display: "flex",
                flexDirection: "column",
                gap: "16px",
              }}
            >
              <div
                style={{
                  border: "none",
                  borderRadius: "0",
                  overflow: "hidden",
                  width: "100%",
                }}
              >
                <div style={{ overflowX: "auto", width: "100%" }}>
                  <div
                    style={{
                      minWidth: "1260px",
                      width: "100%",
                      display: "flex",
                      flexDirection: "column",
                    }}
                  >
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns:
                          "84px 112px minmax(220px, 1.5fr) minmax(180px, 1fr) minmax(220px, 1.4fr) 90px 160px 160px 88px",
                        gap: "0",
                        padding: "0 16px",
                        height: "49px",
                        alignItems: "center",
                        background: "var(--neutral-surface-primary)",
                        borderBottom:
                          "1px solid var(--neutral-line-separator-1)",
                        fontSize: "var(--text-title-3)",
                        fontWeight: "var(--font-weight-bold)",
                        color: "var(--neutral-on-surface-primary)",
                      }}
                    >
                      <span>Type</span>
                      <span>Image</span>
                      <span>Name</span>
                      <span>SKU</span>
                      <span>Description</span>
                      <span style={{ textAlign: "center" }}>Qty</span>
                      <span style={{ textAlign: "right" }}>Unit Price</span>
                      <span style={{ textAlign: "right" }}>Subtotal</span>
                      <span style={{ textAlign: "right" }}>Action</span>
                    </div>

                    {lines.length > 0 ? (
                      lines.map((line, idx) => {
                        const isLockedWorkOrderLine =
                          !!line.lockedFromWorkOrder;
                        const lineSubtotal =
                          (parseFloat(line.qty) || 0) *
                          (parseFloat(line.price) || 0);
                        return (
                          <div
                            key={line.id}
                            style={{
                              display: "grid",
                              gridTemplateColumns:
                                "84px 112px minmax(220px, 1.5fr) minmax(180px, 1fr) minmax(220px, 1.4fr) 90px 160px 160px 88px",
                              gap: "0",
                              padding: "0 16px",
                              minHeight: "64px",
                              alignItems: "center",
                              borderBottom:
                                idx === lines.length - 1
                                  ? "none"
                                  : "1px solid var(--neutral-line-separator-1)",
                              background: "var(--neutral-surface-primary)",
                            }}
                          >
                            <div>
                              <StatusBadge
                                variant={
                                  line.type === "wo"
                                    ? "blue-light"
                                    : line.type === "material"
                                      ? "yellow-light"
                                      : "grey-light"
                                }
                              >
                                {line.type === "wo"
                                  ? "WO"
                                  : line.type === "material"
                                    ? "Material"
                                    : "Manual"}
                              </StatusBadge>
                            </div>
                            <div
                              style={{ display: "flex", alignItems: "center" }}
                            >
                              <div
                                style={{
                                  width: "56px",
                                  height: "56px",
                                  borderRadius: "12px",
                                  background:
                                    "var(--neutral-surface-grey-lighter)",
                                  border:
                                    "1px solid var(--neutral-line-separator-1)",
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  flexShrink: 0,
                                }}
                              >
                                <ImageAssetIcon
                                  size={20}
                                  color="var(--neutral-on-surface-tertiary)"
                                />
                              </div>
                            </div>
                            <div style={{ minWidth: 0 }}>
                              <span
                                style={{
                                  display: "block",
                                  fontSize: "var(--text-title-3)",
                                  fontWeight: "var(--font-weight-bold)",
                                  color: "var(--neutral-on-surface-primary)",
                                  whiteSpace: "nowrap",
                                  overflow: "hidden",
                                  textOverflow: "ellipsis",
                                }}
                                title={line.item}
                              >
                                {line.item}
                              </span>
                            </div>
                            <div style={{ minWidth: 0 }}>
                              <span
                                style={{
                                  display: "block",
                                  fontSize: "var(--text-title-3)",
                                  color: "var(--neutral-on-surface-secondary)",
                                  whiteSpace: "nowrap",
                                  overflow: "hidden",
                                  textOverflow: "ellipsis",
                                }}
                                title={line.code}
                              >
                                {line.code}
                              </span>
                            </div>
                            <div style={{ minWidth: 0 }}>
                              <span
                                style={{
                                  display: "block",
                                  fontSize: "var(--text-title-3)",
                                  color: "var(--neutral-on-surface-secondary)",
                                  whiteSpace: "nowrap",
                                  overflow: "hidden",
                                  textOverflow: "ellipsis",
                                }}
                                title={line.desc || "-"}
                              >
                                {line.desc || "-"}
                              </span>
                            </div>
                            <span
                              style={{
                                textAlign: "center",
                                fontSize: "var(--text-title-3)",
                                color: "var(--neutral-on-surface-primary)",
                              }}
                            >
                              {line.qty || 0}
                            </span>
                            <span
                              style={{
                                textAlign: "right",
                                fontSize: "var(--text-title-3)",
                                color: "var(--neutral-on-surface-primary)",
                              }}
                            >
                              {formatCurrency(line.price)}
                            </span>
                            <span
                              style={{
                                textAlign: "right",
                                fontSize: "var(--text-title-3)",
                                fontWeight: "var(--font-weight-bold)",
                                color: "var(--neutral-on-surface-primary)",
                              }}
                            >
                              {formatCurrency(lineSubtotal)}
                            </span>
                            <div
                              style={{
                                display: "flex",
                                justifyContent: "flex-end",
                                gap: "10px",
                              }}
                            >
                              <IconButton
                                icon={EditIcon}
                                onClick={() => handleEditLine(line)}
                                title="Edit line"
                                color="var(--feature-brand-primary)"
                              />
                              <IconButton
                                icon={DeleteIcon}
                                onClick={() => handleRemoveLine(line.id)}
                                disabled={isLockedWorkOrderLine}
                                title={
                                  isLockedWorkOrderLine
                                    ? "This work order line cannot be removed"
                                    : "Remove line"
                                }
                                color={
                                  isLockedWorkOrderLine
                                    ? "var(--neutral-on-surface-tertiary)"
                                    : "var(--status-red-primary)"
                                }
                                hoverBackground="var(--status-red-container)"
                              />
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div
                        style={{
                          padding: "32px",
                          textAlign: "center",
                          color: "var(--neutral-on-surface-tertiary)",
                          fontSize: "var(--text-title-3)",
                          background: "var(--neutral-surface-primary)",
                        }}
                      >
                        No purchase order lines added yet. Click “Add PO Line”
                        to get started.
                      </div>
                    )}
                  </div>
                </div>
              </div>
              {formErrors.lines ? (
                <span
                  style={{
                    fontSize: "var(--text-body)",
                    color: "var(--status-red-primary)",
                  }}
                >
                  {formErrors.lines}
                </span>
              ) : null}
            </div>
          </div>

          <div style={pageSectionStyle}>
            {sectionHeader("Notes & Terms")}
            <div
              style={{
                padding: "18px 20px 20px 20px",
                display: "flex",
                flexDirection: "column",
                gap: "16px",
              }}
            >
              <div style={rowWrapStyle}>
                {fieldLabelCol("Notes", "Additional notes for the vendor.")}
                <InputField
                  multiline
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Input notes"
                />
              </div>
              <div style={rowWrapStyle}>
                {fieldLabelCol(
                  "Terms",
                  "Terms and conditions related to this order."
                )}
                <InputField
                  multiline
                  value={terms}
                  onChange={(e) => setTerms(e.target.value)}
                  placeholder="Input terms"
                />
              </div>
            </div>
          </div>

          <div style={pageSectionStyle}>
            {sectionHeader(
              "Price",
              <Button
                variant="tertiary"
                size="small"
                leftIcon={AddIcon}
                onClick={handleAddFeeLine}
              >
                Add Fee
              </Button>
            )}
            <div
              style={{
                padding: "18px 20px 20px 20px",
                display: "flex",
                flexDirection: "column",
                gap: "16px",
              }}
            >
              <div style={rowWrapStyle}>
                {fieldLabelCol(
                  "Tax",
                  "Input tax percentage for this purchase order."
                )}
                <InputGroup
                  type="number"
                  value={tax}
                  onChange={(e) => setTax(e.target.value)}
                  placeholder="0"
                  suffix="%"
                />
              </div>
              <div style={rowWrapStyle}>
                {fieldLabelCol("Fees", "Add one or more fee lines if needed.")}
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "12px",
                  }}
                >
                  {feeLines.map((fee) => (
                    <div
                      key={fee.id}
                      style={{
                        display: "grid",
                        gridTemplateColumns: "1.4fr 1fr 48px",
                        gap: "12px",
                        alignItems: "end",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "8px",
                        }}
                      >
                        <span
                          style={{
                            fontSize: "var(--text-body)",
                            color: "var(--neutral-on-surface-primary)",
                          }}
                        >
                          Fee Name
                        </span>
                        <div style={{ position: "relative", width: "100%" }}>
                          <input
                            type="text"
                            value={fee.name}
                            onChange={(e) =>
                              handleFeeChange(
                                fee.id,
                                "name",
                                e.target.value.slice(0, 40)
                              )
                            }
                            placeholder="Input fee name"
                            style={{
                              height: "48px",
                              padding: "0 56px 0 16px",
                              background: "var(--neutral-surface-primary)",
                              ...inputFrameStyle(false, false),
                              ...inputControlStyle(false, !!fee.name),
                            }}
                            onFocus={(e) => focusInputFrame(e.currentTarget)}
                            onBlur={(e) =>
                              blurInputFrame(e.currentTarget, false, false)
                            }
                          />
                          <span
                            style={{
                              position: "absolute",
                              right: "16px",
                              top: "50%",
                              transform: "translateY(-50%)",
                              fontSize: "var(--text-desc)",
                              color: "var(--neutral-on-surface-tertiary)",
                              pointerEvents: "none",
                            }}
                          >
                            {fee.name.length}/40
                          </span>
                        </div>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "8px",
                        }}
                      >
                        <span
                          style={{
                            fontSize: "var(--text-body)",
                            color: "var(--neutral-on-surface-primary)",
                          }}
                        >
                          Amount
                        </span>
                        <InputGroup
                          type="number"
                          value={fee.amount}
                          onChange={(e) =>
                            handleFeeChange(fee.id, "amount", e.target.value)
                          }
                          placeholder="0"
                          prefix={currencyPrefixLabel}
                        />
                      </div>
                      <button
                        onClick={() => handleRemoveFeeLine(fee.id)}
                        disabled={feeLines.length === 1}
                        style={{
                          width: "40px",
                          height: "40px",
                          borderRadius: "10px",
                          border: "1px solid var(--neutral-line-separator-1)",
                          background:
                            feeLines.length === 1
                              ? "var(--neutral-surface-grey-lighter)"
                              : "var(--neutral-surface-primary)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          cursor:
                            feeLines.length === 1 ? "not-allowed" : "pointer",
                          opacity: 1,
                        }}
                      >
                        <DeleteIcon
                          size={16}
                          color={
                            feeLines.length === 1
                              ? "var(--neutral-on-surface-tertiary)"
                              : "var(--status-red-primary)"
                          }
                        />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div style={pageSectionStyle}>
            {sectionHeader("Summary")}
            <div
              style={{
                padding: "18px 20px 20px 20px",
                display: "flex",
                justifyContent: "stretch",
              }}
            >
              <div
                style={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  gap: "14px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    fontSize: "var(--text-title-3)",
                  }}
                >
                  <span
                    style={{ color: "var(--neutral-on-surface-secondary)" }}
                  >
                    Subtotal
                  </span>
                  <span style={{ fontWeight: "var(--font-weight-bold)" }}>
                    {formatCurrency(subtotal)}
                  </span>
                </div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    fontSize: "var(--text-title-3)",
                  }}
                >
                  <span
                    style={{ color: "var(--neutral-on-surface-secondary)" }}
                  >
                    Tax ({parseFloat(tax) || 0}%)
                  </span>
                  <span style={{ fontWeight: "var(--font-weight-bold)" }}>
                    {formatCurrency(taxAmount)}
                  </span>
                </div>
                {activeFeeLines.length > 0
                  ? activeFeeLines.map((fee) => (
                    <div
                      key={fee.id}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        fontSize: "var(--text-title-3)",
                      }}
                    >
                      <span
                        style={{
                          color: "var(--neutral-on-surface-secondary)",
                        }}
                      >
                        {fee.name.trim() || "Fee"}
                      </span>
                      <span style={{ fontWeight: "var(--font-weight-bold)" }}>
                        {formatCurrency(parseFloat(fee.amount) || 0)}
                      </span>
                    </div>
                  ))
                  : null}
                <div
                  style={{
                    borderTop: "1px solid var(--neutral-line-separator-1)",
                  }}
                />
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    fontSize: "20px",
                    fontWeight: "var(--font-weight-black)",
                  }}
                >
                  <span>Total</span>
                  <span>{formatCurrency(total)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        style={{
          position: "fixed",
          bottom: 0,
          left: isSidebarCollapsed ? "82px" : "286px",
          right: 0,
          transition: "left 0.2s ease",
          background: "var(--neutral-surface-primary)",
          borderTop: "1px solid var(--neutral-line-separator-1)",
          padding: "14px 24px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          zIndex: 100,
        }}
      >
        <Button
          size="medium"
          variant="ghost"
          onClick={handleBackNavigation}
          style={{ color: "var(--status-red-primary)" }}
        >
          Cancel
        </Button>
        <div style={{ display: "flex", gap: "12px" }}>
          <Button size="medium" variant="outlined" onClick={handleSaveDraft}>
            Save as Draft
          </Button>
          <Button size="medium" variant="filled" onClick={handleSubmitClick}>
            Submit PO
          </Button>
        </div>
      </div>

      {showAddProductModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "80vw",
              maxWidth: "1600px",
              maxHeight: "88vh",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              position: "relative",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <div
              style={{
                position: "relative",
                minHeight: "40px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <IconButton
                icon={CloseIcon}
                size="large"
                onClick={() => setShowAddProductModal(false)}
                style={{ position: "absolute", top: "-8px", right: 0 }}
                color="var(--neutral-on-surface-tertiary)"
              />
              <h2
                style={{
                  margin: 0,
                  fontSize: "var(--text-headline)",
                  fontWeight: "var(--font-weight-bold)",
                  textAlign: "center",
                }}
              >
                {editingLineId
                  ? "Edit Purchase Order Line"
                  : "Add Purchase Order Line"}
              </h2>
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "20px",
                overflowY: "auto",
                paddingRight: "4px",
                minHeight: 0,
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "12px",
                }}
              >
                <div
                  style={{ display: "flex", alignItems: "center", gap: "4px" }}
                >
                  <span
                    style={{
                      color: "var(--status-red-primary)",
                      fontSize: "var(--text-title-3)",
                    }}
                  >
                    *
                  </span>
                  <span
                    style={{
                      fontSize: "var(--text-title-3)",
                      fontWeight: "var(--font-weight-regular)",
                      color: "var(--neutral-on-surface-primary)",
                    }}
                  >
                    Purchase Order Line Type
                  </span>
                </div>

                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr 1fr",
                    gap: "16px",
                  }}
                >
                  {[
                    {
                      key: "manual",
                      title: "Manual",
                      desc: "Add a product line manually by filling in the product details.",
                    },
                    {
                      key: "material",
                      title: "Material",
                      desc: "Select a material and adjust the editable fields as needed.",
                    },
                    {
                      key: "wo",
                      title: "Work Order",
                      desc: "Use an available work order line and adjust the editable fields as needed.",
                    },
                  ].map((option) => (
                    <button
                      key={option.key}
                      type="button"
                      onClick={() => {
                        if (!isEditingLockedWorkOrderLine)
                          setProductLineType(option.key);
                      }}
                      disabled={isEditingLockedWorkOrderLine}
                      style={{
                        border:
                          productLineType === option.key
                            ? "2px solid var(--feature-brand-primary)"
                            : "1px solid var(--neutral-line-separator-2)",
                        borderRadius: "24px",
                        background:
                          productLineType === option.key
                            ? "var(--feature-brand-container-lighter)"
                            : "var(--neutral-surface-primary)",
                        padding: "22px 24px",
                        display: "flex",
                        alignItems: "flex-start",
                        gap: "14px",
                        cursor: isEditingLockedWorkOrderLine
                          ? "not-allowed"
                          : "pointer",
                        textAlign: "left",
                      }}
                    >
                      <div
                        style={{
                          width: "20px",
                          height: "20px",
                          borderRadius: "50%",
                          border:
                            productLineType === option.key
                              ? "2px solid var(--feature-brand-primary)"
                              : "2px solid var(--neutral-line-separator-2)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                          marginTop: "2px",
                        }}
                      >
                        {productLineType === option.key ? (
                          <div
                            style={{
                              width: "10px",
                              height: "10px",
                              borderRadius: "50%",
                              background: "var(--feature-brand-primary)",
                            }}
                          />
                        ) : null}
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: "8px",
                        }}
                      >
                        <span
                          style={{
                            fontSize: "16px",
                            fontWeight: "var(--font-weight-bold)",
                            color: "var(--neutral-on-surface-primary)",
                          }}
                        >
                          {option.title}
                        </span>
                        <span
                          style={{
                            fontSize: "14px",
                            color: "var(--neutral-on-surface-secondary)",
                            lineHeight: "1.5",
                          }}
                        >
                          {option.desc}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {productLineType === "manual" ? (
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: "16px",
                  }}
                >
                  <div style={{ gridColumn: "1 / -1" }}>
                    {renderProductImageUploader(false)}
                  </div>
                  <div style={{ gridColumn: "1 / -1" }}>
                    <InputField
                      label="Name"
                      required
                      value={productModalForm.manualName}
                      onChange={(e) => {
                        setProductModalForm({
                          ...productModalForm,
                          manualName: e.target.value,
                        });
                        if (productModalFieldErrors.manualName)
                          setProductModalFieldErrors((prev) => ({
                            ...prev,
                            manualName: "",
                          }));
                      }}
                      placeholder="Enter name"
                    />
                    {productModalFieldErrors.manualName ? (
                      <span
                        style={{
                          fontSize: "var(--text-body)",
                          color: "var(--status-red-primary)",
                        }}
                      >
                        {productModalFieldErrors.manualName}
                      </span>
                    ) : null}
                  </div>
                  <InputField
                    label="SKU / Code"
                    value={productModalForm.manualCode}
                    onChange={(e) =>
                      setProductModalForm({
                        ...productModalForm,
                        manualCode: e.target.value,
                      })
                    }
                    placeholder="Enter code"
                  />
                  <div>
                    <InputField
                      label="Quantity"
                      required
                      type="number"
                      value={productModalForm.manualQty}
                      onChange={(e) => {
                        setProductModalForm({
                          ...productModalForm,
                          manualQty: e.target.value,
                        });
                        if (productModalFieldErrors.manualQty)
                          setProductModalFieldErrors((prev) => ({
                            ...prev,
                            manualQty: "",
                          }));
                      }}
                      placeholder="0"
                    />
                    {productModalFieldErrors.manualQty ? (
                      <span
                        style={{
                          fontSize: "var(--text-body)",
                          color: "var(--status-red-primary)",
                        }}
                      >
                        {productModalFieldErrors.manualQty}
                      </span>
                    ) : null}
                  </div>
                  <div style={{ gridColumn: "1 / -1" }}>
                    <InputField
                      label="Description"
                      multiline
                      value={productModalForm.manualDesc}
                      onChange={(e) =>
                        setProductModalForm({
                          ...productModalForm,
                          manualDesc: e.target.value,
                        })
                      }
                      placeholder="Enter description"
                    />
                  </div>
                  <div
                    style={{
                      gridColumn: "1 / -1",
                      display: "flex",
                      flexDirection: "column",
                      gap: "8px",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                        fontSize: "var(--text-body)",
                      }}
                    >
                      <span style={{ color: "var(--status-red-primary)" }}>
                        *
                      </span>
                      <span>Unit Price</span>
                    </div>
                    <InputGroup
                      type="number"
                      value={productModalForm.manualPrice}
                      onChange={(e) => {
                        setProductModalForm({
                          ...productModalForm,
                          manualPrice: e.target.value,
                        });
                        if (productModalFieldErrors.manualPrice)
                          setProductModalFieldErrors((prev) => ({
                            ...prev,
                            manualPrice: "",
                          }));
                      }}
                      placeholder="0"
                      prefix={currencyPrefixLabel}
                      hasError={!!productModalFieldErrors.manualPrice}
                    />
                    {productModalFieldErrors.manualPrice ? (
                      <span
                        style={{
                          fontSize: "var(--text-body)",
                          color: "var(--status-red-primary)",
                        }}
                      >
                        {productModalFieldErrors.manualPrice}
                      </span>
                    ) : null}
                  </div>
                </div>
              ) : productLineType === "material" ? (
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "16px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "8px",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                        fontSize: "var(--text-body)",
                      }}
                    >
                      <span style={{ color: "var(--status-red-primary)" }}>
                        *
                      </span>
                      <span>Material</span>
                    </div>
                    <DropdownSelect
                      value={productModalForm.selectedMaterialLineId}
                      disabled={isEditingLockedWorkOrderLine}
                      hasError={!!productModalFieldErrors.selectedMaterialLineId}
                      onChange={(selectedId) => {
                        const targetLine = availableMaterialLines.find(
                          (line) => line.id === selectedId
                        );
                        setProductModalForm({
                          ...productModalForm,
                          selectedMaterialLineId: selectedId,
                          manualName: targetLine?.item || "",
                          manualCode: targetLine?.code || "",
                          manualDesc: targetLine?.desc || "",
                          manualQty: targetLine ? String(targetLine.qty) : "",
                          manualPrice: targetLine
                            ? String(targetLine.price)
                            : "",
                        });
                        setProductModalImages(
                          targetLine?.image
                            ? [createImageUploadRecord(targetLine.image)]
                            : []
                        );
                        if (productModalFieldErrors.selectedMaterialLineId)
                          setProductModalFieldErrors((prev) => ({
                            ...prev,
                            selectedMaterialLineId: "",
                          }));
                      }}
                      placeholder="Select material"
                      options={availableMaterialLines.map((line) => ({
                        value: line.id,
                        label: `${line.item} · ${line.code}`,
                      }))}
                    />
                    {productModalFieldErrors.selectedMaterialLineId ? (
                      <span
                        style={{
                          fontSize: "var(--text-body)",
                          color: "var(--status-red-primary)",
                        }}
                      >
                        {productModalFieldErrors.selectedMaterialLineId}
                      </span>
                    ) : null}
                  </div>
                  {availableMaterialLines.length === 0 ? (
                    <span
                      style={{
                        fontSize: "var(--text-body)",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      No materials available.
                    </span>
                  ) : null}
                  {productModalForm.selectedMaterialLineId ? (
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: "1fr 1fr",
                        gap: "16px",
                      }}
                    >
                      <div style={{ gridColumn: "1 / -1" }}>
                        {renderProductImageUploader(true)}
                      </div>
                      <div style={{ gridColumn: "1 / -1" }}>
                        <InputField
                          label="Name"
                          value={productModalForm.manualName}
                          disabled
                        />
                      </div>
                      <InputField
                        label="SKU / Code"
                        value={productModalForm.manualCode}
                        disabled
                      />
                      <div>
                        <InputField
                          label="Quantity"
                          required
                          type="number"
                          value={productModalForm.manualQty}
                          onChange={(e) => {
                            setProductModalForm({
                              ...productModalForm,
                              manualQty: e.target.value,
                            });
                            if (productModalFieldErrors.manualQty)
                              setProductModalFieldErrors((prev) => ({
                                ...prev,
                                manualQty: "",
                              }));
                          }}
                          placeholder="0"
                        />
                        {productModalFieldErrors.manualQty ? (
                          <span
                            style={{
                              fontSize: "var(--text-body)",
                              color: "var(--status-red-primary)",
                            }}
                          >
                            {productModalFieldErrors.manualQty}
                          </span>
                        ) : null}
                      </div>
                      <div style={{ gridColumn: "1 / -1" }}>
                        <InputField
                          label="Description"
                          multiline
                          value={productModalForm.manualDesc}
                          onChange={(e) =>
                            setProductModalForm({
                              ...productModalForm,
                              manualDesc: e.target.value,
                            })
                          }
                          placeholder="Enter description"
                        />
                      </div>
                      <div
                        style={{
                          gridColumn: "1 / -1",
                          display: "flex",
                          flexDirection: "column",
                          gap: "8px",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "4px",
                            fontSize: "var(--text-body)",
                          }}
                        >
                          <span style={{ color: "var(--status-red-primary)" }}>
                            *
                          </span>
                          <span>Unit Price</span>
                        </div>
                        <InputGroup
                          type="number"
                          value={productModalForm.manualPrice}
                          onChange={(e) => {
                            setProductModalForm({
                              ...productModalForm,
                              manualPrice: e.target.value,
                            });
                            if (productModalFieldErrors.manualPrice)
                              setProductModalFieldErrors((prev) => ({
                                ...prev,
                                manualPrice: "",
                              }));
                          }}
                          placeholder="0"
                          prefix={currencyPrefixLabel}
                          hasError={!!productModalFieldErrors.manualPrice}
                        />
                        {productModalFieldErrors.manualPrice ? (
                          <span
                            style={{
                              fontSize: "var(--text-body)",
                              color: "var(--status-red-primary)",
                            }}
                          >
                            {productModalFieldErrors.manualPrice}
                          </span>
                        ) : null}
                      </div>
                    </div>
                  ) : null}
                </div>
              ) : (
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "16px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "8px",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                        fontSize: "var(--text-body)",
                      }}
                    >
                      <span style={{ color: "var(--status-red-primary)" }}>
                        *
                      </span>
                      <span>Work Order</span>
                    </div>
                    <DropdownSelect
                      value={productModalForm.selectedWorkOrderLineId}
                      disabled={isEditingLockedWorkOrderLine}
                      hasError={!!productModalFieldErrors.selectedWorkOrderLineId}
                      onChange={(selectedId) => {
                        const targetLine = availableWorkOrderLines.find(
                          (line) => getWorkOrderSourceId(line) === selectedId
                        );
                        setProductModalForm({
                          ...productModalForm,
                          selectedWorkOrderLineId: selectedId,
                          manualName: targetLine?.item || "",
                          manualCode: targetLine?.code || "",
                          manualDesc: targetLine?.desc || "",
                          manualQty: targetLine ? String(targetLine.qty) : "",
                          manualPrice: targetLine
                            ? String(targetLine.price)
                            : "",
                        });
                        setProductModalImages(
                          targetLine?.image
                            ? [createImageUploadRecord(targetLine.image)]
                            : []
                        );
                        if (productModalFieldErrors.selectedWorkOrderLineId)
                          setProductModalFieldErrors((prev) => ({
                            ...prev,
                            selectedWorkOrderLineId: "",
                          }));
                      }}
                      placeholder="Select work order"
                      options={availableWorkOrderLines.map((line) => ({
                        value: getWorkOrderSourceId(line),
                        label: `${line.item} · ${line.woRef}`,
                      }))}
                    />
                    {productModalFieldErrors.selectedWorkOrderLineId ? (
                      <span
                        style={{
                          fontSize: "var(--text-body)",
                          color: "var(--status-red-primary)",
                        }}
                      >
                        {productModalFieldErrors.selectedWorkOrderLineId}
                      </span>
                    ) : null}
                    {isEditingLockedWorkOrderLine ? (
                      <span
                        style={{
                          fontSize: "var(--text-body)",
                          color: "var(--neutral-on-surface-secondary)",
                        }}
                      >
                        This item is linked to a work order and cannot be
                        changed.
                      </span>
                    ) : null}
                  </div>
                  {availableWorkOrderLines.length === 0 ? (
                    <span
                      style={{
                        fontSize: "var(--text-body)",
                        color: "var(--neutral-on-surface-secondary)",
                      }}
                    >
                      No work orders available for the selected vendor.
                    </span>
                  ) : null}
                  {productModalForm.selectedWorkOrderLineId ? (
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: "1fr 1fr",
                        gap: "16px",
                      }}
                    >
                      <div style={{ gridColumn: "1 / -1" }}>
                        {renderProductImageUploader(true)}
                      </div>
                      <div style={{ gridColumn: "1 / -1" }}>
                        <InputField
                          label="Name"
                          value={productModalForm.manualName}
                          disabled
                        />
                      </div>
                      <InputField
                        label="SKU / Code"
                        value={productModalForm.manualCode}
                        disabled
                      />
                      <div>
                        <InputField
                          label="Quantity"
                          required
                          type="number"
                          value={productModalForm.manualQty}
                          onChange={(e) => {
                            setProductModalForm({
                              ...productModalForm,
                              manualQty: e.target.value,
                            });
                            if (productModalFieldErrors.manualQty)
                              setProductModalFieldErrors((prev) => ({
                                ...prev,
                                manualQty: "",
                              }));
                          }}
                          placeholder="0"
                        />
                        {productModalFieldErrors.manualQty ? (
                          <span
                            style={{
                              fontSize: "var(--text-body)",
                              color: "var(--status-red-primary)",
                            }}
                          >
                            {productModalFieldErrors.manualQty}
                          </span>
                        ) : null}
                      </div>
                      <div style={{ gridColumn: "1 / -1" }}>
                        <InputField
                          label="Description"
                          multiline
                          value={productModalForm.manualDesc}
                          onChange={(e) =>
                            setProductModalForm({
                              ...productModalForm,
                              manualDesc: e.target.value,
                            })
                          }
                          placeholder="Enter description"
                        />
                      </div>
                      <div
                        style={{
                          gridColumn: "1 / -1",
                          display: "flex",
                          flexDirection: "column",
                          gap: "8px",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "4px",
                            fontSize: "var(--text-body)",
                          }}
                        >
                          <span style={{ color: "var(--status-red-primary)" }}>
                            *
                          </span>
                          <span>Unit Price</span>
                        </div>
                        <InputGroup
                          type="number"
                          value={productModalForm.manualPrice}
                          onChange={(e) => {
                            setProductModalForm({
                              ...productModalForm,
                              manualPrice: e.target.value,
                            });
                            if (productModalFieldErrors.manualPrice)
                              setProductModalFieldErrors((prev) => ({
                                ...prev,
                                manualPrice: "",
                              }));
                          }}
                          placeholder="0"
                          prefix={currencyPrefixLabel}
                          hasError={!!productModalFieldErrors.manualPrice}
                        />
                        {productModalFieldErrors.manualPrice ? (
                          <span
                            style={{
                              fontSize: "var(--text-body)",
                              color: "var(--status-red-primary)",
                            }}
                          >
                            {productModalFieldErrors.manualPrice}
                          </span>
                        ) : null}
                      </div>
                    </div>
                  ) : null}
                </div>
              )}

              {productModalError ? (
                <span
                  style={{
                    fontSize: "var(--text-body)",
                    color: "var(--status-red-primary)",
                  }}
                >
                  {productModalError}
                </span>
              ) : null}
            </div>
            <div style={{ display: "flex", gap: "12px", flexShrink: 0 }}>
              <Button
                variant="outlined"
                size="large"
                style={{ flex: 1 }}
                onClick={() => {
                  setShowAddProductModal(false);
                  setEditingLineId(null);
                }}
              >
                Cancel
              </Button>
              <Button
                variant="filled"
                size="large"
                style={{ flex: 1 }}
                onClick={handleSaveProductLine}
              >
                {editingLineId ? "Save Changes" : "Add PO Line"}
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {showEmptyDraftModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "420px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "28px 22px 22px",
              display: "flex",
              flexDirection: "column",
              gap: "16px",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <h2
              style={{
                margin: 0,
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Save as Draft?
            </h2>
            <p
              style={{
                margin: 0,
                textAlign: "center",
                fontSize: "var(--text-title-3)",
                color: "var(--neutral-on-surface-secondary)",
                lineHeight: "1.6",
              }}
            >
              Fill at least one field in the form to proceed.
            </p>
            <Button
              size="large"
              style={{ width: "100%" }}
              onClick={() => setShowEmptyDraftModal(false)}
            >
              Okay
            </Button>
          </div>
        </div>
      ) : null}

      {showSubmitConfirmModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "376px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "28px 22px 22px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              boxShadow: "var(--elevation-sm)",
            }}
          >
            <h2
              style={{
                margin: 0,
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Submit PO?
            </h2>
            <p
              style={{
                margin: 0,
                textAlign: "center",
                fontSize: "var(--text-title-3)",
                color: "var(--neutral-on-surface-secondary)",
                lineHeight: "1.6",
              }}
            >
              {poApprovalSettings?.isApprovalActive
                ? "This PO will be submitted for approval."
                : "This PO will be automatically approved upon submission."}
            </p>
            <div
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <Button
                size="large"
                style={{ width: "100%" }}
                onClick={handleConfirmSubmit}
              >
                Yes, Submit
              </Button>
              <Button
                variant="outlined"
                size="large"
                style={{ width: "100%" }}
                onClick={() => setShowSubmitConfirmModal(false)}
              >
                Keep Editing
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {showDiscardChangesModal ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              width: "400px",
              background: "var(--neutral-surface-primary)",
              borderRadius: "24px",
              padding: "24px 22px 22px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              boxShadow: "var(--elevation-sm)",
              position: "relative",
            }}
          >
            <IconButton
              icon={CloseIcon}
              size="large"
              onClick={() => setShowDiscardChangesModal(false)}
              style={{ position: "absolute", top: "16px", right: "16px" }}
              color="var(--neutral-on-surface-tertiary)"
            />
            <h2
              style={{
                margin: "8px 0 0 0",
                textAlign: "center",
                fontSize: "var(--text-headline)",
                fontWeight: "var(--font-weight-bold)",
              }}
            >
              Discard changes?
            </h2>
            <div
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <Button
                variant="filled"
                size="large"
                style={{ width: "100%" }}
                onClick={() => {
                  setShowDiscardChangesModal(false);
                  navigateBackWithoutPrompt();
                }}
              >
                Yes, Discard
              </Button>
              <Button
                variant="outlined"
                size="large"
                style={{ width: "100%" }}
                onClick={() => setShowDiscardChangesModal(false)}
              >
                Keep Editing
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default function App() {
  const [activeModule, setActiveModule] = useState("work_order");
  const [viewState, setViewState] = useState({ view: "list", data: null });
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const appRootRef = useRef(null);
  const isApplyingLocalizationRef = useRef(false);
  const [language, setLanguage] = useState(() => {
    if (typeof window === "undefined") return "en";
    const storedLanguage = window.localStorage.getItem("labamu-language");
    return storedLanguage === "id" ? "id" : "en";
  });
  const [poApprovalSettings, setPoApprovalSettings] = useState({
    isApprovalActive: false,
    requireComment: false,
    approvers: [],
  });
  const [notificationSettings, setNotificationSettings] = useState(() =>
    cloneNotificationSettings()
  );
  const [systemNotifications, setSystemNotifications] = useState(
    DEFAULT_SYSTEM_NOTIFICATIONS
  );

  const t = (key, fallback = "") => getTranslation(language, key, fallback);

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.lang = language === "id" ? "id" : "en";
    }
    if (typeof window !== "undefined") {
      window.localStorage.setItem("labamu-language", language);
    }
  }, [language]);

  useEffect(() => {
    const rootNode = appRootRef.current;
    if (!rootNode || typeof MutationObserver === "undefined") return undefined;

    const runLocalization = () => {
      if (isApplyingLocalizationRef.current) return;
      isApplyingLocalizationRef.current = true;

      try {
        applyDomLocalization(rootNode, language);
      } finally {
        isApplyingLocalizationRef.current = false;
      }
    };

    runLocalization();

    const observer = new MutationObserver(() => {
      runLocalization();
    });

    observer.observe(rootNode, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: LOCALIZABLE_ATTRIBUTES,
    });

    return () => observer.disconnect();
  }, [language]);

  const handleModuleChange = (moduleId) => {
    setActiveModule(moduleId);
    setViewState({ view: "list", data: null });
  };

  const renderContent = () => {
    if (activeModule === "user_guide") {
      return (
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            background: "#F5F6FA",
            height: "100%",
            overflowY: "auto",
          }}
        >
          <div
            style={{
              maxWidth: "900px",
              margin: "0 auto",
              padding: "40px 32px 80px",
              display: "flex",
              flexDirection: "column",
              gap: "24px",
              width: "100%",
            }}
          >
            {/* Header */}
            <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
              <h1 style={{ fontSize: "28px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>
                User Guide
              </h1>
              <p style={{ fontSize: "14px", color: "#6B7280", margin: 0 }}>
                Complete step-by-step guide to using Labamu Manufacturing (MRP)
              </p>
            </div>

            {/* Intro Callout */}
            <div
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: "12px",
                padding: "16px 20px",
                background: "#fff",
                borderRadius: "12px",
                border: "1px solid #E5E7EB",
              }}
            >
              <Info size={18} color="#6B7280" style={{ flexShrink: 0, marginTop: "2px" }} />
              <span style={{ color: "#374151", fontSize: "14px", lineHeight: "1.6" }}>
                This guide walks you through the entire manufacturing workflow, from setup to production tracking. You can plan, produce, and monitor efficiently.
              </span>
            </div>

            {/* Step 1 */}
            <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "18px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ display: "flex", alignItems: "center", justifyCenter: "center", width: "28px", height: "28px", borderRadius: "50%", border: "2px solid #4F70E2", flexShrink: 0, padding: "4px" }}>
                  <Check size={14} color="#4F70E2" />
                </div>
                <h2 style={{ fontSize: "18px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>Step 1: Getting Started</h2>
              </div>
              <p style={{ fontSize: "14px", color: "#6B7280", marginTop: "-8px", margin: 0 }}>Set up your account and understand the basics.</p>
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                <span style={{ fontSize: "14px", fontWeight: "600", color: "#1A1D23" }}>What you need to know:</span>
                <ul style={{ paddingLeft: "20px", display: "flex", flexDirection: "column", gap: "6px", color: "#4B5563", margin: 0, fontSize: "14px" }}>
                  <li>MRP is automatically available once your business is activated for the Manufacturing app on Labamu.</li>
                  <li>It connects directly with <b>Products</b>, <b>Materials</b>, <b>BOM (Bill of Materials)</b>, and <b>Routing</b>.</li>
                  <li>Each production order follows this flow:</li>
                </ul>
                <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "6px", padding: "12px 16px", background: "#F0F7FF", borderRadius: "10px" }}>
                  {["Material Planning", "RFQ", "Quotes", "Order", "Work Order", "Production Tracking", "Completion"].map((pill, idx, arr) => (
                    <React.Fragment key={idx}>
                      <span style={{ background: "#4F70E2", color: "#fff", padding: "4px 12px", borderRadius: "20px", fontSize: "12px", fontWeight: "600" }}>{pill}</span>
                      {idx < arr.length - 1 && <span style={{ color: "#9CA3AF" }}><ChevronRight size={14} /></span>}
                    </React.Fragment>
                  ))}
                </div>
                <ul style={{ paddingLeft: "20px", display: "flex", flexDirection: "column", gap: "6px", color: "#4B5563", margin: 0, fontSize: "14px" }}>
                  <li>Ensure your master data (Products, Materials, BOM, and Routing) is uploaded before creating an Order.</li>
                </ul>
              </div>
            </div>

            {/* Step 2 */}
            <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "18px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ display: "flex", alignItems: "center", justifyCenter: "center", width: "28px", height: "28px", borderRadius: "50%", border: "2px solid #4F70E2", flexShrink: 0, padding: "4px" }}>
                  <Check size={14} color="#4F70E2" />
                </div>
                <h2 style={{ fontSize: "18px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>Step 2: Manage Materials & Batches</h2>
              </div>
              <p style={{ fontSize: "14px", color: "#6B7280", marginTop: "-8px", margin: 0 }}>Define all raw materials or components used in your production.</p>

              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                <span style={{ fontSize: "14px", fontWeight: "600", color: "#1A1D23" }}>How to Create Materials:</span>
                <ol style={{ paddingLeft: "20px", display: "flex", flexDirection: "column", gap: "6px", color: "#4B5563", margin: 0, fontSize: "14px" }}>
                  <li>Navigate to <b>Manufacturing → Materials</b> in the sidebar.</li>
                  <li>Click <b>New Material</b>.</li>
                  <li>Fill in the details:
                    <ul style={{ paddingLeft: "20px", display: "flex", flexDirection: "column", gap: "4px", marginTop: "4px", fontSize: "13px" }}>
                      <li><b>SKU</b> – Auto-generated if left empty.</li>
                      <li><b>Material Name</b> – (Mandatory) e.g., <i>Steel Plate 2mm</i>.</li>
                      <li><b>Category</b> – (Mandatory) e.g., <i>Metal</i>, <i>Plastic</i>.</li>
                      <li><b>ABC Classification</b> – (Mandatory) A = High Value, B = Medium, C = Low.</li>
                      <li><b>Material Type</b> – (Mandatory) Raw Material, Sub Material, or Consumable.</li>
                      <li><b>Unit of Measure</b> – (Mandatory) e.g., <i>pcs</i>, <i>kg</i>, <i>mL</i>.</li>
                    </ul>
                  </li>
                  <li>Click <b>Save</b>.</li>
                </ol>
                <div style={{ padding: "16px 18px", background: "#EFF6FF", borderRadius: "10px", display: "flex", flexDirection: "column", gap: "6px" }}>
                  <span style={{ fontSize: "13px", fontWeight: "700", color: "#1A1D23" }}>How to Create Batches:</span>
                  <p style={{ fontSize: "13px", color: "#4B5563", margin: 0 }}>Track stock quantity, expiry, and vendor details for each material via the <b>Stock Batches</b> tab.</p>
                </div>
              </div>
            </div>

            {/* Step 3 & 4 */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
              <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "12px" }}>
                <h3 style={{ fontSize: "16px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>Step 3: Create Routing</h3>
                <p style={{ fontSize: "13px", color: "#6B7280", margin: 0 }}>Define sequence of operations (e.g. Cutting → Assembly → QA).</p>
                <ol style={{ fontSize: "13px", color: "#4B5563", paddingLeft: "20px" }}>
                  <li>Go to <b>Manufacturing → Routing</b>.</li>
                  <li>Click <b>Add Stage</b>.</li>
                  <li>Enter Name & Save.</li>
                </ol>
              </div>
              <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "12px" }}>
                <h3 style={{ fontSize: "16px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>Step 4: Create BOM</h3>
                <p style={{ fontSize: "13px", color: "#6B7280", margin: 0 }}>Connect materials and routing steps into a production recipe.</p>
                <ol style={{ fontSize: "13px", color: "#4B5563", paddingLeft: "20px" }}>
                  <li>Go to <b>Bill of Materials</b>.</li>
                  <li>Assign Materials & Stages.</li>
                  <li>View calculated COGS.</li>
                </ol>
              </div>
            </div>

            {/* Step 5 */}
            <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "18px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ display: "flex", alignItems: "center", justifyCenter: "center", width: "28px", height: "28px", borderRadius: "50%", border: "2px solid #4F70E2", flexShrink: 0, padding: "4px" }}>
                  <Check size={14} color="#4F70E2" />
                </div>
                <h2 style={{ fontSize: "18px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>Step 5: Create Products</h2>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                <p style={{ fontSize: "14px", color: "#4B5563", margin: 0 }}>Define finished goods that will be produced using your BOMs.</p>
                <div style={{ padding: "14px 16px", background: "#FFF4F4", borderRadius: "10px", border: "1px solid #FFCDD2", display: "flex", gap: "10px", alignItems: "flex-start" }}>
                  <Info size={16} color="#B91C1C" style={{ flexShrink: 0, marginTop: "2px" }} />
                  <span style={{ fontSize: "13px", color: "#B91C1C", fontWeight: "500" }}><b>Critical:</b> Products <u>must</u> have an attached BOM to be used in RFQs, Quotes, or Orders.</span>
                </div>
              </div>
            </div>

            {/* Step 6 & 7 */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
              <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "12px" }}>
                <h3 style={{ fontSize: "16px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>Step 6: Create RFQ</h3>
                <p style={{ fontSize: "13px", color: "#6B7280", margin: 0 }}>Request procurement from suppliers. Manage up to 5 PICs per request.</p>
              </div>
              <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "12px" }}>
                <h3 style={{ fontSize: "16px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>Step 7: Manage Quotes</h3>
                <p style={{ fontSize: "13px", color: "#6B7280", margin: 0 }}>Create customer quotes with multi-PIC support, T&C, and payment terms.</p>
              </div>
            </div>

            {/* Step 8 & 9 */}
            <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "18px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ display: "flex", alignItems: "center", justifyCenter: "center", width: "28px", height: "28px", borderRadius: "50%", border: "2px solid #4F70E2", flexShrink: 0, padding: "4px" }}>
                  <Check size={14} color="#4F70E2" />
                </div>
                <h2 style={{ fontSize: "18px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>Execution: Orders & Work Orders</h2>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
                <div style={{ padding: "16px", background: "#F8F9FB", borderRadius: "12px", display: "flex", flexDirection: "column", gap: "8px" }}>
                  <span style={{ fontSize: "11px", fontWeight: "700", color: "#4F70E2", background: "#EFF6FF", padding: "2px 8px", borderRadius: "4px", alignSelf: "flex-start" }}>Step 8</span>
                  <span style={{ fontSize: "14px", fontWeight: "700", color: "#1A1D23" }}>Manage Orders</span>
                  <p style={{ fontSize: "13px", color: "#6B7280", margin: 0 }}>Confirm orders and track planned vs actual dates. Manage shipment codes for tracking.</p>
                </div>
                <div style={{ padding: "16px", background: "#F8F9FB", borderRadius: "12px", display: "flex", flexDirection: "column", gap: "8px" }}>
                  <span style={{ fontSize: "11px", fontWeight: "700", color: "#4F70E2", background: "#EFF6FF", padding: "2px 8px", borderRadius: "4px", alignSelf: "flex-start" }}>Step 9</span>
                  <span style={{ fontSize: "14px", fontWeight: "700", color: "#1A1D23" }}>Work Order</span>
                  <p style={{ fontSize: "13px", color: "#6B7280", margin: 0 }}>Allocate materials and track routing progress. Production results update inventory.</p>
                </div>
              </div>
            </div>

            {/* Step 10 & Settings */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
              <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "12px" }}>
                <h3 style={{ fontSize: "16px", fontWeight: "700", color: "#1A1D23", margin: 0 }}>Step 10: Invoicing</h3>
                <p style={{ fontSize: "13px", color: "#6B7280", margin: 0 }}>Create repayment or down payment invoices directly from Orders or Finance menu.</p>
              </div>
              <div style={{ background: "#fff", borderRadius: "16px", border: "1px solid #E5E7EB", padding: "24px", display: "flex", flexDirection: "column", gap: "12px" }}>
                <h3 style={{ fontSize: "16px", fontWeight: "700", color: "#6366F1", margin: 0 }}>Admin Settings</h3>
                <p style={{ fontSize: "13px", color: "#6B7280", margin: 0 }}>Manage <b>User Permissions</b>, Groups, and <b>FX Exchange Rates</b> for multi-currency support.</p>
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (activeModule === "user_management") {
      return <AdministrationUserManagement isSidebarCollapsed={isSidebarCollapsed} />;
    }

    if (activeModule === "notification_settings") {
      return (
        <AdministrationNotificationSettings
          isSidebarCollapsed={isSidebarCollapsed}
          notificationSettings={notificationSettings}
          onSaveNotificationSettings={setNotificationSettings}
        />
      );
    }
    if (activeModule === "work_order") {
      if (viewState.view === "list") {
        return (
          <WorkOrderList
            onNavigate={(view, data) => setViewState({ view, data })}
            t={t}
          />
        );
      }
      if (viewState.view === "detail") {
        return (
          <WorkOrderDetail
            onNavigate={(view, data) => setViewState({ view, data })}
            isSidebarCollapsed={isSidebarCollapsed}
            initialData={viewState.data}
          />
        );
      }
      if (viewState.view === "create") {
        return (
          <PurchaseOrderCreate
            onNavigate={(view, data) => setViewState({ view, data })}
            isSidebarCollapsed={isSidebarCollapsed}
            initialData={viewState.data}
            poApprovalSettings={poApprovalSettings}
          />
        );
      }
      if (viewState.view === "po_detail") {
        return (
          <PurchaseOrderDetail
            onNavigate={(view, data) => setViewState({ view, data })}
            initialData={viewState.data}
            poApprovalSettings={poApprovalSettings}
            isSidebarCollapsed={isSidebarCollapsed}
          />
        );
      }
    }
    if (activeModule === "purchase_order") {
      if (viewState.view === "list") {
        return (
          <PurchaseOrderList
            onNavigate={(view, data) => setViewState({ view, data })}
            t={t}
          />
        );
      }
      if (viewState.view === "settings") {
        return (
          <PurchaseOrderSettings
            onNavigate={(view, data) => setViewState({ view, data })}
            isSidebarCollapsed={isSidebarCollapsed}
            poApprovalSettings={poApprovalSettings}
            onSaveSettings={setPoApprovalSettings}
          />
        );
      }
      if (viewState.view === "create") {
        return (
          <PurchaseOrderCreate
            onNavigate={(view, data) => setViewState({ view, data })}
            isSidebarCollapsed={isSidebarCollapsed}
            initialData={viewState.data}
            poApprovalSettings={poApprovalSettings}
          />
        );
      }
      if (viewState.view === "detail" || viewState.view === "po_detail") {
        return (
          <PurchaseOrderDetail
            onNavigate={(view, data) => setViewState({ view, data })}
            initialData={viewState.data}
            poApprovalSettings={poApprovalSettings}
            isSidebarCollapsed={isSidebarCollapsed}
          />
        );
      }
    }
    return (
      <div
        style={{
          padding: "24px",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100%",
        }}
      >
        <span
          style={{
            color: "var(--neutral-on-surface-tertiary)",
            fontSize: "var(--text-title-2)",
          }}
        >
          {t("message.under_construction")}
        </span>
      </div>
    );
  };

  return (
    <div
      ref={appRootRef}
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh",
        background: "#F5F5F7",
      }}
    >
      <LabamuStyles />
      <div style={{ display: "flex", flex: 1, width: "100%" }}>
        <Sidebar
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          activeModule={activeModule}
          onModuleChange={handleModuleChange}
          language={language}
          onLanguageChange={setLanguage}
          t={t}
        />

        <div
          style={{
            marginLeft: isSidebarCollapsed ? "82px" : "286px",
            transition: "margin-left 0.2s ease",
            flex: 1,
            display: "flex",
            flexDirection: "column",
            position: "relative",
            minWidth: 0,
            paddingTop: "64px",
          }}
        >
          <TopHeader
            t={t}
            isSidebarCollapsed={isSidebarCollapsed}
            notificationSettings={notificationSettings}
            notifications={systemNotifications}
            onNotificationsChange={setSystemNotifications}
          />
          {renderContent()}
        </div>
      </div>
    </div>
  );
}

// =============================
// PURCHASE ORDER STATUS LOGIC (REVISED)
// =============================

// Determine if NO remaining qty across all items
const isNoRemainingQty = (items = []) => {
  if (!items.length) return false;
  return items.every((item) => {
    const ordered = Number(item.orderedQty || 0);
    const received = Number(item.receivedQty || 0);
    const remaining = Math.max(ordered - received, 0);
    return remaining === 0 && ordered > 0;
  });
};

// Resolve PO status based on remaining qty
const resolvePurchaseOrderStatus = (po) => {
  if (!po) return "Draft";

  // Keep terminal states
  if (po.status === "Canceled") return "Canceled";
  if (po.status === "Completed") return "Completed";

  // Core rule: no remaining qty → Completed
  if (po.status === "Issued" && isNoRemainingQty(po.items)) {
    return "Completed";
  }

  return po.status;
};

// Hook this after receipt confirmation
const handleConfirmReceipt = ({ po, receivePayload, setPO }) => {
  const updatedItems = po.items.map((item) => {
    const incoming = Number(receivePayload[item.id] || 0);
    const newReceived = Number(item.receivedQty || 0) + incoming;

    return {
      ...item,
      receivedQty: newReceived,
      remainingQty: Math.max(Number(item.orderedQty || 0) - newReceived, 0),
    };
  });

  const updatedPO = {
    ...po,
    items: updatedItems,
  };

  const nextStatus = resolvePurchaseOrderStatus(updatedPO);

  setPO({
    ...updatedPO,
    status: nextStatus,
  });
};
